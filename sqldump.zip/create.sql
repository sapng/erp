create database dbmecca;
use dbmecca;
source table.sql;
source index.sql;
source insert.sql;