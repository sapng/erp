CREATE TABLE `adm_applicant` (
    `applicant_id` varchar(50), 
    `applicant_name` varchar(100), 
    `address1` varchar(100), 
    `address2` varchar(100), 
    `address3` varchar(100), 
    `city` varchar(100), 
    `state` varchar(100), 
    `poscode` varchar(50), 
    `country_code` varchar(50), 
    `phone` varchar(50), 
    `gender` varchar(10), 
    `password` varchar(50), 
    `birth_date` datetime, 
    `email` varchar(50), 
    `vet_rule_scheme_id` varchar(50), 
    `vet_program_id` varchar(50), 
    `vet_date` datetime, 
    `status` varchar(50), 
    `applicant_status` int, 
    `offer_letter_text` text, 
    `status2` varchar(50), 
    `offer_letter_addr` text, 
    `offer_letter_salutation` text, 
    `offer_letter_subject` text, 
    `offer_letter_signature` text, 
    `apply_date` datetime, 
    `ip_address` varchar(50)
);
CREATE TABLE `adm_applicant_choice` (
    `applicant_id` varchar(50), 
    `choice1` varchar(50), 
    `choice2` varchar(50), 
    `choice3` varchar(50)
);
CREATE TABLE `adm_applicant_exam` (
    `applicant_id` varchar(50), 
    `adm_exam_id` varchar(50), 
    `adm_subject_id` varchar(50), 
    `adm_subject_grade` int
);
CREATE TABLE `adm_applicant_selected` (
    `applicant_id` varchar(50), 
    `rule_scheme_id` varchar(50), 
    `program_id` varchar(50), 
    `date_vetted` date
);
CREATE TABLE `adm_display_grade` (
    `adm_grade_display_id` varchar(50), 
    `adm_grade_value` int, 
    `adm_grade_display` varchar(50)
);
CREATE TABLE `adm_display_grade_main` (
    `adm_grade_display_id` varchar(50), 
    `adm_grade_display_name` varchar(100)
);
CREATE TABLE `adm_exam` (
    `adm_exam_id` varchar(50), 
    `adm_exam_name` varchar(200), 
    `display` varchar(10)
);
CREATE TABLE `adm_exam_subject` (
    `adm_subject_id` varchar(50), 
    `adm_exam_id` varchar(50), 
    `adm_subject_name` varchar(100), 
    `adm_grade_display_id` varchar(50)
);
CREATE TABLE `adm_qualifier_factor` (
    `qualifier_id` varchar(50), 
    `adm_subject_id` varchar(50), 
    `qualifier_subject_grade` int, 
    `qualifier_operator` varchar(10)
);
CREATE TABLE `adm_rule_scheme` (
    `rule_scheme_id` varchar(50), 
    `qualifier_id` varchar(50), 
    `rule_sequence` int, 
    `condition_operator` int, 
    `rule_group` int
);
CREATE TABLE `adm_rule_scheme_main` (
    `rule_scheme_id` varchar(50), 
    `rule_scheme_name` varchar(200)
);
CREATE TABLE `adm_subject_grade` (
    `adm_subject_id` varchar(50), 
    `grade_value` int, 
    `grade_display` varchar(10)
);
CREATE TABLE `applicant_status` (
    `status_id` varchar(50), 
    `status_name` varchar(60), 
    `status_description` varchar(255)
);
CREATE TABLE `attr_module_data` (
    `module_id` varchar(100), 
    `attribute_name` varchar(100), 
    `attribute_value` varchar(255)
);
CREATE TABLE `billing_doc` (
    `doc_name` varchar(50), 
    `doc_prefix` varchar(50), 
    `doc_num_size` int, 
    `doc_current_num` bigint
);
CREATE TABLE `blobs` (
    `id` varchar(50), 
    `filename` varchar(255), 
    `binarydata` longblob
);
CREATE TABLE `breakdown_marks` (
    `session_id` varchar(50), 
    `subject_id` varchar(50), 
    `breakdown_id` varchar(50), 
    `breakdown_name` varchar(50), 
    `breakdown_value` int
);
CREATE TABLE `choices` (
    `id` bigint, 
    `poll_id` varchar(50), 
    `text` varchar(255), 
    `value` bigint
);
CREATE TABLE `country` (
    `country_code` varchar(50), 
    `country_name` varchar(50)
);
CREATE TABLE `course` (
    `course_id` varchar(50), 
    `title` varchar(100)
);
CREATE TABLE `course_enroll` (
    `course_id` varchar(50), 
    `member_id` varchar(50)
);
CREATE TABLE `course_sco` (
    `course_id` varchar(50), 
    `sco_id` varchar(50), 
    `level` int
);
CREATE TABLE `course_structure` (
    `course_id` varchar(50), 
    `period_root_id` varchar(50), 
    `period_id` varchar(50), 
    `subject_id` varchar(50), 
    `subject_option` char, 
    `program_code` varchar(50), 
    `intake_session` varchar(50)
);
CREATE TABLE `course_url` (
    `subject_id` varchar(50), 
    `link_id` varchar(50), 
    `link_title` varchar(255), 
    `link_url` varchar(100), 
    `link_type` varchar(50)
);
CREATE TABLE `custom_data` (
    `data_id` varchar(50), 
    `data_name` varchar(100), 
    `value_type` varchar(20)
);
CREATE TABLE `custom_data_values` (
    `data_id` varchar(50), 
    `data_value` varchar(100)
);
CREATE TABLE `enquiry` (
    `program_code` varchar(50), 
    `name` varchar(100), 
    `gender` varchar(20), 
    `birth_date` datetime, 
    `address1` varchar(255), 
    `address2` varchar(255), 
    `state` varchar(50), 
    `country_code` varchar(50), 
    `phone_home` varchar(50), 
    `phone_mobile` varchar(50), 
    `email` varchar(100), 
    `academic_qualification` varchar(100), 
    `academic_year` int, 
    `academic_grade` varchar(100), 
    `enquiry_body` text, 
    `enquiry_id` varchar(50), 
    `city` varchar(50), 
    `poscode` varchar(50), 
    `date_post` datetime, 
    `status` varchar(100), 
    `category_id` varchar(50), 
    `date_closed` datetime, 
    `comment` text, 
    `reply` text, 
    `date_opened` datetime, 
    `comment_by` varchar(50)
);
CREATE TABLE `enquiry_status` (
    `status_id` varchar(50), 
    `status_name` varchar(50), 
    `status_description` varchar(255)
);
CREATE TABLE `faculty` (
    `faculty_id` varchar(100), 
    `faculty_code` varchar(100), 
    `faculty_name` varchar(100), 
    `institution_id` varchar(50)
);
CREATE TABLE `faculty_subject` (
    `faculty_id` varchar(50), 
    `subject_id` varchar(50), 
    `subject_name` varchar(50), 
    `credit_hrs` int, 
    `subject_code` varchar(50), 
    `subject_name_alt` varchar(50)
);
CREATE TABLE `fee_structure_general` (
    `fee_code` varchar(50), 
    `fee_description` varchar(255)
);
CREATE TABLE `fee_structure_program` (
    `program_code` varchar(50), 
    `fee_code` varchar(50), 
    `fee_description` varchar(255), 
    `fee_amount` float, 
    `session_id` varchar(50), 
    `fee_id` varchar(50)
);
CREATE TABLE `forum` (
    `id` varchar(50), 
    `parent_id` varchar(50), 
    `category_id` varchar(50), 
    `member_id` varchar(50), 
    `posted_date` date, 
    `title` varchar(255), 
    `description` varchar(255), 
    `content` text, 
    `is_parent` int, 
    `is_delete` int, 
    `message_text` text
);
CREATE TABLE `forum_attachment` (
    `forum_id` varchar(50), 
    `file_name` varchar(255), 
    `directory` varchar(255)
);
CREATE TABLE `grading_scheme` (
    `scheme_id` varchar(50), 
    `scheme_name` varchar(50)
);
CREATE TABLE `grading_scheme_detail` (
    `scheme_id` varchar(50), 
    `high_mark` float, 
    `low_mark` float, 
    `grade_letter` varchar(10), 
    `grade_point` float, 
    `grade_id` varchar(50)
);
CREATE TABLE `grading_scheme_impl` (
    `scheme_id` varchar(50), 
    `session_id` varchar(50), 
    `program_code` varchar(50)
);
CREATE TABLE `hd_categories` (
    `category_id` varchar(50), 
    `category_name` varchar(50), 
    `category_description` varchar(100)
);
CREATE TABLE `hd_escalation` (
    `enquiry_id` varchar(50), 
    `responsible_id` varchar(50), 
    `date_escalate` datetime, 
    `date_read` datetime, 
    `date_reply` datetime, 
    `reply_text` text
);
CREATE TABLE `hd_group` (
    `group_id` varchar(50), 
    `group_name` varchar(100)
);
CREATE TABLE `hd_responsible_group` (
    `group_id` varchar(50), 
    `res_id` varchar(50)
);
CREATE TABLE `hd_responsibles` (
    `res_id` varchar(50), 
    `res_email` varchar(50), 
    `res_phone_office` varchar(50), 
    `res_phone_mobile` varchar(50), 
    `res_phone_home` varchar(50)
);
CREATE TABLE `institution` (
    `institution_id` varchar(50), 
    `institution_name` varchar(100), 
    `institution_abbr` varchar(50)
);
CREATE TABLE `intake` (
    `intake_id` varchar(50), 
    `intake_name` varchar(50), 
    `intake_begin` date
);
CREATE TABLE `intake_batch` (
    `session_id` varchar(50), 
    `intake_session` varchar(50), 
    `period_root_id` varchar(50), 
    `period_id` varchar(50)
);
CREATE TABLE `ip2country` (
    `ip_from` double, 
    `ip_to` double, 
    `registry` varchar(60), 
    `assigned` varchar(60), 
    `country_code` char, 
    `country_code2` varchar(4), 
    `country_name` varchar(100)
);
CREATE TABLE `learner_sco` (
    `cmi_name` varchar(50), 
    `cmi_value` varchar(50), 
    `course_id` varchar(50), 
    `sco_id` varchar(50), 
    `member_id` varchar(50), 
    `cmi_value_text` text
);
CREATE TABLE `lesson` (
    `subject_id` varchar(50), 
    `lesson_id` varchar(50), 
    `lesson_title` varchar(100), 
    `lesson_description` varchar(255), 
    `lesson_sequence` int
);
CREATE TABLE `letter_compose` (
    `letter_id` varchar(50), 
    `content` text, 
    `applicant_address` text, 
    `salutation` text, 
    `subject` text, 
    `signature` text
);
CREATE TABLE `library_category` (
    `category_id` varchar(50), 
    `category_name` varchar(50), 
    `category_type` varchar(50)
);
CREATE TABLE `library_group` (
    `group_id` varchar(50), 
    `group_name` varchar(50), 
    `category_id` varchar(50)
);
CREATE TABLE `library_item` (
    `item_id` varchar(50), 
    `item_name` varchar(50), 
    `file_name` varchar(100), 
    `group_id` varchar(50), 
    `item_description` varchar(255)
);
CREATE TABLE `log_country` (
    `country_name` varchar(100), 
    `count` bigint
);
CREATE TABLE `marking_part` (
    `scheme_id` varchar(50), 
    `part_id` varchar(50), 
    `part_name` varchar(50), 
    `part_sequence` int, 
    `part_percentage` int
);
CREATE TABLE `marking_scheme` (
    `scheme_id` varchar(50), 
    `scheme_name` varchar(50)
);
CREATE TABLE `marking_scheme_impl` (
    `scheme_id` varchar(50), 
    `subject_id` varchar(50), 
    `session_id` varchar(50)
);
CREATE TABLE `member` (
    `member_id` varchar(50), 
    `login` varchar(50), 
    `password` varchar(50), 
    `name` varchar(100)
);
CREATE TABLE `member_subject` (
    `member_id` varchar(50), 
    `subject_id` varchar(50), 
    `role` varchar(50), 
    `status` varchar(50), 
    `date_apply` date, 
    `date_enroll` date, 
    `module_id` varchar(50)
);
CREATE TABLE `module` (
    `module_id` varchar(100), 
    `module_title` varchar(100), 
    `module_class` varchar(100), 
    `module_group` varchar(100), 
    `module_description` varchar(200)
);
CREATE TABLE `module_htmlcontainer` (
    `module_id` varchar(100), 
    `html_url` varchar(100)
);
CREATE TABLE `page_css` (
    `css_title` varchar(100), 
    `css_name` varchar(100)
);
CREATE TABLE `period` (
    `period_root_id` varchar(50), 
    `period_id` varchar(50), 
    `parent_id` varchar(50), 
    `period_level` int, 
    `period_sequence` int, 
    `period_name` varchar(100)
);
CREATE TABLE `period_root` (
    `period_schema_code` varchar(50), 
    `period_root_id` varchar(50)
);
CREATE TABLE `planner_task` (
    `task_id` varchar(100), 
    `user_login` varchar(100), 
    `task_description` varchar(255), 
    `task_start_date` timestamp, 
    `task_end_date` timestamp, 
    `task_public` int, 
    `subject_id` varchar(50), 
    `task_date` date, 
    `hour_start` int, 
    `hour_end` int, 
    `minute_start` int, 
    `minute_end` int
);
CREATE TABLE `planner_task_access` (
    `task_id` varchar(50), 
    `user_login` varchar(50)
);
CREATE TABLE `planner_task_invite` (
    `task_id` varchar(100), 
    `user_id` varchar(100), 
    `inviter_id` varchar(100), 
    `allow_edit` int
);
CREATE TABLE `planner_task_post` (
    `task_id` varchar(100), 
    `user_id` varchar(100), 
    `is_editable` int
);
CREATE TABLE `poll` (
    `tbl_id` bigint, 
    `id` varchar(50), 
    `question` varchar(255), 
    `title` varchar(255)
);
CREATE TABLE `program` (
    `course_id` varchar(50), 
    `period_root_id` varchar(50), 
    `program_name` varchar(100), 
    `program_code` varchar(50), 
    `program_abbr` varchar(50), 
    `program_name_alt` varchar(100), 
    `cyb_grad_credithrs` int, 
    `cyb_ptptn` varchar(100), 
    `cyb_tempoh` int
);
CREATE TABLE `program_intake` (
    `program_code` varchar(50), 
    `intake_session` varchar(50), 
    `period_root_id` varchar(50)
);
CREATE TABLE `quiz_choice` (
    `choice_id` varchar(50), 
    `question_id` varchar(50), 
    `choice_text` varchar(255), 
    `is_correct` int
);
CREATE TABLE `quiz_main` (
    `quiz_id` varchar(50), 
    `quiz_title` varchar(255), 
    `date_create` datetime, 
    `lesson_id` varchar(50)
);
CREATE TABLE `quiz_question` (
    `question_id` varchar(50), 
    `quiz_id` varchar(50), 
    `question_text` text, 
    `question_type` int
);
CREATE TABLE `role` (
    `name` varchar(100), 
    `description` varchar(255)
);
CREATE TABLE `role_module` (
    `module_id` varchar(100), 
    `user_role` varchar(100)
);
CREATE TABLE `rss_module` (
    `module_id` varchar(100), 
    `rss_source` varchar(200)
);
CREATE TABLE `sc_category` (
    `id` bigint, 
    `root` bigint, 
    `parent` bigint, 
    `name` varchar(255), 
    `description` text, 
    `is_parent` int, 
    `is_visible` int
);
CREATE TABLE `sc_content` (
    `user_login` varchar(20), 
    `itemId` bigint
);
CREATE TABLE `sc_item` (
    `id` bigint, 
    `catId` bigint, 
    `name` varchar(255), 
    `description` text, 
    `price` varchar(10), 
    `image` varchar(255), 
    `post_date` date
);
CREATE TABLE `sc_item_category` (
    `itemId` bigint, 
    `catId` bigint
);
CREATE TABLE `sco` (
    `sco_id` varchar(50), 
    `title` varchar(100), 
    `languange` varchar(20), 
    `description` varchar(255), 
    `keywords` varchar(255), 
    `lifecycle_version` varchar(50), 
    `lifecycle_status` varchar(50), 
    `metadata_scheme` varchar(50), 
    `edu_resource_type` varchar(50), 
    `edu_learning_time` varchar(50), 
    `class_purpose` varchar(50), 
    `class_keywords` varchar(255)
);
CREATE TABLE `session` (
    `session_id` varchar(50), 
    `session_name` varchar(50), 
    `start_date` date, 
    `end_date` date, 
    `session_name_alt` varchar(50)
);
CREATE TABLE `student` (
    `id` varchar(60), 
    `password` varchar(50), 
    `name` varchar(100), 
    `address1` varchar(100), 
    `address2` varchar(100), 
    `address3` varchar(100), 
    `city` varchar(50), 
    `state` varchar(50), 
    `poscode` varchar(50), 
    `country_code` varchar(50), 
    `phone` varchar(50), 
    `gender` varchar(10), 
    `birth_date` datetime, 
    `email` varchar(50), 
    `applicant_id` varchar(50), 
    `intake_session` varchar(50), 
    `intake_session2` varchar(50)
);
CREATE TABLE `student_billing` (
    `student_id` varchar(50), 
    `bill_no` varchar(50), 
    `bill_date` datetime, 
    `amount_total` float
);
CREATE TABLE `student_billing_detail` (
    `student_id` varchar(50), 
    `bill_no` varchar(50), 
    `amount` float, 
    `fee_id` varchar(50)
);
CREATE TABLE `student_course` (
    `student_id` varchar(60), 
    `course_id` varchar(50), 
    `period_root_id` varchar(50), 
    `intake_session` varchar(50), 
    `program_code` varchar(50), 
    `cyb_program_code` varchar(50)
);
CREATE TABLE `student_custom_data` (
    `student_id` varchar(50), 
    `data_id` varchar(50), 
    `data_value` varchar(100)
);
CREATE TABLE `student_marks` (
    `student_id` varchar(50), 
    `period_id` varchar(50), 
    `subject_id` varchar(50), 
    `part_id` varchar(50), 
    `mark_value` float
);
CREATE TABLE `student_marks_total` (
    `student_id` varchar(50), 
    `period_id` varchar(50), 
    `subject_id` varchar(50), 
    `mark_total` float, 
    `mark_grade` varchar(10)
);
CREATE TABLE `student_receipt` (
    `student_id` varchar(50), 
    `receipt_no` varchar(50), 
    `receipt_date` datetime, 
    `amount_total` float
);
CREATE TABLE `student_receipt_detail` (
    `student_id` varchar(50), 
    `receipt_no` varchar(50), 
    `fee_id` varchar(50), 
    `amount` varchar(50)
);
CREATE TABLE `student_status` (
    `student_id` varchar(60), 
    `period_id` varchar(50)
);
CREATE TABLE `student_subject` (
    `student_id` varchar(60), 
    `period_root_id` varchar(50), 
    `period_id` varchar(50), 
    `subject_id` varchar(50), 
    `course_id` varchar(50), 
    `program_code` varchar(50), 
    `register_id` varchar(50)
);
CREATE TABLE `study_course` (
    `course_id` varchar(50), 
    `course_code` varchar(50), 
    `course_name` varchar(200), 
    `faculty_id` varchar(50)
);
CREATE TABLE `subject` (
    `subject_id` varchar(50), 
    `subject_code` varchar(50), 
    `subject_title` varchar(100), 
    `subject_comment` varchar(255), 
    `subject_text` text, 
    `module_id` varchar(50)
);
CREATE TABLE `subject_reg_status` (
    `status_id` varchar(50), 
    `status_name` varchar(50), 
    `status_category` int, 
    `status_description` varchar(255), 
    `status_sequence` int
);
CREATE TABLE `tab` (
    `tab_id` varchar(100), 
    `tab_title` varchar(100), 
    `user_login` varchar(100), 
    `sequence` int, 
    `display_type` varchar(100)
);
CREATE TABLE `tab_template` (
    `tab_id` varchar(100), 
    `tab_title` varchar(100), 
    `user_login` varchar(100), 
    `sequence` int, 
    `display_type` varchar(100)
);
CREATE TABLE `teacher_comment` (
    `member_id` varchar(50), 
    `subject_id` varchar(50), 
    `comment` text
);
CREATE TABLE `temp_current_session` (
    `session_id` varchar(50)
);
CREATE TABLE `test` (
    `id` varchar(50), 
    `name` varchar(50), 
    `address` varchar(100)
);
CREATE TABLE `transcript_display` (
    `student_id` varchar(50), 
    `period_name` varchar(100), 
    `startDate` datetime, 
    `session_name` varchar(50), 
    `subject_code` varchar(50), 
    `subject_name` varchar(100), 
    `credit_hrs` int, 
    `total` float, 
    `point` float, 
    `grade_point` float, 
    `tot_credit_hrs` int, 
    `tot_grade_point` float, 
    `gpa` varchar(50), 
    `cum_credit_hrs` int, 
    `cum_grade_point` float, 
    `cgpa` varchar(50), 
    `program_code` varchar(50), 
    `grade` varchar(50)
);
CREATE TABLE `user_css` (
    `user_login` varchar(100), 
    `css_name` varchar(100)
);
CREATE TABLE `user_module` (
    `tab_id` varchar(100), 
    `user_login` varchar(100), 
    `module_id` varchar(100), 
    `sequence` int, 
    `module_custom_title` varchar(100), 
    `column_number` int
);
CREATE TABLE `user_module_template` (
    `tab_id` varchar(100), 
    `user_login` varchar(100), 
    `module_id` varchar(100), 
    `sequence` int, 
    `module_custom_title` varchar(100), 
    `column_number` int
);
CREATE TABLE `user_tracker` (
    `user_login` varchar(50), 
    `log_year` int, 
    `log_month` int, 
    `log_day` int, 
    `module_id` varchar(50), 
    `module_class` varchar(100), 
    `module_name` varchar(100), 
    `time12` varchar(50), 
    `time24` varchar(50), 
    `str_date` varchar(50), 
    `remote_add` varchar(50), 
    `log_date` datetime
);
CREATE TABLE `users` (
    `user_login` varchar(100), 
    `user_password` varchar(100), 
    `user_name` varchar(200), 
    `user_role` varchar(100)
);
CREATE TABLE `web_log` (
    `ip_address` varchar(50), 
    `counter` bigint, 
    `last_log_date` datetime, 
    `first_log_date` datetime
);
CREATE TABLE `web_log_init` (
    `init_date` datetime
);
CREATE TABLE `web_logger` (
    `remote_add` varchar(50), 
    `user_name` varchar(50), 
    `log_year` int, 
    `log_month` int, 
    `log_day` int, 
    `log_string` varchar(255)
);
CREATE TABLE `xml_module` (
    `module_id` varchar(100), 
    `xml` varchar(200), 
    `xsl` varchar(200)
);

