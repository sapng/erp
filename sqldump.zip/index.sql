ALTER TABLE student ADD INDEX(id);
ALTER TABLE session ADD INDEX(session_id);
ALTER TABLE intake_batch ADD INDEX(intake_session);
ALTER TABLE program ADD INDEX(program_code);
ALTER TABLE program ADD INDEX(course_id);