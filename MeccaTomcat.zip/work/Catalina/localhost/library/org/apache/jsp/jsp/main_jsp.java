package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class main_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<title></title>\r\n");
      out.write("</head>\r\n");
      out.write("<frameset framespacing=\"0\" border=\"false\" rows=\"37,*,20\" frameborder=\"0\">\r\n");
      out.write("\r\n");
      out.write("  <frame name=\"frame0\" src=\"head.jsp\" scrolling=\"no\"  marginwidth=\"0\" marginheight=\"0\" noresize>\r\n");
      out.write("  \r\n");
      out.write("  <frame name=\"frame1\" src=\"menu.jsp\" marginwidth=\"0\"  marginheight=\"0\">\r\n");
      out.write("  \r\n");
      out.write("  <frame name=\"frame2\" src=\"foot.jsp\" scrolling=\"no\"  marginwidth=\"0\" marginheight=\"0\" noresize>\r\n");
      out.write("  \r\n");
      out.write("  <noframes>\r\n");
      out.write("  <body>\r\n");
      out.write("\t<script language=\"JavaScript\">\r\n");
      out.write("\t<!--\r\n");
      out.write("\r\n");
      out.write("\t//Disable right mouse click Script\r\n");
      out.write("\t//By Maximus (maximus@nsimail.com)\r\n");
      out.write("\t//For full source code, visit http://www.dynamicdrive.com\r\n");
      out.write("\r\n");
      out.write("\tvar message=\"Function Disabled!\";\r\n");
      out.write("\t///////////////////////////////////\r\n");
      out.write("\tfunction clickIE() {if (document.all) {alert(message);return false;}}\r\n");
      out.write("\tfunction clickNS(e) {if \r\n");
      out.write("\t(document.layers||(document.getElementById&&!document.all)) {\r\n");
      out.write("\tif (e.which==2||e.which==3) {alert(message);return false;}}}\r\n");
      out.write("\tif (document.layers) \r\n");
      out.write("\t{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}\r\n");
      out.write("\telse{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}\r\n");
      out.write("\r\n");
      out.write("\tdocument.oncontextmenu=new Function(\"return false\")\r\n");
      out.write("\t// --> \r\n");
      out.write("\t</script>  \r\n");
      out.write("  <p>This page uses frames, but your browser doesn't support them.</p>\r\n");
      out.write("  </body>\r\n");
      out.write("  </noframes>\r\n");
      out.write("</frameset>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
