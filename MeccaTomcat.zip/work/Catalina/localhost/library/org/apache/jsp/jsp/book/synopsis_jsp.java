package org.apache.jsp.jsp.book;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import library.*;

public final class synopsis_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


void display(String txt, JspWriter out) throws java.io.IOException {
	
}

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");

String book_id = request.getParameter("book_id");
DataBank data = DataBank.getInstance();
String title = "";
String author = "";
String synopsis = "";
if ( !book_id.equals("") ) {
	Book book = data.getBookData().getBook(book_id);
	title = book.getTitle();
	author = book.getAuthor();
	synopsis = book.getSynopsis();
}

      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<title>:: ");
      out.print(title);
      out.write(" ::</title>\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"/library/library.css\" />\r\n");
      out.write("<body>\r\n");
      out.write("<form name=\"f\" method=\"post\">\r\n");
      out.write("<table width=\"100%\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr>\r\n");
      out.write("<td><b>");
      out.print(title);
      out.write("</b><br>&nbsp;&nbsp;by ");
      out.print(author);
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
      out.write("<tr>\r\n");
      out.write("<td><b>Synopsis </b>-\r\n");
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
      out.write("<tr>\r\n");
      out.write("<td>\r\n");
      out.write("<textarea cols=\"60\" rows=\"15\" readonly>\r\n");
      out.print(synopsis);
      out.write("\r\n");
      out.write("</textarea>\r\n");
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
      out.write("<tr>\r\n");
      out.write("<td align=\"center\">\r\n");
      out.write("<input type=\"button\" value=\"Close\" onclick=\"self.close();true;\">\r\n");
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("<script>\r\n");
      out.write("</script>\r\n");
      out.write("</html>\r\n");
      out.write('\r');
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
