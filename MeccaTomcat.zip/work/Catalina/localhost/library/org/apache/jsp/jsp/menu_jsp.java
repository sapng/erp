package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import library.*;

public final class menu_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");

DataBank data = DataBank.getInstance();

      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<title>Library</title>\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"/library/library.css\" />\r\n");
      out.write("<body>\r\n");
      out.write("<form name=\"f\" method=\"post\">\r\n");
      out.write("<!-- MODULE TITLE -->\r\n");
      out.write("<table width=\"100%\" cellpadding=\"1\" cellspacing=\"0\" border=1>\r\n");
      out.write("<tr><td class=\"head\">&nbsp;<img src=\"/library/img/pinkbullet.gif\" border=\"0\">\r\n");
      out.write("<font face=\"verdana\" size=\"2\"><b>&nbsp; :: Main Menu</b></font></td></tr></table>\r\n");
      out.write("<!-- END MODULE TITLE -->\r\n");
      out.write("</p>\r\n");
      out.write("\r\n");
      out.write("<table align=\"center\" width=\"80%\" cellpadding=\"1\" cellspacing=\"0\" border=0>\r\n");
      out.write("\r\n");
      out.write("<tr><td class=\"head\" width=\"10\"><img src=\"/library/img/book19.gif\" border=\"0\"></td>\r\n");
      out.write("<td class=\"head\">\r\n");
      out.write("Circulation\r\n");
      out.write("</td></tr>\r\n");
      out.write("\r\n");
      out.write("<tr><td width=\"10\"></td><td><a href=\"out/getmemberid.jsp\">:: Member check OUT book</a></td></tr>\r\n");
      out.write("<tr><td width=\"10\"></td><td><a href=\"in/getcode.jsp\">:: Member check IN book</a></td></tr>\r\n");
      out.write("<tr><td width=\"10\"></td><td><a href=\"loanhist/getmemberid.jsp\">:: Loans information</a></td></tr>\r\n");
      out.write("\r\n");
      out.write("<tr><td colspan=\"2\"><br></td></tr>\r\n");
      out.write("<tr><td class=\"head\" width=\"10\"><img src=\"/library/img/books.gif\" border=\"0\"></td>\r\n");
      out.write("<td class=\"head\">Catalogue</td></tr>\r\n");
      out.write("\r\n");
      out.write("<tr><td width=\"10\"></td><td><a href=\"catalogue/browse.jsp\">:: Search the catalogue</a></td></tr>\r\n");
      out.write("\r\n");
      out.write("<tr><td colspan=\"2\"><br></td></tr>\r\n");
      out.write("<tr><td class=\"head\" width=\"10\"><img src=\"/library/img/book17.gif\" border=\"0\"></td>\r\n");
      out.write("<td class=\"head\">Inventory Acquisitions</td></tr>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<tr><td width=\"10\"></td><td><a href=\"book/menuadd.jsp\">:: Add data into inventory (Titles, ISBNs or copies)</a></td></tr>\r\n");
      out.write("<tr><td width=\"10\"></td><td><a href=\"book/browse.jsp\">:: Browse items in inventory (To modify or delete)</a></td></tr>\r\n");
      out.write("\r\n");
      out.write("<tr><td colspan=\"2\"><br></td></tr>\r\n");
      out.write("<tr><td class=\"head\" width=\"10\"><img src=\"/library/img/members.gif\" border=\"0\"></td>\r\n");
      out.write("<td class=\"head\">Members Records Management</td></tr>\r\n");
      out.write("\r\n");
      out.write("<tr><td width=\"10\"></td><td><a href=\"member/addform.jsp\">:: Add new member</a></td></tr>\r\n");
      out.write("<tr><td width=\"10\"></td><td><a href=\"member/browse.jsp\">:: Find or browse members (To modify or delete)</a></td></tr>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<tr><td colspan=\"2\"><br></td></tr>\r\n");
      out.write("\r\n");
      out.write("</table>\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("<script>\r\n");
      out.write("</script>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
