package org.apache.jsp.jsp.catalogue;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import library.*;

public final class loadlist_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");

String sort_book = "title";
if ( request.getParameter("sort_book") != null ) {
	sort_book = request.getParameter("sort_book");	
	session.setAttribute("sort_book", sort_book);
} else {
	sort_book = (String) session.getAttribute("sort_book");
}
if ( sort_book == null ) sort_book = "title";

//search parameter
if ( request.getParameter("title") != null ) session.setAttribute("title", request.getParameter("title"));
if ( request.getParameter("author") != null ) session.setAttribute("author", request.getParameter("author"));
if ( request.getParameter("keywords") != null ) session.setAttribute("keywords", request.getParameter("keywords"));

String title_comparator = "AND";
String author_comparator = "AND";
String keywords_comparator = "AND";
byte byte_title = BookData.COMPARATOR_AND;
byte byte_author = BookData.COMPARATOR_AND;
byte byte_keywords = BookData.COMPARATOR_AND;

if ( request.getParameter("title_comparator") != null ) title_comparator = "OR";
if ( request.getParameter("author_comparator") != null ) author_comparator = "OR";
if ( request.getParameter("keywords_comparator") != null ) keywords_comparator = "OR";

if (title_comparator.equals("OR")) byte_title = BookData.COMPARATOR_OR;
if (author_comparator.equals("OR")) byte_author = BookData.COMPARATOR_OR;
if (keywords_comparator.equals("OR")) byte_keywords = BookData.COMPARATOR_OR;

session.setAttribute("title_comparator", title_comparator);
session.setAttribute("author_comparator", author_comparator);
session.setAttribute("keywords_comparator", keywords_comparator);

String title = (String) session.getAttribute("title");
String author = (String) session.getAttribute("author");
String keywords = (String) session.getAttribute("keywords");

Object[] books = null;

//start item no
int item_no = 0;
if ( session.getAttribute("book_list_no") != null ) {
	item_no = Integer.parseInt((String) session.getAttribute("book_list_no"));
}

//determine if new searching has been invoked

if ( request.getParameter("title") != null ) {
	item_no = 0; //this is new criteria, so start again
}


BookData data = BookData.getInstance();
data.setFilterComparator(byte_title, byte_author, byte_keywords);
//books = data.filterBooks(title, author, keywords).toArray();



if ( sort_book.equals("title") ) {
	books = data.filterTitleSortedBooks(title, author, keywords).toArray();
} else if ( sort_book.equals("author") ) {
	books = data.filterAuthorSortedBooks(title, author, keywords).toArray();
}



session.setAttribute("books", books);
response.sendRedirect("listbooks.jsp?item=" + item_no);


      out.write('\r');
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
