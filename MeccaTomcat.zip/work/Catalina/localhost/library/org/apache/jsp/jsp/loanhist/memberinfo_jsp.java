package org.apache.jsp.jsp.loanhist;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import library.*;

public final class memberinfo_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


String display(double d) {
	return new java.text.DecimalFormat("0.00").format(d);	
}

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");

String login = request.getParameter("login");
Member member = MemberData.getInstance().findByLogin(login);
if ( member == null ) {
	response.sendRedirect("membernotfound.jsp");
} else {
	session.setAttribute("member", member);
    List oList = LoanData.getInstance().getLoans(member.getId());
    List hList = LoanHistoryData.getInstance().getLoans(member.getId());
    int osize = oList.size();
    int hsize = hList.size();
    Iterator outs = oList.iterator();
	Iterator hists = hList.iterator();
	BookData bookdata = BookData.getInstance();

      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<title>Library</title>\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"/library/library.css\" />\r\n");
      out.write("<body>\r\n");
      out.write("<form name=\"f\" method=\"post\" action=\"javascript:add_loan()\">\r\n");
      out.write("<!-- MODULE TITLE -->\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td class=\"head\" width=\"10\"><img src=\"/library/img/pinkbullet.gif\" border=\"0\"></td>\r\n");
      out.write("<td class=\"head\">\r\n");
      out.write("<font face=\"verdana\" size=\"2\"><b>\r\n");
      out.write("&nbsp; ::: Member's loan information : \r\n");
      out.write("</b></font></td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("<!-- END MODULE TITLE -->\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td align=\"right\">\r\n");
      out.write("<input type=\"button\" value=\"Reload\" onclick=\"reload()\">\r\n");
      out.write("<input type=\"button\" value=\"Back\" onclick=\"document.location = 'getmemberid.jsp'\">\r\n");
      out.write("</td></tr>\r\n");
      out.write("</table>\r\n");
      out.write("</p>\r\n");
      out.write("\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td class=\"head\"><b>");
      out.print(member.getName());
      out.write(' ');
      out.write('/');
      out.write(' ');
      out.print(member.getIcno());
      out.write(' ');
      out.write('/');
      out.write(' ');
      out.print(member.getLogin());
      out.write("</b></td></tr>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("<!-- OUTSTANDING LOANS -->\r\n");
{
      out.write("\r\n");
      out.write("    \r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td class=\"head\"><b>Loans outstanding : ");
      out.print(osize);
      out.write(" Records</b></td></tr>\r\n");
      out.write("</table>    \r\n");
      out.write("\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"1\" bgcolor=\"silver\">\r\n");
      out.write("<tr>\r\n");
      out.write("<td bgcolor=\"lightgrey\">CN</td>\r\n");
      out.write("<td bgcolor=\"lightgrey\">Title</td>\r\n");
      out.write("<td bgcolor=\"lightgrey\">Out</td>\r\n");
      out.write("<td bgcolor=\"lightgrey\">Due</td>\r\n");
      out.write("<td bgcolor=\"lightgrey\">Days<br>Left</td>\r\n");
      out.write("</tr>\r\n");

while ( outs.hasNext() ) {
	Loan loan = (Loan) outs.next();
	Book book = bookdata.getBook(loan.getBookId());	
	Item item = bookdata.getItem(loan.getBookId(), loan.getItemId());
	Copy copy = bookdata.getCopy(loan.getBookId(), loan.getItemId(), loan.getCopyId());
	

	SimpleDate outdate = loan.getOutDate();
	SimpleDate duedate = loan.getDueDate();

	long diff1 = duedate.getDaysDiff(outdate);
	long diff2 = new SimpleDate().getDaysDiff(outdate);
	if ( diff2 < 0 ) diff2 = 0;
	long daysleft = diff1 - diff2;
	

      out.write("\r\n");
      out.write("<tr>\r\n");
      out.write("<td bgcolor=\"white\">");
      out.print(copy.getCode());
      out.write("</td>\r\n");
      out.write("<td bgcolor=\"white\">");
      out.print(book.getTitle());
      out.write("<br>by ");
      out.print(book.getAuthor());
      out.write("</td>\r\n");
      out.write("<td bgcolor=\"white\" align=\"center\">");
      out.print(outdate.getDMY());
      out.write("</td>\r\n");
      out.write("<td bgcolor=\"white\" align=\"center\">\r\n");
if ( daysleft <= 0 ) {
      out.write("\r\n");
      out.write("<font color=\"red\">");
      out.print(duedate.getDMY());
      out.write('\r');
      out.write('\n');
} else {
      out.write('\r');
      out.write('\n');
      out.print(duedate.getDMY());
      out.write('\r');
      out.write('\n');
}
      out.write("\r\n");
      out.write("</td>\r\n");
      out.write("<td bgcolor=\"white\" align=\"center\">\r\n");
if ( daysleft <= 0 ) {
      out.write("\r\n");
      out.write("<font color=\"red\">");
      out.print(daysleft);
      out.write("</font>\r\n");
} else {
      out.write('\r');
      out.write('\n');
      out.print(daysleft);
      out.write('\r');
      out.write('\n');
}
      out.write("\r\n");
      out.write("</td>\r\n");
      out.write("</tr>\r\n");

}

      out.write("\r\n");
      out.write("</table>\r\n");
}
      out.write("\r\n");
      out.write("<!-- END OF OUTSTANDING LOANS -->\r\n");
      out.write("\r\n");
      out.write("<!-- LOANS HISTORY -->\r\n");
{
      out.write("\r\n");
      out.write("    \r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td class=\"head\"><b>Loans history : ");
      out.print(hsize);
      out.write(" Records</b></td></tr>\r\n");
      out.write("</table>    \r\n");
      out.write("    \r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"1\" bgcolor=\"silver\">\r\n");
      out.write("<tr>\r\n");
      out.write("<td bgcolor=\"lightgrey\" rowspan=\"2\">CN</td>\r\n");
      out.write("<td bgcolor=\"lightgrey\" rowspan=\"2\">Title</td>\r\n");
      out.write("<td bgcolor=\"lightgrey\" rowspan=\"2\">D-M-Y</td>\r\n");
      out.write("<td bgcolor=\"lightgrey\" rowspan=\"2\">Days Late</td>\r\n");
      out.write("<td bgcolor=\"lightgrey\" align=\"center\" colspan=\"3\">Fine</td>\r\n");
      out.write("</tr>\r\n");
      out.write("<tr>\r\n");
      out.write("<td bgcolor=\"lightgrey\" align=\"center\">A</td>\r\n");
      out.write("<td bgcolor=\"lightgrey\" align=\"center\">P</td>\r\n");
      out.write("<td bgcolor=\"lightgrey\" align=\"center\">W</td>\r\n");
      out.write("</tr>\r\n");

while ( hists.hasNext() ) {
	Loan loan = (Loan) hists.next();
	Book book = bookdata.getBook(loan.getBookId());	
	Item item = bookdata.getItem(loan.getBookId(), loan.getItemId());
	Copy copy = bookdata.getCopy(loan.getBookId(), loan.getItemId(), loan.getCopyId());
	
	SimpleDate duedate = loan.getDueDate();
	SimpleDate indate = loan.getInDate();

	long dayslate = indate.getDaysDiff(duedate);
	

      out.write("\r\n");
      out.write("<tr>\r\n");
      out.write("<td bgcolor=\"white\">\r\n");
      out.write("<a href=\"javascript:edit(");
      out.print(loan.getBookId());
      out.write(',');
      out.write(' ');
      out.print(loan.getItemId());
      out.write(',');
      out.write(' ');
      out.print(loan.getCopyId());
      out.write(")\" onmouseover=\"window.status=''; return true;\">\r\n");
      out.print(copy.getCode());
      out.write("</a></td>\r\n");
      out.write("<td bgcolor=\"white\">\r\n");
      out.write("<a href=\"javascript:edit(");
      out.print(loan.getBookId());
      out.write(',');
      out.write(' ');
      out.print(loan.getItemId());
      out.write(',');
      out.write(' ');
      out.print(loan.getCopyId());
      out.write(")\" onmouseover=\"window.status=''; return true;\">\r\n");
      out.print(book.getTitle());
      out.write("<br>by ");
      out.print(book.getAuthor());
      out.write("</a></td>\r\n");
      out.write("<td bgcolor=\"white\">\r\n");
      out.write("<a href=\"javascript:edit(");
      out.print(loan.getBookId());
      out.write(',');
      out.write(' ');
      out.print(loan.getItemId());
      out.write(',');
      out.write(' ');
      out.print(loan.getCopyId());
      out.write(")\" onmouseover=\"window.status=''; return true;\">\r\n");
      out.write("Out :");
      out.print(loan.getOutDate().getDMY());
      out.write("<br>\r\n");
      out.write("Due :");
      out.print(loan.getDueDate().getDMY());
      out.write("<br>\r\n");
      out.write("In  :");
      out.print(loan.getInDate().getDMY());
      out.write("<br>\r\n");
      out.write("</a></td>\r\n");
      out.write("\r\n");
      out.write("<td bgcolor=\"white\" align=\"center\">\r\n");
if ( dayslate > 0 ) {
      out.write("\r\n");
      out.write("\r\n");
      out.write("<a href=\"javascript:edit(");
      out.print(loan.getBookId());
      out.write(',');
      out.write(' ');
      out.print(loan.getItemId());
      out.write(',');
      out.write(' ');
      out.print(loan.getCopyId());
      out.write(")\" onmouseover=\"window.status=''; return true;\">\r\n");
      out.print(dayslate);
      out.write(" days</a>\r\n");
      out.write("\r\n");
} else {
      out.write("\r\n");
      out.write("-\r\n");
}
      out.write("\r\n");
      out.write("</td>\r\n");
      out.write(" \r\n");
      out.write("<td bgcolor=\"white\" align=\"center\">\r\n");
      out.write("<a href=\"javascript:edit(");
      out.print(loan.getBookId());
      out.write(',');
      out.write(' ');
      out.print(loan.getItemId());
      out.write(',');
      out.write(' ');
      out.print(loan.getCopyId());
      out.write(")\" onmouseover=\"window.status=''; return true;\">\r\n");
      out.print(display(loan.getFineAssessed()));
      out.write("</a></td>\r\n");
      out.write("<td bgcolor=\"white\" align=\"center\">\r\n");
      out.write("<a href=\"javascript:edit(");
      out.print(loan.getBookId());
      out.write(',');
      out.write(' ');
      out.print(loan.getItemId());
      out.write(',');
      out.write(' ');
      out.print(loan.getCopyId());
      out.write(")\" onmouseover=\"window.status=''; return true;\">\r\n");
      out.print(display(loan.getFinePaid()));
      out.write("</a></td>\r\n");
      out.write("<td bgcolor=\"white\" align=\"center\">\r\n");
      out.write("<a href=\"javascript:edit(");
      out.print(loan.getBookId());
      out.write(',');
      out.write(' ');
      out.print(loan.getItemId());
      out.write(',');
      out.write(' ');
      out.print(loan.getCopyId());
      out.write(")\" onmouseover=\"window.status=''; return true;\">\r\n");
      out.print(display(loan.getFineWaived()));
      out.write("</a></td>\r\n");
      out.write("</tr>\r\n");

}

      out.write("\r\n");
      out.write("</table>\r\n");
}
      out.write("\r\n");
      out.write("<!-- END OF LOAN HISTORY -->\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<input type=\"hidden\" name=\"login\" value=\"");
      out.print(login);
      out.write("\">\r\n");
      out.write("<input type=\"hidden\" name=\"bookid\">\r\n");
      out.write("<input type=\"hidden\" name=\"itemid\">\r\n");
      out.write("<input type=\"hidden\" name=\"copyid\">\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("<script>\r\n");
      out.write("function edit(id1, id2, id3) {\r\n");
      out.write("\tdocument.f.bookid.value = id1;\r\n");
      out.write("\tdocument.f.itemid.value = id2;\r\n");
      out.write("\tdocument.f.copyid.value = id3;\r\n");
      out.write("\tdocument.f.action = \"edit.jsp\";\r\n");
      out.write("\tdocument.f.submit();\r\n");
      out.write("}\r\n");
      out.write("function reload() {\r\n");
      out.write("\tdocument.f.action = \"memberinfo.jsp\";\r\n");
      out.write("\tdocument.f.submit();\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("</html>\r\n");
      out.write("\r\n");

}

      out.write('\r');
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
