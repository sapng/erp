package org.apache.jsp.jsp.member;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import library.*;

public final class loadlist_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");

MemberData data = MemberData.getInstance();
Object[] members = null;

//start item no
int item_no = 0;
if ( session.getAttribute("member_list_no") != null ) {
	item_no = Integer.parseInt((String) session.getAttribute("member_list_no"));
}

if ( request.getParameter("name") != null ) {
	session.setAttribute("name", request.getParameter("name"));
	item_no = 0; //this is new criteria, so start again
}

if ( session.getAttribute("name") != null ) {	
	if ( request.getParameter("type") != null ) {
		session.setAttribute("type", request.getParameter("type"));
	}
	String type = (String) session.getAttribute("type");
	if ( type == null ) type = "0";
	byte browsetype = 0;
	if ( type.equals("1") ) browsetype = 1;
	if ( type.equals("2") ) browsetype = 2;
	members = data.getMembers((String) session.getAttribute("name"), browsetype).toArray();
} else {
	members = data.getMembers().toArray();
}

session.setAttribute("members", members);
session.setAttribute("mode", "edit");
response.sendRedirect("list.jsp?item=" + item_no);

      out.write('\r');
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
