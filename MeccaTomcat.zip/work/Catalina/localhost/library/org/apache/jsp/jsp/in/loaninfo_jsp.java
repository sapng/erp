package org.apache.jsp.jsp.in;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import library.*;

public final class loaninfo_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");

String code = request.getParameter("code");
String copy_id = "";
String title = "";
String author = "";
String member_name = "";
String member_id = "";
String out_date = "";
String due_date = "";
String in_date = "";
long dayslate = 0;
boolean success = true;
String error = "";

try {
	LoanInfo info = LoanData.getInstance().findCopyByCode(code);
	if ( info != null ) {
		BookInfo bookinfo = info.getBookInfo();
		Book book = bookinfo.getBook();
		Item item = bookinfo.getItem();
		Copy copy = bookinfo.getCopy();
		Loan loan = info.getLoan();
		Member member = MemberData.getInstance().getMember(loan.getMemberId());
		code = copy.getCode();
		title = book.getTitle();
		copy_id = copy.getId();
		author = book.getAuthor();
		member_name = member.getName();
		member_id = member.getLogin();
		out_date = loan.getOutDate().getDMY();
		due_date = loan.getDueDate().getDMY();
		
		in_date = new SimpleDate().getDMY();
		
		dayslate = new SimpleDate().getDaysDiff(loan.getDueDate());			
		
		session.setAttribute("loan", loan);
		
	} else {
		success = false;
		error = "The book may NOT be on loan status.";	
		//---
		//anyway set the onloan status to false
		BookInfo bookinfo = BookData.getInstance().findByCode(code);
		if ( bookinfo != null ) {
			BookData.getInstance().setOnLoan(bookinfo.getCopy(), false);
		}
		//---
	}
} catch ( java.io.IOException e ) {
	success = false;
	error = e.getMessage();
}

      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<title>Library</title>\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"/library/library.css\" />\r\n");
      out.write("<body>\r\n");
      out.write("<form name=\"f\" method=\"post\">\r\n");
      out.write("<!-- MODULE TITLE -->\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td class=\"head\" width=\"10\"><img src=\"/library/img/pinkbullet.gif\" border=\"0\"></td>\r\n");
      out.write("<td class=\"head\">\r\n");
      out.write("<font face=\"verdana\" size=\"2\"><b>\r\n");
      out.write("&nbsp; ::: Check IN book :\r\n");
      out.write("</b></font></td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("<!-- END MODULE TITLE -->\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td align=\"right\"><input type=\"button\" value=\"Back\" onclick=\"back()\"></td></tr>\r\n");
      out.write("</table>\r\n");
if (success) {
      out.write("\r\n");
      out.write("\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td class=\"head\">Call No : <b>");
      out.print(code);
      out.write("</b></td></tr>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("<table cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td></td><td><b>");
      out.print(title);
      out.write("</b></td></tr>\r\n");
      out.write("<tr><td></td><td><b>");
      out.print(author);
      out.write("</b></td></tr>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td class=\"head\">On loan to this member :</td></tr>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("<table cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td>Name </td><td>: <b>");
      out.print(member_name);
      out.write("</b></td></tr>\r\n");
      out.write("<tr><td>Member ID </td><td>: <b>");
      out.print(member_id);
      out.write("</b></td></tr>\r\n");
      out.write("<tr><td>Out date </td><td>: <b>");
      out.print(out_date);
      out.write("</b></td></tr>\r\n");
      out.write("<tr><td>Due date </td><td>: <b>");
      out.print(due_date);
      out.write("</b></td></tr>\r\n");
      out.write("</table>\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td><hr></td></tr>\r\n");
      out.write("</table>\r\n");
      out.write("<table cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td>CHECK IN DATE </td><td>: <b>");
      out.print(in_date);
      out.write("</b>&nbsp;&nbsp;&nbsp;*You can change this date below.</td></tr>\r\n");
if ( dayslate > 0 ) {
      out.write("\r\n");
      out.write("<tr><td><font color=\"red\">Days late </font></td><td>: <font color=\"red\"><b>");
      out.print(dayslate);
      out.write(" days</b></font></td></tr>\r\n");
      out.write("<tr><td>Fine Assessed</td><td>: RM <input name=\"fine_assessed\" size=\"10\"></td></tr>\r\n");
      out.write("<tr><td>Fine Paid</td><td>: RM <input name=\"fine_paid\" size=\"10\"></td></tr>\r\n");
      out.write("\r\n");
}
      out.write("\r\n");
      out.write("</table>\r\n");
      out.write("</p>\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td align=\"center\" class=\"head\">Change check IN date :\r\n");
      out.write("<input name=\"in_date\" value=\"");
      out.print(in_date);
      out.write("\" size=\"10\"> :: \r\n");
      out.write("<input type=\"button\" value=\"CHECK IN\" onclick=\"check_in()\"></td></tr>\r\n");
      out.write("</table>\r\n");
} else {
      out.write("\r\n");
      out.write("An error has occured while retreiving data.<br>\r\n");
      out.write("The error desciption is: <b>");
      out.print(error );
      out.write("</b>\r\n");
}
      out.write("\r\n");
      out.write("<input type=\"hidden\" name=\"copy_id\" value=\"");
      out.print(copy_id);
      out.write("\">\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("<script>\r\n");
      out.write("function back() {\r\n");
      out.write("\tdocument.f.action = \"getcode.jsp\";\r\n");
      out.write("\tdocument.f.submit();\r\n");
      out.write("}\r\n");
      out.write("function check_in() {\r\n");
      out.write("\tif ( confirm(\"Check in this copy ?\") ) {\r\n");
      out.write("\t\tdocument.f.action = \"checkin.jsp\";\r\n");
      out.write("\t\tdocument.f.submit();\t\r\n");
      out.write("\t} else {\r\n");
      out.write("\t\tback();\t\r\n");
      out.write("\t}\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
