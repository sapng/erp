package org.apache.jsp.jsp.book;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import library.*;

public final class addform_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");

String mode = "add";
if ( session.getAttribute("mode") != null ) mode = (String) session.getAttribute("mode");
String book_id = request.getParameter("book_id");
DataBank data = DataBank.getInstance();
String title = "";
String author = "";
String synopsis = "";
String module_title = "Add New Title";
if ( !book_id.equals("") ) {
	Book book = data.getBookData().getBook(book_id);
	title = book.getTitle();
	author = book.getAuthor();
	synopsis = book.getSynopsis();
	module_title = "Edit Title";
}

      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<title>Library</title>\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"/library/library.css\" />\r\n");
      out.write("<body>\r\n");
      out.write("<form name=\"f\" method=\"post\">\r\n");
      out.write("<!-- MODULE TITLE -->\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td class=\"head\" width=\"10\"><img src=\"/library/img/pinkbullet.gif\" border=\"0\"></td>\r\n");
      out.write("<td class=\"head\">\r\n");
      out.write("<font face=\"verdana\" size=\"2\"><b>\r\n");
      out.write("&nbsp; ::: ");
      out.print(module_title);
      out.write("\r\n");
      out.write("</b></font></td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("<!-- END MODULE TITLE -->\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\" >\r\n");
      out.write("<tr>\r\n");
      out.write("<td class=\"label\">Title :</td><td><input name=\"title\" size=\"80\" value=\"");
      out.print(title);
      out.write("\"></td>\r\n");
      out.write("</tr>\r\n");
      out.write("<tr>\r\n");
      out.write("<td class=\"label\">Author(s) :</td><td><input name=\"author\" size=\"80\" value=\"");
      out.print(author);
      out.write("\"></td>\r\n");
      out.write("</tr>\r\n");
      out.write("<tr>\r\n");
      out.write("<td class=\"label\">Synopsis :</td><td><textarea name=\"synopsis\" cols=\"80\" rows=\"15\">");
      out.print(synopsis);
      out.write("</textarea></td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr>\r\n");
      out.write("<td align=\"center\">\r\n");
      out.write("<input type=\"button\" value=\"Cancel\" onclick=\"back()\">\r\n");
if ( !book_id.equals("") ) {
      out.write("\r\n");
      out.write("<input type=\"button\" value=\"Delete\" onclick=\"delete_book()\">\r\n");
}
      out.write("\r\n");
      out.write("<input type=\"button\" value=\"Save\" onclick=\"save_book()\">\r\n");
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("<input type=\"hidden\" name=\"book_id\" value=\"");
      out.print(book_id);
      out.write("\">\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("<script>\r\n");
      out.write("function save_book() {\r\n");
      out.write("\tdocument.f.action = \"savebook.jsp\";\r\n");
      out.write("\tdocument.f.submit();\r\n");
      out.write("}\r\n");
      out.write("function delete_book() {\r\n");
      out.write("\tdocument.f.action = \"confirmdelete.jsp\";\r\n");
      out.write("\tdocument.f.submit();\r\n");
      out.write("}\r\n");
      out.write("function back() {\r\n");
      out.write("\t");
if ( mode.equals("add") ) {
      out.write("\r\n");
      out.write("\tdocument.f.action = \"menuadd.jsp\";\r\n");
      out.write("\t");
} else {
      out.write("\r\n");
      out.write("\tdocument.f.action = \"listbooks.jsp\";\r\n");
      out.write("\t");
}
      out.write("\r\n");
      out.write("\tdocument.f.submit();\t\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
