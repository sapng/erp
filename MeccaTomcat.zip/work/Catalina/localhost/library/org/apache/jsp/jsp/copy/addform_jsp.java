package org.apache.jsp.jsp.copy;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import library.*;

public final class addform_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");

String copy_id = request.getParameter("copy_id");
DataBank data = DataBank.getInstance();
Book book = (Book) session.getAttribute("book");
Item item = (Item) session.getAttribute("item");
String code = "";
String module_title = "Add New Copy";
if ( !copy_id.equals("") ) {
	Copy copy = data.getBookData().getCopy(book.getId(), item.getId(), copy_id);
	code = copy.getCode();
	module_title = "Edit Copy";
}

      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<title>Library</title>\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"/library/library.css\" />\r\n");
      out.write("<body>\r\n");
      out.write("<form name=\"f\" method=\"post\">\r\n");
      out.write("<!-- MODULE TITLE -->\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr><td class=\"head\" width=\"10\"><img src=\"/library/img/pinkbullet.gif\" border=\"0\"></td>\r\n");
      out.write("<td class=\"head\">\r\n");
      out.write("<font face=\"verdana\" size=\"2\"><b>\r\n");
      out.write("&nbsp; ::: ");
      out.print(module_title);
      out.write("\r\n");
      out.write("</b></font></td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("<!-- END MODULE TITLE -->\r\n");
      out.write("<table width=\"600\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr>\r\n");
      out.write("<td width=\"10\">\r\n");
      out.write("<img src=\"/library/img/book.gif\" border=\"0\">\r\n");
      out.write("</td>\r\n");
      out.write("<td><b>");
      out.print(book.getTitle());
      out.write("</b> <br>&nbsp;&nbsp by ");
      out.print(book.getAuthor());
      out.write("</td></tr>\r\n");
      out.write("<tr>\r\n");
      out.write("<td width=\"10\">\r\n");
      out.write("<img src=\"/library/img/book.gif\" border=\"0\">\r\n");
      out.write("</td>\r\n");
      out.write("<td>\r\n");
      out.write("ISBN : ");
      out.print(item.getIsbn());
      out.write("<br>\r\n");
      out.write("Language : ");
      out.print(item.getLanguage());
      out.write("<br>\r\n");
      out.write("Cover : ");
      out.print(item.getCover());
      out.write("\r\n");
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("</p>\r\n");
      out.write("<br>\r\n");
      out.write("<table width=\"300\" cellpadding=\"1\" cellspacing=\"0\" >\r\n");
      out.write("<tr>\r\n");
      out.write("<td class=\"label\">Copy's code :</td><td><input name=\"code\" size=\"20\" value=\"");
      out.print(code);
      out.write("\"></td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("</p>\r\n");
      out.write("<table width=\"300\" cellpadding=\"1\" cellspacing=\"0\">\r\n");
      out.write("<tr>\r\n");
      out.write("<td align=\"center\">\r\n");
      out.write("<input type=\"button\" value=\"Cancel\" onclick=\"back()\">\r\n");
if ( !copy_id.equals("") ) {
      out.write("\r\n");
      out.write("<input type=\"button\" value=\"Delete\" onclick=\"delete_copy()\">\r\n");
}
      out.write("\r\n");
      out.write("<input type=\"button\" value=\"Save\" onclick=\"save_copy()\">\r\n");
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("<input type=\"hidden\" name=\"copy_id\" value=\"");
      out.print(copy_id);
      out.write("\">\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("<script>\r\n");
      out.write("function save_copy() {\r\n");
      out.write("\tdocument.f.action = \"savecopy.jsp\";\r\n");
      out.write("\tdocument.f.submit();\r\n");
      out.write("}\r\n");
      out.write("function delete_copy() {\r\n");
      out.write("\tdocument.f.action = \"confirmdelete.jsp\";\r\n");
      out.write("\tdocument.f.submit();\r\n");
      out.write("}\r\n");
      out.write("function back() {\r\n");
      out.write("\tdocument.f.action = \"listcopys.jsp\";\r\n");
      out.write("\tdocument.f.submit();\t\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
