package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class foot_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<html>\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"/library/library.css\" />\r\n");
      out.write("<body leftmargin=\"0\" topmargin=\"0\" onload=\"window.status='EasyLibrary -alpha-'; return true;\">\r\n");
      out.write("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"1\"><tr>\r\n");
      out.write("<td bgcolor=\"skyblue\">\r\n");
      out.write("<font face=\"verdana\" size=\"1\">\r\n");
      out.write("<b>EasyLibrary</b>\r\n");
      out.write("</font>\r\n");
      out.write("</td>\r\n");
      out.write("<td bgcolor=\"skyblue\" align=\"right\">\r\n");
      out.write("<font face=\"arial\" size=\"1\">\r\n");
      out.write("<!-- <a href=\"menu.jsp\" target=\"frame1\">Main</a> | -->\r\n");
      out.write("<a href=\"javascript:openHelp()\">\r\n");
      out.write("Help\r\n");
      out.write("</a>\r\n");
      out.write("</font>\r\n");
      out.write("</td>\r\n");
      out.write("</tr></table>\r\n");
      out.write("</body>\r\n");
      out.write("<script>\r\n");
      out.write("function openHelp() {\r\n");
      out.write("\tpopupWin = window.open('help.jsp', 'helpdoc', 'scrollbars,resizable,width=480,height=320');\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
