This module provide feature of Activity Management.
