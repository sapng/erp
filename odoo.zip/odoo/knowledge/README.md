[![Runbot Status](https://runbot.odoo-community.org/runbot/badge/flat/119/13.0.svg)](https://runbot.odoo-community.org/runbot/repo/github-com-oca-knowledge-118)
[![Build Status](https://travis-ci.org/OCA/knowledge.svg?branch=13.0)](https://travis-ci.org/OCA/knowledge)
[![codecov](https://codecov.io/gh/OCA/knowledge/branch/13.0/graph/badge.svg)](https://codecov.io/gh/OCA/knowledge)

Knowledge
=========

This project is meant to gather all community extensions of Odoo's knowledge and document management.

Here you should find all community modules that:

- implement means to structure knowledge
- provide access to knowledge/documents



Translation Status
------------------
[![Transifex Status](https://www.transifex.com/projects/p/OCA-knowledge-13-0/chart/image_png)](https://www.transifex.com/projects/p/OCA-knowledge-13-0)
