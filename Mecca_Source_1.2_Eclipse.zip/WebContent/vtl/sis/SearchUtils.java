package infusion.sis;

import java.io.*;
import java.util.*;
import infusion.sis.db.Db;
import infusion.sis.tools.*;
import org.merak.db.*;
import java.sql.*;

public class SearchUtils {

	public Hashtable getSearchByName(String value) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			Hashtable result = new Hashtable();
			Vector v = new Vector();
			{
				r.add("id");
				r.add("name");
				r.add("name", "%" + value + "%", "LIKE");
				sql = r.getSQLSelect("student", "name");
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					h.put("id", rs.getString("id"));
					h.put("name", rs.getString("name"));
					v.addElement(h);
				}
			}
			result.put("criteria", value);
			result.put("studentList", v);
			return result;
		} finally {
			if ( db != null ) db.close();
		}
	}	

}