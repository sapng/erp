/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.planner;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Collections;
import java.util.Hashtable;
import java.util.TimeZone;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.db.DbException;
import mecca.db.SQLRenderer;
import mecca.db.UniqueID;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class PlannerModule extends mecca.portal.velocity.VTemplate {
	
	private String timeZoneId = "";
	boolean isLastPage = false;
	static int LIST_ROWS = 20;
	
	boolean standAlone = true;
	
	private static String[] month_name = {"January", "February", "March", "April", "May", "Jun", "July", "August", "September", "October", "November", "December"};
	private static String[] day_name = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
	private static String[] hour_name = {"12 AM", "1 AM", "2 AM", "3 AM", "4 AM", "5 AM", "6 AM", "7 AM", "8 AM", "9 AM", "10 AM", "11 AM",
							 							"12 PM", "1 PM", "2 PM", "3 PM", "4 PM", "5 PM", "6 PM", "7 PM", "8 PM", "9 PM", "10 PM", "11 PM"};
	
	public void setStandAlone(boolean b) {
	    standAlone = b;
	}
	
	public Template doTemplate() throws Exception {
		Template template = engine.getTemplate("vtl/schedule/list_task.vm");
		HttpSession session = request.getSession();
		
		String inCollabModule = session.getAttribute("inCollabModule") != null ? (String) session.getAttribute("inCollabModule") : "false";
		String subjectId = "";
		if ( "true".equals(inCollabModule) ) subjectId = getId();
		
		context.put("month_name", month_name);
		
		String action = !"".equals(getParam("planner_action")) ? getParam("planner_action"):"listmytask";

		if ( "addtask".equals(action) ) {
			template = engine.getTemplate("vtl/schedule/add_task.vm");		
		}
		else if ( "insert".equals(action) ) {
			doInsertTask(session, subjectId);	
			doListTask(session, subjectId);
			template = engine.getTemplate("vtl/schedule/list_task.vm");			
		}
		else if ( "listmytask".equals(action) ) {
			doListTask(session, subjectId);
			template = engine.getTemplate("vtl/schedule/list_task.vm");
		}
		else if ( "deletetask".equals(action) ) {
			doDeleteTask(session);	
			doListTask(session, subjectId);
			template = engine.getTemplate("vtl/schedule/list_task.vm");
		}
		else if ( "selectdate".equals(action) ) {
			doListTask(session, subjectId);
			template = engine.getTemplate("vtl/schedule/list_task.vm");	
		}
		else if ( "edittask".equals(action) ) {
			doEditTask(session);
			template = engine.getTemplate("vtl/schedule/edit_task.vm");	
		}
		else if ( "updatetask".equals(action) ) {
			doUpdateTask(session);
			doListTask(session, subjectId);
			template = engine.getTemplate("vtl/schedule/list_task.vm");	
		}		
		else if ( "goPreviousWeek".equals(action) ) {
			doListTask(session, subjectId, "prevweek");
			template = engine.getTemplate("vtl/schedule/list_task.vm");				
		}
		else if ( "goNextWeek".equals(action) ) {
			doListTask(session, subjectId, "nextweek");
			template = engine.getTemplate("vtl/schedule/list_task.vm");				
		}
		else if ( "goToday".equals(action) ) {
			doListTask(session, subjectId, "today");
			template = engine.getTemplate("vtl/schedule/list_task.vm");				
		}	
		else if ( "listUsers".equals(action) ) {
			prepareList(session);
			getRows(session, 1);
			template = engine.getTemplate("vtl/schedule/list_users.vm");	
		}	
		else if ( "goPage".equals(action) ) {
			int page = Integer.parseInt(getParam("pagenum"));
			getRows(session, page);
			session.setAttribute("page_number", Integer.toString(page));			
		}		
		else if ( "back".equals(action) ) {
			doListCurrentTask(session, subjectId);	
			template = engine.getTemplate("vtl/schedule/list_task.vm");	
		}
		else if ( "selectNames".equals(action) ) {
			String[] userids = request.getParameterValues("userids");
			context.put("inviteList", userids);
			doListCurrentTask(session, subjectId);	
			template = engine.getTemplate("vtl/schedule/list_task.vm");	
		}
				
		
		return template;		
	}

	
	private void doInsertTask(HttpSession session, String subjectid) throws Exception {
		if ( subjectid == null ) subjectid = "";
		Db db = null;
		Connection conn = null;
		String sql = "";
		String user = (String) session.getAttribute("_portal_login");
		String task_description = getParam("description");
		
		if ( "".equals(task_description.trim()) ) return;
		
		
		String year1 = getParam("year1");
		String month1 = getParam("month1");
		String day1 = getParam("day1");
		String hour1 = getParam("hour1");
		String minute1 = getParam("minute1");
		String hour2 = getParam("hour2");
		String minute2 = getParam("minute2");	
		int ispublic = !"".equals(getParam("public")) ? Integer.parseInt(getParam("public")) : 1;
		//String start_date = year1 + "-" + fmt(month1) + "-" + fmt(day1) + " " + fmt(hour1) + ":" + fmt(minute1) + ":00";		
		//String end_date = year1 + "-" + fmt(month1) + "-" + fmt(day1) + " " + fmt(hour2) + ":" + fmt(minute2) + ":00";
		String task_date = year1 + "-" + fmt(month1) + "-" + fmt(day1);
		
		String[] invitelist = request.getParameterValues("invitelist");
		
		//generate unique id
		String id = user.concat(Long.toString(UniqueID.get()));
		try {
			db = new Db();	
			conn = db.getConnection();
			Statement stmt = db.getStatement();
			
			conn.setAutoCommit(false);
			SQLRenderer r = new SQLRenderer();
			
			//task data
			{
				r.add("task_id", id);
				r.add("user_login", user);
				r.add("task_description", task_description);
				
				r.add("task_date", task_date);
				r.add("hour_start", Integer.parseInt(hour1));
				r.add("hour_end", Integer.parseInt(hour2));
				r.add("minute_start", Integer.parseInt(minute1));
				r.add("minute_end", Integer.parseInt(minute2));
				
				r.add("task_public", ispublic);
				r.add("subject_id", subjectid);
				sql = r.getSQLInsert("planner_task");
				
				//System.out.println(sql);
				
				stmt.executeUpdate(sql);
			}
			
			//invite list
			//delete first
			{
				sql = "DELETE FROM planner_task_invite WHERE task_id = '" + id + "' ";	
				stmt.executeUpdate(sql);
			}
			if ( invitelist != null ) {
				for ( int i=0; i < invitelist.length; i++ ) {
					r = new SQLRenderer();
					r.add("task_id", id);
					r.add("user_id", invitelist[i]);
					r.add("inviter_id", user);
					r.add("allow_edit", 0);
					sql = r.getSQLInsert("planner_task_invite");
					stmt.executeUpdate(sql);
				}
			}
			conn.commit();
			
		} catch ( DbException dbex ) {
			System.out.println( dbex.getMessage() );	
			throw dbex;		
		} catch ( SQLException ex ) {
			if ( conn != null ) {
				try {
					conn.rollback();	
				} catch ( SQLException rex ) {}
			}
			System.out.println( ex.getMessage() + sql);
			throw ex;
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	private String fmt(String s) {
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}
	
	private String strDate(int y, int m, int d) {
		String str = "" + y;
		if ( m < 10 ) str += "-0" + m;
		else str += "-" + m;
		if ( d < 10 ) str += "-0" + d;
		else str += "-" + d;
		return str;
	}
	
	private Vector getTaskVector(String user, String subjectid, int year1, int month1, int day1) throws Exception {
		Db db = null;
		String sql = "";
		Vector v = new Vector();
		
		String strdate = strDate(year1, month1, day1);
		//System.out.println("getTaskVector=" + strdate);		

		try {
			db = new Db();	
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			//get personal task
			if ( "".equals(subjectid ) )
			{
				r.add("task_id");
				r.add("task_description");
				
				r.add("hour_start");
				r.add("hour_end");
				r.add("minute_start");
				r.add("minute_end");
				
				r.add("task_public");
				
				r.add("user_login", user);
				r.add("subject_id", "");
				
				r.add("task_date", strdate);
				
				sql = r.getSQLSelect("planner_task");
				ResultSet rs = stmt.executeQuery(sql);

				while ( rs.next() ) {
					Hashtable task = new Hashtable();
					String task_id = rs.getString("task_id");
					String task_description = rs.getString("task_description");
					String task_public = rs.getString("task_public");
					
					int hour_start = rs.getInt("hour_start");
					int minute_start = rs.getInt("minute_start");
					int hour_end = rs.getInt("hour_end");
					int minute_end = rs.getInt("minute_end");
					
					String time_start = fmtTime(hour_start, minute_start);
					String time_end = fmtTime(hour_end, minute_end);
					
									
					task.put("task_id", task_id);
					task.put("task_description", putLineBreak(task_description));
					task.put("task_public", task_public);
					
					//required for sorting
					task.put("hour_start", new Integer(hour_start));
					task.put("hour_end", new Integer(hour_end));
					task.put("minute_start", new Integer(minute_start));
					task.put("minute_end", new Integer(minute_end));
	
					task.put("time_start", time_start);
					task.put("time_end", time_end);		
					
					task.put("inviter", "");
					task.put("canEdit", new Boolean(true));
					
					task.put("subject_code", "");
					task.put("subject_title", "");						
					
					v.addElement(task);
				}
			}
			
			//get community task
			if ( !"".equals(subjectid) )
			{
				r.clear();
				r.add("p.task_id");
				r.add("p.task_description");
				r.add("hour_start");
				r.add("hour_end");
				r.add("minute_start");
				r.add("minute_end");				
				
				r.add("p.task_public");
				r.add("p.user_login");
				r.add("u.user_name");				
				r.add("p.user_login", r.unquote("u.user_login"));

				//only for this subject
				r.add("p.subject_id", subjectid);
				r.add("p.subject_id", r.unquote("s.subject_id"));				
				//where this user enroll in
				r.add("s.member_id", user);
				r.add("s.status", "active");
				
				
				r.add("task_date", strdate);
								
				sql = r.getSQLSelect("planner_task p, member_subject s, users u");
				
				//System.out.println(sql);
				
				ResultSet rs = stmt.executeQuery(sql);

				while ( rs.next() ) {
					Hashtable task = new Hashtable();
					String task_id = rs.getString("task_id");
					String task_description = rs.getString("task_description");
					String task_public = rs.getString("task_public");
					String user_task = rs.getString("user_login");
					String user_name = rs.getString("user_name");
					int hour_start = rs.getInt("hour_start");
					int minute_start = rs.getInt("minute_start");
					int hour_end = rs.getInt("hour_end");
					int minute_end = rs.getInt("minute_end");
					
					String time_start = fmtTime(hour_start, minute_start);
					String time_end = fmtTime(hour_end, minute_end);
									
					task.put("task_id", task_id);
					task.put("task_description", putLineBreak(task_description));
					task.put("task_public", task_public);
					
					//required for sorting
					task.put("hour_start", new Integer(hour_start));
					task.put("hour_end", new Integer(hour_end));
					task.put("minute_start", new Integer(minute_start));
					task.put("minute_end", new Integer(minute_end));
	
					task.put("time_start", time_start);
					task.put("time_end", time_end);		
					
					task.put("inviter", user_name);
					if ( user.equals(user_task) )
						task.put("canEdit", new Boolean(true));
					else
						task.put("canEdit", new Boolean(false));
						
					task.put("subject_code", "");
					task.put("subject_title", "");						
					
					v.addElement(task);
				}
				
			} else {
				
				r.clear();
				r.add("task_id");
				r.add("task_description");
				//r.add("task_start_date");
				//r.add("task_end_date");				
				r.add("hour_start");
				r.add("hour_end");
				r.add("minute_start");
				r.add("minute_end");		
								
				r.add("task_public");
				r.add("p.user_login");
				r.add("u.user_name");				
				r.add("s.subject_code");
				r.add("s.subject_title");
				
				//for all subjects
				r.add("p.subject_id", r.unquote("ms.subject_id"));				
				//where this user enroll in
				r.add("ms.member_id", user);
				r.add("ms.status", "active");
				
				r.add("p.subject_id", r.unquote("ms.subject_id"));
				r.add("ms.subject_id", r.unquote("s.subject_id"));
				r.add("p.user_login", r.unquote("u.user_login"));
				
				r.add("task_date", strdate);
								
				sql = r.getSQLSelect("planner_task p, users u, member_subject ms, subject s");
				
				//System.out.println(sql);
				
				ResultSet rs = stmt.executeQuery(sql);

				while ( rs.next() ) {
					Hashtable task = new Hashtable();
					String task_id = rs.getString("task_id");
					String task_description = rs.getString("task_description");
					//String task_start_date = rs.getString("task_start_date");
					//String task_end_date = rs.getString("task_end_date");
					String task_public = rs.getString("task_public");
					String user_task = rs.getString("user_login");
					String user_name = rs.getString("user_name");
					int hour_start = rs.getInt("hour_start");
					int minute_start = rs.getInt("minute_start");
					int hour_end = rs.getInt("hour_end");
					int minute_end = rs.getInt("minute_end");
					String subject_code = rs.getString("subject_code");
					String subject_title = rs.getString("subject_title");
					
					String time_start = fmtTime(hour_start, minute_start);
					String time_end = fmtTime(hour_end, minute_end);
									
					task.put("task_id", task_id);
					task.put("task_description", putLineBreak(task_description));
					task.put("task_public", task_public);
					
					//required for sorting
					task.put("hour_start", new Integer(hour_start));
					task.put("hour_end", new Integer(hour_end));
					task.put("minute_start", new Integer(minute_start));
					task.put("minute_end", new Integer(minute_end));
	
					task.put("time_start", time_start);
					task.put("time_end", time_end);		
					
					task.put("inviter", "");
					if ( user.equals(user_task) )
						task.put("canEdit", new Boolean(true));
					else
						task.put("canEdit", new Boolean(false));
					
						
					task.put("subject_code", subject_code);
					task.put("subject_title", subject_title);
					v.addElement(task);
				}				
				
			}			
			//get from invite
			if ( "".equals(subjectid) )
			{
				r = new SQLRenderer();
				r.add("t.task_id AS id");
				r.add("t.task_description");
				//r.add("t.task_start_date");
				//r.add("t.task_end_date");
				r.add("t.task_public");
				r.add("u.user_name AS inviter_name");
				
				//r.add("task_date");
				r.add("hour_start");
				r.add("hour_end");
				r.add("minute_start");
				r.add("minute_end");	
								
			
				r.add("t.task_id", r.unquote("i.task_id"));
				r.add("i.inviter_id", r.unquote("u.user_login"));
				r.add("i.user_id", user);				
				
				
				r.add("task_date", strdate);				
				
				sql = r.getSQLSelect("planner_task t, planner_task_invite i, users u");
				ResultSet rs = stmt.executeQuery(sql);

				while ( rs.next() ) {
					Hashtable task = new Hashtable();
					String task_id = rs.getString("id"); 
					String task_description = rs.getString("task_description");
					String task_public = rs.getString("task_public");
					String inviter_name = rs.getString("inviter_name");
					int hour_start = rs.getInt("hour_start");
					int minute_start = rs.getInt("minute_start");
					int hour_end = rs.getInt("hour_end");
					int minute_end = rs.getInt("minute_end");
					
					String time_start = fmtTime(hour_start, minute_start);
					String time_end = fmtTime(hour_end, minute_end);
									
					task.put("task_id", task_id);
					task.put("task_description", putLineBreak(task_description));
					task.put("task_public", task_public);
					
					//required for sorting
					task.put("hour_start", new Integer(hour_start));
					task.put("hour_end", new Integer(hour_end));
					task.put("minute_start", new Integer(minute_start));
					task.put("minute_end", new Integer(minute_end));					
	
					task.put("time_start", time_start);
					task.put("time_end", time_end);		
					
					task.put("inviter", inviter_name);
					task.put("canEdit", new Boolean(false));
					
					task.put("subject_code", "");
					task.put("subject_title", "");						
					
					v.addElement(task);
				}

				Collections.sort(v, new TimeComparator());
				
			}
			
			return v;
			
		} catch ( DbException dbex ) {
			System.out.println( dbex.getMessage() );
			throw dbex;			
		} catch ( SQLException ex ) {
			System.out.println( ex.getMessage() + sql);
			throw ex;
		} finally {
			if ( db != null ) db.close();
		}	
	
	
	}
	
	private void doListTask(HttpSession session, String subjectid) throws Exception {
		doListTask(session, subjectid, "");
	}
	
	private void doListTask(HttpSession session, String subjectid, String go) throws Exception {
		
		//go = nextweek / prevweek
		
		String user = (String) session.getAttribute("_portal_login");
		
		int year1 = 0, month1 = 0, day1 = 0;
		java.util.Calendar calendar = "".equals(timeZoneId) ? 
									  new java.util.GregorianCalendar() :
									  new java.util.GregorianCalendar(TimeZone.getTimeZone(timeZoneId));
									  
		calendar.setTime(new java.util.Date());
		
		if ( !"today".equals(go) ) {
			year1 = !"".equals(getParam("year1")) ? Integer.parseInt(getParam("year1")) : calendar.get(Calendar.YEAR);
			month1 = !"".equals(getParam("month1")) ? Integer.parseInt(getParam("month1")) : calendar.get(Calendar.MONTH) + 1;
			day1 = !"".equals(getParam("day1")) ? Integer.parseInt(getParam("day1")) : calendar.get(Calendar.DAY_OF_MONTH);	
			if ( !"".equals(getParam("year1")) && !"".equals(getParam("month1")) && !"".equals(getParam("month1")) ) {
				calendar = new java.util.GregorianCalendar(year1, month1-1, day1);	
			}
		}
		
		if ( "nextweek".equals(go) ) {
			calendar.add(Calendar.DATE, 7);	
		}
		else if ( "prevweek".equals(go) ) {
			calendar.add(Calendar.DATE, -7);			
		}
		session.setAttribute("calendar", calendar);
		displayWeekly(session, calendar, subjectid);
		//determine whether this user teacher for this subject
		if ( !"".equals(subjectid) && userIsTeacher(user, subjectid) )
			context.put("allowAddTask", new Boolean(true));
		else
			context.put("allowAddTask", new Boolean(false));
	}
	
	private void doListCurrentTask(HttpSession session, String subjectid) throws Exception {
		String user = (String) session.getAttribute("_portal_login");
		int year1 = 0, month1 = 0, day1 = 0;
		java.util.Calendar calendar = (java.util.Calendar) session.getAttribute("calendar");
		displayWeekly(session, calendar, subjectid);
		//determine whether this user teacher for this subject
		if ( !"".equals(subjectid) && userIsTeacher(user, subjectid) )
			context.put("allowAddTask", new Boolean(true));
		else
			context.put("allowAddTask", new Boolean(false));
	}	
	
	
	private void displayWeekly(HttpSession session, java.util.Calendar calendar, String subjectid) throws Exception {
		String user = (String) session.getAttribute("_portal_login");
		int year1 = calendar.get(Calendar.YEAR);
		int month1 =calendar.get(Calendar.MONTH) + 1;
		int day1 = calendar.get(Calendar.DAY_OF_MONTH);	
		int day_week = calendar.get(Calendar.DAY_OF_WEEK);
		int max_day = calendar.getActualMaximum(Calendar.DAY_OF_MONTH );				
		
		Hashtable schedules = new Hashtable();
		Hashtable scheduleDates = new Hashtable();
		Hashtable scheduleDateValues = new Hashtable();
		
		int dy = day1, mn = month1, yr = year1, dw = day_week;
		
		for ( int i = 0; i < day_week - 1; i++ ) {
			int num = --dw;
			//System.out.print(num + " = ");
			if ( dy == 1 ) {
				mn--;
				
				if ( mn == 0 ) {
					mn = 12;
					yr--;
				}
									

				Calendar dummy = new java.util.GregorianCalendar(yr, mn-1, 1);
				int dummy_max = dummy.getActualMaximum(Calendar.DAY_OF_MONTH );
				dy = dummy_max;
				
				//System.out.println("backward 1st: " +dy + " - " + mn + " - " + yr);	
				String taskdate = mecca.util.DateTool.getDateFormatted(
								  (new java.util.GregorianCalendar(yr, mn-1, dy)).getTime());
								  		
				Vector tasklist = getTaskVector(user, subjectid, yr, mn, dy);
				schedules.put("d" + Integer.toString(num), tasklist);

				
				scheduleDates.put("d" + Integer.toString(num), taskdate);
				Hashtable h = new Hashtable();
				h.put("day", new Integer(dy));
				h.put("month", new Integer(mn));
				h.put("year", new Integer(yr));
				scheduleDateValues.put("d" + Integer.toString(num), h);
				
			
				
			} else {
				dy--;
				//System.out.println("backward = " + dy + " - " + mn + " - " + yr);	
				Vector tasklist = getTaskVector(user, subjectid, yr, mn, dy);
				schedules.put("d" + Integer.toString(num), tasklist);
				String taskdate = mecca.util.DateTool.getDateFormatted((new java.util.GregorianCalendar(yr, mn-1, dy)).getTime());
				scheduleDates.put("d" + Integer.toString(num), taskdate);
				Hashtable h = new Hashtable();
				h.put("day", new Integer(dy));
				h.put("month", new Integer(mn));
				h.put("year", new Integer(yr));
				scheduleDateValues.put("d" + Integer.toString(num), h);				
				
			}
		}
		
		//now
		dy = day1; 
		mn = month1;
		yr = year1;
		//forward
		for ( int i = 0; i < (8 - day_week); i++ ) {
			int num = i + day_week;
			//System.out.print(num + " = ");
			//System.out.println(dy + " - " + mn + " - " + yr);	
			Vector tasklist = getTaskVector(user, subjectid, yr, mn, dy);
			schedules.put("d" + Integer.toString(num), tasklist);
			String taskdate = mecca.util.DateTool.getDateFormatted((new java.util.GregorianCalendar(yr, mn-1, dy)).getTime());
			scheduleDates.put("d" + Integer.toString(num), taskdate);
			Hashtable h = new Hashtable();
			h.put("day", new Integer(dy));
			h.put("month", new Integer(mn));
			h.put("year", new Integer(yr));
			scheduleDateValues.put("d" + Integer.toString(num), h);			
			if ( dy == max_day ) {
				dy = 0;
				mn++;
				if ( mn == 13 ) {
					mn = 1;
					yr++;
				}
			}
			dy++;			
		}
		
		context.put("schedules", schedules);
		context.put("scheduleDates", scheduleDates);
		context.put("scheduleDateValues", scheduleDateValues);
		
		
		String date_display = mecca.util.DateTool.getDateFormatted(calendar.getTime());
		
		//Vector v = getTaskVector(user, subjectid, year1, month1, day1);
		//context.put("taskVector", v);
		
		context.put("year", new Integer(year1));
		context.put("month", new Integer(month1));
		context.put("day", new Integer(day1));
		context.put("date_display", date_display);
	}		
	
	private boolean userIsTeacher(String userid, String subjectid) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("member_id", userid);
			r.add("subject_id", subjectid);
			r.add("role");
			sql = r.getSQLSelect("member_subject");
			ResultSet rs = stmt.executeQuery(sql);
			if ( rs.next() ) {
				if ( "tutor".equals(rs.getString("role")) )
					return true;
				else
					return false;
			}
			else
				return false;	
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	private void doDeleteTask(HttpSession session) {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			String task_id = getParam("task_id");
			sql = "DELETE FROM planner_task WHERE task_id = '" + task_id + "'";
			stmt.executeUpdate(sql);
		} catch ( DbException dbex ) {
			System.out.println( dbex.getMessage() );			
		} catch ( SQLException ex ) {
			System.out.println( ex.getMessage() + sql);
		} finally {
			if ( db != null ) db.close();
		}				

			
	}
	
	private String fmtTime(int h, int m) {
		String mn = m < 10 ? "0" + Integer.toString(m): Integer.toString(m);
		String ap = "";
		if ( h < 12 ) {
			ap = "AM";
			if ( h == 0 ) h = 12;
		} else {
			if ( h > 12 ) h = h - 12;
			ap = "PM";	
		}
		return Integer.toString(h).concat(":").concat(mn).concat(" " ).concat(ap);
	}
	

	String putLineBreak(String str) {
		//first look for href
		//if ( str == null || str.equals("") ) return "";
		//str = Hyperlinker.convert(str);
		StringBuffer txt = new StringBuffer(str);
		char c = '\r';
		while (txt.toString().indexOf(c) > -1) {
			int pos = txt.toString().indexOf(c);
			txt.replace(pos, pos + 1, "<br>");
		}
		return txt.toString();
	}
	
	private void doEditTask(HttpSession session) {
				
		Hashtable task = new Hashtable();
		Db db = null;
		Connection conn = null;
		String sql = "";
		String user = (String) session.getAttribute("_portal_login");
		String id = getParam("task_id");

		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			//get task
			{
				r.add("task_description");
				//r.add("task_start_date");
				//r.add("task_end_date");
				r.add("task_public");
				
				r.add("hour_start");
				r.add("hour_end");
				r.add("minute_start");
				r.add("minute_end");
								
				r.add("task_date");
				
				r.add("task_id", id);
				sql = r.getSQLSelect("planner_task");
				
				ResultSet rs = stmt.executeQuery(sql);

				if ( rs.next() ) {
					String task_id = id;
					String task_description = rs.getString("task_description");
					java.sql.Date task_date = rs.getDate("task_date");
					String date_display = mecca.util.DateTool.getDateFormatted(task_date);
					//String task_end_date = rs.getString("task_end_date");
					String task_public = rs.getString("task_public");

					Calendar c = new java.util.GregorianCalendar();
					
					c.setTime(task_date);				
					int year1 = c.get(Calendar.YEAR);
					int month1 = c.get(Calendar.MONTH) + 1;
					int day1 = c.get(Calendar.DAY_OF_MONTH);
					
					int hour_start = rs.getInt("hour_start");
					int minute_start = rs.getInt("minute_start");
					int hour_end = rs.getInt("hour_end");
					int minute_end = rs.getInt("minute_end");
					
					String time_start = fmtTime(hour_start, minute_start);
					String time_end = fmtTime(hour_end, minute_end);
									
					task.put("task_id", task_id);
					task.put("task_description", task_description);
					task.put("hour_start", new Integer(hour_start));
					task.put("minute_start", new Integer(minute_start));
					task.put("hour_end", new Integer(hour_end));
					task.put("minute_end", new Integer(minute_end));
					task.put("task_public", task_public);
	
					task.put("time_start", time_start);
					task.put("time_end", time_end);		
					
					task.put("inviter", "");
					
					
					context.put("task", task);
					context.put("year", new Integer(year1));
					context.put("month", new Integer(month1));
					context.put("day", new Integer(day1));
					context.put("date_display", date_display);					

				}
			}
			
			//get invite list
			String invite_list = "";
			Vector inviteList = new Vector();
			{
				r = new SQLRenderer();
				r.add("user_id");
				r.add("task_id", id);
				sql = r.getSQLSelect("planner_task_invite", "user_id");
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					String userid = rs.getString("user_id");
					inviteList.addElement(userid);
					invite_list += userid + " ";
				}
			}
			context.put("inviteList", inviteList);
			context.put("task_invite_list", invite_list);

			
		} catch ( DbException dbex ) {
			System.out.println( dbex.getMessage() );			
		} catch ( SQLException ex ) {
			if ( conn != null ) {
				try {
					conn.rollback();	
				} catch ( SQLException rex ) {}
			}
			System.out.println( ex.getMessage() + sql);
		} finally {
			if ( db != null ) db.close();
		}	
				
	}			
	
	
	private void doUpdateTaskX(HttpSession session) {
		Db db = null;
		Connection conn = null;
		String sql = "";
		String user = (String) session.getAttribute("_portal_login");
		String id = getParam("task_id");
		String task_description = getParam("description");
		String year1 = getParam("year1");
		String month1 = getParam("month1");
		String day1 = getParam("day1");
		String hour1 = getParam("hour1");
		String minute1 = getParam("minute1");
		String hour2 = getParam("hour2");
		String minute2 = getParam("minute2");	
		int ispublic = !"".equals(getParam("public")) ? Integer.parseInt(getParam("public")) : 1;
		
		String task_date = year1 + "-" + fmt(month1) + "-" + fmt(day1);

		String[] invitelist = request.getParameterValues("invitelist");

		try {
			db = new Db();	
			conn = db.getConnection();
			Statement stmt = db.getStatement();
			
			conn.setAutoCommit(false);
			SQLRenderer r = new SQLRenderer();
			
			//task data
			{
				sql = "UPDATE planner_task SET task_description = '" + task_description + "', " +
				"task_date = '" + task_date  + " WHERE task_id = '" + id + "'";
				stmt.executeUpdate(sql);
			}
			
			//invite list
			//delete first
			{
				sql = "DELETE FROM planner_task_invite WHERE task_id = '" + id + "' ";	
				stmt.executeUpdate(sql);
			}
			if ( invitelist != null ) {
				for ( int i=0; i < invitelist.length; i++ ) {
					r = new SQLRenderer();
					r.add("task_id", id);
					r.add("user_id", invitelist[i]);
					r.add("inviter_id", user);
					r.add("allow_edit", 0);
					sql = r.getSQLInsert("planner_task_invite");
					stmt.executeUpdate(sql);
				}
			}
			
			conn.commit();
			
		} catch ( DbException dbex ) {
			System.out.println( dbex.getMessage() );			
		} catch ( SQLException ex ) {
			if ( conn != null ) {
				try {
					conn.rollback();	
				} catch ( SQLException rex ) {}
			}
			System.out.println( ex.getMessage() + sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	private void doUpdateTask(HttpSession session) throws Exception {
		String id = getParam("task_id");

		Db db = null;
		Connection conn = null;
		String sql = "";
		String user = (String) session.getAttribute("_portal_login");
		String task_description = getParam("description");
		
		if ( "".equals(task_description.trim()) ) return;
		
		
		String year1 = getParam("year1");
		String month1 = getParam("month1");
		String day1 = getParam("day1");
		String hour1 = getParam("hour1");
		String minute1 = getParam("minute1");
		String hour2 = getParam("hour2");
		String minute2 = getParam("minute2");	
		int ispublic = !"".equals(getParam("public")) ? Integer.parseInt(getParam("public")) : 1;
		String task_date = year1 + "-" + fmt(month1) + "-" + fmt(day1);
		//invite list
		String[] invitelist = request.getParameterValues("invitelist");
		
		try {
			db = new Db();	
			conn = db.getConnection();
			Statement stmt = db.getStatement();
			
			conn.setAutoCommit(false);
			SQLRenderer r = new SQLRenderer();
			
			//task data
			{
				r.update("task_id", id);
				r.add("task_description", task_description);
				//r.add("task_start_date", start_date);
				//r.add("task_end_date", end_date);
				
				r.add("task_date", task_date);
				r.add("hour_start", Integer.parseInt(hour1));
				r.add("hour_end", Integer.parseInt(hour2));
				r.add("minute_start", Integer.parseInt(minute1));
				r.add("minute_end", Integer.parseInt(minute2));
				
				r.add("task_public", ispublic);
				sql = r.getSQLUpdate("planner_task");
				
				//System.out.println(sql);
				
				stmt.executeUpdate(sql);
			}
			
			//invite list
			//delete first
			{
				sql = "DELETE FROM planner_task_invite WHERE task_id = '" + id + "' ";	
				stmt.executeUpdate(sql);
			}
			if ( invitelist != null ) {
				for ( int i=0; i < invitelist.length; i++ ) {
					r = new SQLRenderer();
					r.add("task_id", id);
					r.add("user_id", invitelist[i]);
					r.add("inviter_id", user);
					r.add("allow_edit", 0);
					sql = r.getSQLInsert("planner_task_invite");
					stmt.executeUpdate(sql);
				}
			}
			
			conn.commit();
			
		} catch ( DbException dbex ) {
			System.out.println( dbex.getMessage() );	
			throw dbex;		
		} catch ( SQLException ex ) {
			if ( conn != null ) {
				try {
					conn.rollback();	
				} catch ( SQLException rex ) {}
			}
			System.out.println( ex.getMessage() + sql);
			throw ex;
		} finally {
			if ( db != null ) db.close();
		}	
	}		
	
	public class TimeComparator implements java.util.Comparator {
		public int compare(Object o1, Object o2) {
			Hashtable htbl1 = (Hashtable) o1;
			Hashtable htbl2 = (Hashtable) o2;
			int start_hour1 = ((Integer) htbl1.get("hour_start")).intValue();
			int start_minute1 = ((Integer) htbl1.get("minute_start")).intValue(); 
			int start_hour2 = ((Integer) htbl2.get("hour_start")).intValue();
			int start_minute2 = ((Integer) htbl2.get("minute_start")).intValue(); 		
			
			int end_hour1 = ((Integer) htbl1.get("hour_end")).intValue();
			int end_minute1 = ((Integer) htbl1.get("minute_end")).intValue(); 
			int end_hour2 = ((Integer) htbl2.get("hour_end")).intValue();
			int end_minute2 = ((Integer) htbl2.get("minute_end")).intValue(); 
			
			int result = 0;
			
			if ( start_hour1 > start_hour2 ) result = 1;
			else if ( start_hour1 < start_hour2) result = -1;
			else if ( start_hour1 == start_hour2 ) {
				if ( start_minute1 > start_minute2 ) result = 1;
				else if ( start_minute1 < start_minute2 ) result = -1;
				else if ( start_minute1 == start_minute2) {
					if ( end_hour1 > end_hour2 ) result = 1;
					else if ( end_hour1 < end_hour2) result = -1;
					else if ( end_hour1 == end_hour2 ) {
						if ( end_minute1 > end_minute2 ) result = 1;
						else if ( end_minute1 < end_minute2 ) result = -1;
						else if ( end_minute1 == end_minute2) {
							result = 0;
						}	
					}
					else result = 0;
				}	
			}
			else result = 0;
			return result;
		}
	
	}
	
	public static String[] getTimeZoneIDs() {		
		return TimeZone.getAvailableIDs();
	}	
	
	//-- start paging methods
	
	void prepareList(HttpSession session) throws Exception {
		Vector list = UsersData.getList();
		int pages =  list.size() / LIST_ROWS;
		double leftover = ((double)list.size() % (double)LIST_ROWS);
		if ( leftover > 0.0 ) ++pages;
		context.put("pages", new Integer(pages));	
		session.setAttribute("pages", new Integer(pages));
			
		session.setAttribute("userList", list);

	}	
	
	void getRows(HttpSession session, int page) throws Exception {
		Vector list = (Vector) session.getAttribute("userList");
		Vector items = getPage(page, LIST_ROWS, list);
		context.put("users", items);	
		context.put("page_number", new Integer(page));
		context.put("pages", (Integer) session.getAttribute("pages" ));			
	}
	
	Vector getPage(int page, int size, Vector list) throws Exception {
		int elementstart = (page - 1) * size;
		int elementlast = 0;
		//int elementlast = page * size < list.size() ? (page * size) - 1 : list.size() - 1;
		if ( page * size < list.size() ) {
			elementlast = (page * size) - 1;
			isLastPage = false;
			context.put("eol", new Boolean(false));
		} else {
			elementlast = list.size() - 1;
			isLastPage = true;
			context.put("eol", new Boolean(true));
		}
		if ( page == 1 ) context.put("bol", new Boolean(true));
		else context.put("bol", new Boolean(false));
		Vector v = new Vector();
		for ( int i = elementstart; i < elementlast + 1; i++ ) {
			v.addElement(list.elementAt(i));
		}
		
		return v;
	}
	
	//---- end paging methods		
	
	
}