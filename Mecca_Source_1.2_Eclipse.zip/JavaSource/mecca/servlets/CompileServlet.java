
package mecca.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dori.jasper.engine.JRException;
import dori.jasper.engine.JasperCompileManager;

/**
 * @author Teodor Danciu (teodord@users.sourceforge.net)
 * @version $Id: CompileServlet.java,v 1.4 2005/07/16 04:57:12 sbahrin2 Exp $
 */
public class CompileServlet extends HttpServlet 
{
	public void service(
		HttpServletRequest request,
		HttpServletResponse response
		) throws IOException, ServletException
	{
		ServletContext context = this.getServletConfig().getServletContext();

		System.setProperty(
			"jasper.reports.compile.class.path", 
			context.getRealPath("/WEB-INF/lib/jasperreports-0.5.3.jar") +
			System.getProperty("path.separator") + 
			context.getRealPath("/WEB-INF/classes/")
			);
	
		System.setProperty(
			"jasper.reports.compile.temp", 
			context.getRealPath("/reports/")
			);

		try
		{
			JasperCompileManager.compileReportToFile(context.getRealPath("/reports/OfferLetter3.jrxml"));
		}
		catch (JRException e)
		{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<head>");
			out.println("<title>JasperReports - Web Application Sample</title>");
			out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"../stylesheet.css\" title=\"Style\">");
			out.println("</head>");
			
			out.println("<body bgcolor=\"white\">");

			out.println("<span class=\"bnew\">JasperReports encountered this error :</span>");
			out.println("<pre>");

			e.printStackTrace(out);

			out.println("</pre>");

			out.println("</body>");
			out.println("</html>");

			return;
		}

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>JasperReports - Web Application Sample</title>");
		out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"../stylesheet.css\" title=\"Style\">");
		out.println("</head>");
		
		out.println("<body bgcolor=\"white\">");

		out.println("<span class=\"bold\">The XML report design was successfully compiled.</span>");

		out.println("</body>");
		out.println("</html>");
	}


}
