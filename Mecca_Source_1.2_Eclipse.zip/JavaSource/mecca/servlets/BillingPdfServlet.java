/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.servlets;


import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mecca.datasource.BillingDataSource;
import mecca.sis.billing.BillingData;
import mecca.sis.billing.ReceiptData;
import dori.jasper.engine.JasperRunManager;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class BillingPdfServlet extends HttpServlet
{


	/**
	 *
	 */
	public void service(
		HttpServletRequest request,
		HttpServletResponse response
		) throws IOException, ServletException	{
			
		ServletContext context = this.getServletConfig().getServletContext();


		File reportFile = null;
		Map parameters = new HashMap();
		
		String student_id = request.getParameter("student_id");
		String no = request.getParameter("no");
		String get = request.getParameter("get");
		
		String reporttype = request.getParameter("report");
		String pdfName = "billing";
		if ( "payment".equals(reporttype)) {
			parameters.put("ReportTitle", "Official Receipt");
			pdfName = "receipt";
			reportFile = new File(context.getRealPath("/reports/Receipt.jasper"));
		} else {
			parameters.put("ReportTitle", "Student Billing");	
			reportFile = new File(context.getRealPath("/reports/Billing.jasper"));
		}		
		
		parameters.put("BaseDir", reportFile.getParentFile());
		
					
		byte[] bytes = null;

		try {
			
			Hashtable studentInfo = BillingData.getStudentInfo(student_id);
			
			Hashtable report = null;
			String date = "";
			String total = "";
			String docno = "";
			String totalInWords = "";
			if ( "payment".equals(reporttype) ) {
				report = ReceiptData.getStudentReceipt(studentInfo, no);
				Hashtable header = (Hashtable) report.get("header");
				date = (String) header.get("receipt_date");
				total= (String) header.get("amount_total_formatted");
				docno= (String) header.get("receipt_no");
				totalInWords = (String) header.get("amount_total_words");
				
			} else {
				report = BillingData.getStudentBilling(studentInfo, no);
				Hashtable header = (Hashtable) report.get("header");
				date = (String) header.get("bill_date");
				total= (String) header.get("amount_total_formatted");
				docno= (String) header.get("bill_no");				
				totalInWords = (String) header.get("amount_total_words");
			}
			
			String name = (String) studentInfo.get("name");
			String matric = (String) studentInfo.get("id");
			String addr1 = (String) studentInfo.get("address1");
			String addr2 = (String) studentInfo.get("address2");
			String addr3 = (String) studentInfo.get("address3");
			String city = (String) studentInfo.get("city");
			String poscode = (String) studentInfo.get("poscode");
			String state = (String) studentInfo.get("state");
			String country = (String) studentInfo.get("country");
			
			pdfName += "_" + name + ".pdf";			
			
			parameters.put("Matric", matric);
			parameters.put("Name", name);
			parameters.put("Date", date);
			parameters.put("No", docno);
			parameters.put("Total", total);			
			parameters.put("TotalInWords", totalInWords);
			
			String address = name + "\n";
			address += addr1 + "\n";
			address += addr2 != null ? addr2 + "\n" : "";
			address += addr3 != null ? addr3 + "\n" : "";
			address += poscode != null ? poscode + " " : "";
			address += city != null ? city + "\n" : "";
			address += state != null ? state + ", " : "";
			address += country != null ? country + "\n" : "";
			
			parameters.put("Address", address);
			
			Vector items = (Vector) report.get("detail");
			
			BillingDataSource dataSource = new BillingDataSource();

			dataSource.setData(items);
			
			bytes = JasperRunManager.runReportToPdf(reportFile.getPath(), parameters, dataSource);
		}
		catch (Exception e)
		{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<head>");
			out.println("<title>JasperReports - Error</title>");
			out.println("</head>");
			
			out.println("<body bgcolor=\"white\">");

			out.println("<span class=\"bnew\">JasperReports encountered this error :</span>");
			out.println("<pre>");

			e.printStackTrace(out);

			out.println("</pre>");

			out.println("</body>");
			out.println("</html>");

			return;
		}

		if (bytes != null && bytes.length > 0)
		{
			response.setContentType("application/pdf");
			if ( "save".equals(get)) response.setHeader("Content-Disposition", "attachment; filename=\"" + pdfName + "\"");
			response.setContentLength(bytes.length);
			ServletOutputStream ouputStream = response.getOutputStream();
			ouputStream.write(bytes, 0, bytes.length);
			ouputStream.flush();
			ouputStream.close();
		}
		else
		{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Empty response.</title>");
			out.println("</head>");
			
			out.println("<body bgcolor=\"white\">");
	
			out.println("<span class=\"bold\">Empty response.</span>");
	
			out.println("</body>");
			out.println("</html>");
		}
	}


}
