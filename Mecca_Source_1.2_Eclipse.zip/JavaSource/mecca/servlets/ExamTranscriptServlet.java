/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.servlets;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mecca.datasource.TranscriptDataSource;
import dori.jasper.engine.JRResultSetDataSource;
import dori.jasper.engine.JasperRunManager;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ExamTranscriptServlet extends HttpServlet
{
	public void service(
		HttpServletRequest request,
		HttpServletResponse response
		) throws IOException, ServletException
	{
		ServletContext context = this.getServletConfig().getServletContext();
		
		String student = request.getParameter("student") != null ? request.getParameter("student") : "";
		String program = request.getParameter("program") != null ? request.getParameter("program") : "";

		File reportFile = new File(context.getRealPath("/reports/ExamTranscript.jasper"));
				
		byte[] bytes = null;
		
		TranscriptDataSource data = null;
		try
		{
			Map parameters = new HashMap();
			parameters.put("ReportTitle", "Examination Result Transcript");
			parameters.put("BaseDir", reportFile.getParentFile());				
			
			
			
			//get student informations
			Hashtable studentDetail = mecca.sis.registration.StudentData.getStudent(student);
			
			parameters.put("student_id",(String) studentDetail.get("id"));
			parameters.put("student_name", (String) studentDetail.get("name"));
						
			Hashtable studentInfo = mecca.sis.registration.StudentData.getEnrollmentInfo(student);
			parameters.put("course_code",(String) studentInfo.get("course_code"));
			parameters.put("course_name", (String) studentInfo.get("course_name"));
			parameters.put("program_code", (String) studentInfo.get("program_code"));
			parameters.put("program_name", (String) studentInfo.get("program_name"));
			parameters.put("intake_session", (String) studentInfo.get("intake_session_name"));
			parameters.put("period_name", (String) studentInfo.get("period_name"));
			parameters.put("faculty_code", (String) studentInfo.get("faculty_code"));
			parameters.put("faculty_name", (String) studentInfo.get("faculty_name"));
			
			//create JRResultSetDataSource
			if ( "".equals(program) ) program = (String) studentInfo.get("program_code");
			data = new TranscriptDataSource();
			JRResultSetDataSource dataSource = new JRResultSetDataSource(data.getResultSet(student, program));
			
			bytes = JasperRunManager.runReportToPdf(reportFile.getPath(), parameters, dataSource);
		}
		catch (Exception e)
		{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Error!</title>");
			out.println("</head>");
			
			out.println("<body bgcolor=\"white\">");

			out.println("<span class=\"bnew\">JasperReports encountered this error :</span>");
			out.println("<pre>");

			e.printStackTrace(out);

			out.println("</pre>");

			out.println("</body>");
			out.println("</html>");

			return;
		} 
		finally 
		{
			data.close();
		}

		if (bytes != null && bytes.length > 0)
		{
			response.setContentType("application/pdf");
			response.setContentLength(bytes.length);
			ServletOutputStream ouputStream = response.getOutputStream();
			ouputStream.write(bytes, 0, bytes.length);
			ouputStream.flush();
			ouputStream.close();
		}
		else
		{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Empty response.</title>");
			out.println("</head>");
			
			out.println("<body bgcolor=\"white\">");
	
			out.println("<span class=\"bold\">Empty response.</span>");
	
			out.println("</body>");
			out.println("</html>");
		}
	}

}
