package mecca.servlets;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mecca.datasource.ApplicantDataSource;
import dori.jasper.engine.JRExporterParameter;
import dori.jasper.engine.JRResultSetDataSource;
import dori.jasper.engine.JasperFillManager;
import dori.jasper.engine.JasperPrint;
import dori.jasper.engine.JasperReport;
import dori.jasper.engine.export.JRHtmlExporter;
import dori.jasper.engine.export.JRHtmlExporterParameter;
import dori.jasper.engine.util.JRLoader;


/**
 * @author Teodor Danciu (teodord@users.sourceforge.net)
 * @version $Id: HtmlServlet.java,v 1.3 2005/07/15 02:00:38 sbahrin2 Exp $
 */
public class HtmlServlet extends HttpServlet
{
	public void service(
		HttpServletRequest request,
		HttpServletResponse response
		) throws IOException, ServletException
	{
		ServletContext context = this.getServletConfig().getServletContext();

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		ApplicantDataSource appData = null;
		try
		{
			File reportFile = new File(context.getRealPath("/reports/OfferLetter.jasper"));
		
			JasperReport jasperReport = (JasperReport)JRLoader.loadObject(reportFile.getPath());
		
			Map parameters = new HashMap();
			parameters.put("ReportTitle", "Address Report");
			parameters.put("BaseDir", reportFile.getParentFile());
			
			//create JRResultSetDataSource
			appData = new ApplicantDataSource();
			JRResultSetDataSource dataSource = new JRResultSetDataSource(appData.getResultSet());
									
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);
						
			JRHtmlExporter exporter = new JRHtmlExporter();
		
			Map imagesMap = new HashMap();
			request.getSession().setAttribute("IMAGES_MAP", imagesMap);
			
			exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			exporter.setParameter(JRExporterParameter.OUTPUT_WRITER, out);
			exporter.setParameter(JRHtmlExporterParameter.IMAGES_MAP, imagesMap);
			exporter.setParameter(JRHtmlExporterParameter.IMAGES_URI, "image?image=");
			
			exporter.exportReport();
		}
		catch (Exception e)
		{
			out.println("<html>");
			out.println("<head>");
			out.println("<title>JasperReports - Web Application Sample</title>");
			out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"../stylesheet.css\" title=\"Style\">");
			out.println("</head>");
			
			out.println("<body bgcolor=\"white\">");

			out.println("<span class=\"bnew\">JasperReports encountered this error :</span>");
			out.println("<pre>");

			e.printStackTrace(out);

			out.println("</pre>");

			out.println("</body>");
			out.println("</html>");
		}
		finally 
		{
			appData.close();
		}		
	}


}
