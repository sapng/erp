/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.servlets;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mecca.datasource.ApplicantDataSource;
import dori.jasper.engine.JRResultSetDataSource;
import dori.jasper.engine.JasperRunManager;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class Pdf2Servlet extends HttpServlet
{


	/**
	 *
	 */
	public void service(
		HttpServletRequest request,
		HttpServletResponse response
		) throws IOException, ServletException
	{
		ServletContext context = this.getServletConfig().getServletContext();
		
		String applicant_id = request.getParameter("applicant_id");

		File reportFile = new File(context.getRealPath("/reports/OfferLetter.jasper"));
				
		byte[] bytes = null;
		
		ApplicantDataSource appData = null;
		try
		{
			//create JRResultSetDataSource
			appData = new ApplicantDataSource();
			JRResultSetDataSource dataSource = new JRResultSetDataSource(appData.getResultSet(applicant_id));
			
			Map parameters = new HashMap();
			parameters.put("ReportTitle", "International Worldview College");
			parameters.put("BaseDir", reportFile.getParentFile());	
			
			bytes = JasperRunManager.runReportToPdf(reportFile.getPath(), parameters, dataSource);
		}
		catch (Exception e)
		{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Error!</title>");
			out.println("</head>");
			
			out.println("<body bgcolor=\"white\">");

			out.println("<span class=\"bnew\">JasperReports encountered this error :</span>");
			out.println("<pre>");

			e.printStackTrace(out);

			out.println("</pre>");

			out.println("</body>");
			out.println("</html>");

			return;
		} 
		finally 
		{
			appData.close();
		}

		if (bytes != null && bytes.length > 0)
		{
			response.setContentType("application/pdf");
			response.setContentLength(bytes.length);
			ServletOutputStream ouputStream = response.getOutputStream();
			ouputStream.write(bytes, 0, bytes.length);
			ouputStream.flush();
			ouputStream.close();
		}
		else
		{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Empty response.</title>");
			out.println("</head>");
			
			out.println("<body bgcolor=\"white\">");
	
			out.println("<span class=\"bold\">Empty response.</span>");
	
			out.println("</body>");
			out.println("</html>");
		}
	}
	
	



}
