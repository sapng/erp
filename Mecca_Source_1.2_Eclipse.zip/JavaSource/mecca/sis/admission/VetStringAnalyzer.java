/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

/*
In the Admission modules, a way must be provided to analyzed vetting criteria.  Such criteria example is:

To enroll in COURSE Bachelor Of ABC, Candidate must have the following SPM results:

Bahasa Malaysia SPM is 6 or less
AND
English Language SPM is 6 or less
AND
Matematik SPM is 3 or less

which can be shown mathematically as:

SPM-BM < 7 AND SPM-EN < 7 AND SPM-MA < 4

The admission system will run each criteria separately against the applicant data, which might result as follows:

SPM-BM < 7 = true
SPM-EN < 7 = true
SPM-MA < 4 = false

The "true, true and false" then is compared with the conditional operator, to become:

"true AND true AND false" which is then translated to "110-11"

and pass to the VetStringAnalyzer class.

boolean result = VetStringAnalyzer.doProcess("110-11");



This class is used to analyze conditional Vetting String.  The String must be in the form of sequences of
1 and 0 where 1 represent true or AND and 0 represent false or OR.  The String should contains two part separated by a hyphen character (-).
The first part is the true/false values, and the second part is the conditional value (AND/OR).

example:

110-00	=	true true false - OR OR
is translation of: true AND true AND false

Grouping is allowed in the Vet String, for example:

(101-11)(11-1)(1)-00
is translation of:
(true AND false AND true) OR (true AND true) OR (true)

*/

package mecca.sis.admission;

import java.util.Vector;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class VetStringAnalyzer{
	
	public static void main(String[] args) {
		//String s = "(101-11)(11-1)(1)-00";
		String s = args[0];
		Vector list = new Vector();
		if ( doProcess(s, list) == 1 ) {
			System.out.println("TRUE");
			for ( int i = 0; i < list.size(); i++ ) {
				System.out.println( (String) list.elementAt(i) );	
			}
		} else {
			System.out.println("FALSE");
		}
	}	
	
	public static int doProcess(String s, Vector list) {
		int group_num = 0;
		StringBuffer temp = new StringBuffer("");
		StringBuffer r = new StringBuffer();
		boolean in = false;
		for ( int i = 0; i < s.length(); i++ ) {
			char c = s.charAt(i);
			if ( c == '(' ) {
				in = true;
				temp = new StringBuffer("");
				continue;
			}
			if ( c == ')' ) {
				//process    
				group_num++;
				if ( temp.toString().indexOf("-") > 0 ) {
					String s1 = temp.substring(0, temp.toString().indexOf("-"));
					String s2 = temp.substring(temp.toString().indexOf("-") + 1);
					int q = getQualified(s1, s2);
					r.append(Integer.toString(q));
					if ( q == 1 ) {
						//System.out.println("group_num = " + group_num);
						list.addElement(Integer.toString(group_num));
					}
				} else {
					r.append(temp);
					if ( Integer.parseInt(temp.toString().trim()) == 1 ) {
						//System.out.println("group_num = " + group_num);
						list.addElement(Integer.toString(group_num));
					}
				}
				in = false;
				continue;
			}			
			if ( in ) {
				temp.append(c);
				continue;
			}
			r.append(c);
		}
		//process
		
		int result = 0;
		if ( r.toString().indexOf("-") > 0 ) {
			String s1 = r.substring(0, r.toString().indexOf("-"));
			String s2 = r.substring(r.toString().indexOf("-") + 1);
			result = getQualified(s1, s2);
		} else {
			result = Integer.parseInt(r.toString().trim());
		}
		return result;
	}
	
	static int getQualified(String s1, String s2) {
		
		int count = s1.length();
		
		int[] data = new int[count], condition = new int[count - 1];
		for ( int i=0; i < s1.length(); i++ ) {
			data[i] = Integer.parseInt(new Character(s1.charAt(i)).toString());
			//data[i] = s1.charAt(i);
		}
		for ( int i=0; i < s2.length(); i++ ) {
			condition[i] = Integer.parseInt(new Character(s2.charAt(i)).toString());
			//condition[i] = s2.charAt(i);
		}
		return getQualified(data, condition);		
	}
	
	static int getQualified(int[] data, int[] condition) {
		int x = data[0];
		for ( int i = 1; i < data.length; i++ ) {
			if ( condition[i-1] == 1 ) {
				x = x & data[i];
			} else {
				x = x | data[i];	
			}
		}
		return x;
	}		
	
}