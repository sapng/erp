/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.admission;
 

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.db.SQLRenderer;
import mecca.sis.struct.ProgramData;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class QualifiedApplicantModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/sis/qualified_applicant.vm";
		String submit = getParam("command");
		String program_code = getParam("program_code");
		String select_status = getParam("select_status");
		String select_status2 = getParam("select_status2");
		context.put("program_code", program_code);
		context.put("select_status", select_status);
		context.put("select_status2", select_status2);
		
		context.put("applicantStatus", ApplicantStatus.getStatus());
		//reset
		context.put("qualifiedList", new Vector());			
		

		
		//get program list
		Vector programList = ProgramData.getProgramList();
		context.put("programList", programList);
		
		String program_name = session.getAttribute("program_name") != null ? (String) session.getAttribute("program_name") : "";
		Vector qualifiedList = session.getAttribute("qualifiedList") != null ? (Vector) session.getAttribute("qualifiedList") : new Vector();
		
 		if ( "list".equals(submit) ) {
			
		}
		//else if ( "generate".equals(submit) ) {
		//	generateOfferLetter(program_code, select_status);
		//}
		else if ( "compile".equals(submit) ) {
			template_name = "vtl/sis/compose_letter.vm";
			String[] fieldList = new String[] {"{applicant_name}", "{address1}", "{address2}", "{address3}", "{poscode}", "{city}", "{state}",
											   "{program_code}", "{program_name}"};
			context.put("fieldList", fieldList);
			context.put("fieldNameList", "{applicant_name}\n{address1}\n{address2}\n{address3}\n{poscode}\n{city}\n{state}\n{program_code}\n{program_name}");
			
			//context.put("contentText", getContentText(program_code));
			
			context.put("offerLetter", getOfferLetter(program_code));
			
		}
		else if ( "save_letter".equals(submit)) {
			template_name = "vtl/sis/compose_letter.vm";
			//context.put("contentText", getContentText(program_code));
			
			String[] fieldList = new String[] {"{applicant_name}", "{address1}", "{address2}", "{address3}", "{poscode}", "{city}", "{state}",
											   "{program_code}", "{program_name}"};
			context.put("fieldList", fieldList);
			context.put("fieldNameList", "{applicant_name}\n{address1}\n{address2}\n{address3}\n{poscode}\n{city}\n{state}\n{program_code}\n{program_name}");
			
			
			saveLetter(program_code);
			Hashtable offerLetter = (Hashtable) getOfferLetter(program_code);
			context.put("offerLetter", offerLetter);
			
			generateOfferLetter(program_code, select_status, offerLetter);
			
			
		}	
		else if ( "change_pending".equals(submit) ) {
			changePending(program_code, select_status);	
		}
		else if ( "change_status".equals(submit) ) {
			String status2 = getParam("status2");
			String[] ids = request.getParameterValues("applicant_ids");
			
			if ( ids != null ) {
			
				session.setAttribute("applicantIds", ids);
				if ("create".equals(status2)) {
					template_name = "vtl/sis/applicant_new_status.vm";
				}
				else {
					updateApplicantStatus(ids, status2);	
				}
			}
		}
		else if ( "add_status".equals(submit)) {
			String status_id = getParam("status_name");
			String status_name = getParam("status_name");
			String status_description = getParam("status_description");
			String[] ids = (String[]) session.getAttribute("applicantIds");
			if ( !"".equals(status_id) && !"".equals(status_name) && !"".equals(status_description) ){
				addNewStatus(status_id, status_name, status_description, ids);
			}
				
		}
		else if ( "deletestatus".equals(submit) ) {
			String status_id = getParam("status_id");
			deleteStatus(status_id);
		}
		else if ( "viewstatus".equals(submit) ) {
			template_name = "vtl/sis/view_status.vm";
		}
		
		
		if ( !"".equals(submit)){
			program_name = ProgramData.getProgramName(program_code);
			session.setAttribute("program_name", program_name);
			qualifiedList = getCandidateList(program_code, select_status, select_status2);
			context.put("qualifiedList", qualifiedList);		
		}
		
		//status2
		Vector statusList = getApplicantStatus();
		context.put("statusList", statusList);		
	
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	Vector getCandidateList(String program_code, String select_status, String select_status2) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			Vector list = new Vector();
			{
				r.add("applicant_id");
				r.add("applicant_name");
				r.add("status");
				r.add("status2");
				r.add("vet_program_id", program_code);
				if ( !"".equals(select_status)) {
					r.add("status", select_status);	
				}
				if ( !"".equals(select_status2)) {
					r.add("status2", select_status2);	
				}				
				sql = r.getSQLSelect("adm_applicant", "applicant_name");
				ResultSet rs = stmt.executeQuery(sql);

				while ( rs.next()){
					Hashtable h = new Hashtable();
					h.put("applicant_id", mecca.db.Db.getString(rs, "applicant_id"));
					h.put("applicant_name", mecca.db.Db.getString(rs, "applicant_name"));
					h.put("status", mecca.db.Db.getString(rs, "status"));
					h.put("status2", mecca.db.Db.getString(rs, "status2"));
					list.addElement(h);
				}

			}
			
			return list;
		} finally {
			if ( db != null ) db.close();	
		}
	}
	
	void generateOfferLetter(String program_code, String status, Hashtable offerLetter) throws Exception {
		Db db = null;
		String sql = "";
		String compose_id = "offer_letter2";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			Vector applicantIds = new Vector();
			{
				r.clear();
				r.add("applicant_id");
				r.add("applicant_name");
				r.add("address1");
				r.add("address2");
				r.add("address3");
				r.add("city");
				r.add("poscode");
				r.add("state");
				r.add("p.program_code");
				r.add("p.program_name");
				r.add("p.program_code", r.unquote("vet_program_id"));
				r.add("vet_program_id", program_code);
				r.add("status", status);	
				sql = r.getSQLSelect("adm_applicant, program p");
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					h.put("id", rs.getString("applicant_id"));
					h.put("name", rs.getString("applicant_name"));
					h.put("address1", mecca.db.Db.getString(rs, "address1"));
					h.put("address2", mecca.db.Db.getString(rs, "address2"));
					h.put("address3", mecca.db.Db.getString(rs, "address3"));
					h.put("city", mecca.db.Db.getString(rs, "city"));
					h.put("poscode", mecca.db.Db.getString(rs, "poscode"));
					h.put("state", mecca.db.Db.getString(rs, "state"));
					h.put("program_code", mecca.db.Db.getString(rs, "program_code"));
					h.put("program_name", mecca.db.Db.getString(rs, "program_name"));
					applicantIds.addElement(h);	
				}
			}
			for ( int i=0; i < applicantIds.size(); i++ ) {
				Hashtable h = (Hashtable) applicantIds.elementAt(i);
				Hashtable content = (Hashtable) createLetter(offerLetter, h);
				r.clear();
				r.add("offer_letter_addr", (String) content.get("applicant_address"));
				r.add("offer_letter_salutation", (String) content.get("salutation"));
				r.add("offer_letter_subject", (String) content.get("subject"));
				r.add("offer_letter_text", (String) content.get("body"));
				r.add("offer_letter_signature", (String) content.get("signature"));
				r.update("applicant_id", (String) h.get("id"));
				sql = r.getSQLUpdate("adm_applicant");
				stmt.executeUpdate(sql);
			}
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	Hashtable createLetter(Hashtable offerLetter, Hashtable h) {
		Hashtable result = new Hashtable();
		result.put("applicant_address", replaceField(h, (String) offerLetter.get("applicant_address")));
		result.put("salutation", replaceField(h, (String) offerLetter.get("salutation")));
		result.put("subject", replaceField(h, (String) offerLetter.get("subject")));
		result.put("body", replaceField(h, (String) offerLetter.get("body")));
		result.put("signature", replaceField(h, (String) offerLetter.get("signature")));
		return result;
	}
	
	String replaceField(Hashtable h, String str) {
		str = str.replaceAll("\\{applicant_name\\}", (String) h.get("name"));
		str = str.replaceAll("\\{address1\\}", (String) h.get("address1"));
		str = str.replaceAll("\\{address2\\}", (String) h.get("address2"));
		str = str.replaceAll("\\{address3\\}", (String) h.get("address3"));
		str = str.replaceAll("\\{city\\}", (String) h.get("city"));
		str = str.replaceAll("\\{poscode\\}", (String) h.get("poscode"));
		str = str.replaceAll("\\{state\\}", (String) h.get("state"));
		str = str.replaceAll("\\{program_code\\}", (String) h.get("program_code"));
		str = str.replaceAll("\\{program_name\\}", (String) h.get("program_name"));
		str = str.replaceAll("\\{date_now\\}", (String) h.get("date_now"));
		return str;
	}	
	
	String getContentText(String id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			String str = "";
			{
				sql = "select content from letter_compose where letter_id = '" + id + "'";
				ResultSet rs = stmt.executeQuery(sql);
			
				if ( rs.next() ) str = mecca.db.Db.getString(rs, "content");
			}
			if ( "".equals(str) ) {
				sql = "select content from letter_compose where letter_id = 'offer_letter2'";
				ResultSet rs = stmt.executeQuery(sql);
			
				if ( rs.next() ) str = mecca.db.Db.getString(rs, "content");				
			}
			return str;
			
		} finally {
			if ( db != null ) db.close();
		}	
		
	}
	
	Hashtable getOfferLetter(String id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			String str = "";
			sql = "select applicant_address, salutation, subject, content, signature from letter_compose where letter_id = '" + id + "'";
			ResultSet rs = stmt.executeQuery(sql);
			Hashtable h = new Hashtable();
			if ( rs.next() ) {
				h.put("applicant_address", mecca.db.Db.getString(rs, "applicant_address"));
				h.put("salutation", mecca.db.Db.getString(rs, "salutation"));
				h.put("subject", mecca.db.Db.getString(rs, "subject"));
				h.put("body", mecca.db.Db.getString(rs, "content"));
				h.put("signature", mecca.db.Db.getString(rs, "signature"));
			}
			return h;
		} finally {
			if ( db != null ) db.close();
		}	
		
	}	
	
	void saveLetter(String id)throws Exception {
		Db db = null;
		String sql = "";
		String applicant_address = getParam("applicant_address");
		String salutation = getParam("salutation");
		String subject = getParam("subject");
		String content = getParam("body");
		String signature = getParam("signature");
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			boolean found = false;
			{
				r.add("letter_id");
				r.add("letter_id", id);
				sql = r.getSQLSelect("letter_compose");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) found = true;
			}
			if ( !found ) {
				r.clear();
				r.add("letter_id", id);	
				r.add("content", content);
				r.add("applicant_address", applicant_address);
				r.add("salutation", salutation);
				r.add("subject", subject);
				r.add("signature", signature);
				sql = r.getSQLInsert("letter_compose");
				stmt.executeUpdate(sql);
			}
			else {
				r.clear();
				r.update("letter_id", id);	
				r.add("content", content);
				r.add("applicant_address", applicant_address);
				r.add("salutation", salutation);
				r.add("subject", subject);
				r.add("signature", signature);				
				sql = r.getSQLUpdate("letter_compose");
				stmt.executeUpdate(sql);
			}
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	void changePending(String program_code, String select_status) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("status", "1");
			r.update("vet_program_id", program_code);
			r.update("status", select_status);
			sql = r.getSQLUpdate("adm_applicant");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	Vector getApplicantStatus() throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			Vector v = new Vector();
			SQLRenderer r = new SQLRenderer();
			
			r.add("status_id");
			r.add("status_name");
			r.add("status_description");
			sql = r.getSQLSelect("applicant_status");
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next()) {
				Hashtable h = new Hashtable();
				h.put("id", mecca.db.Db.getString(rs, "status_id"));
				h.put("name", mecca.db.Db.getString(rs, "status_name"));
				h.put("description", mecca.db.Db.getString(rs, "status_description"));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	void addNewStatus(String id, String name, String description, String[] ids) throws Exception {
		Db db = null;
		String sql = "";
		try { 
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			boolean found = false;
			{
				sql = "select status_id from applicant_status where status_id = '" + id + "'";
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next()) found = true;
			}	
			if ( !found ) {
				{
					r.clear();
					r.add("status_id", id);
					r.add("status_name", name);
					r.add("status_description", description);
					sql = r.getSQLInsert("applicant_status");
					stmt.executeUpdate(sql);	
				}	
				{
					for ( int i=0; i < ids.length; i++) {
						r.clear();
						r.add("status2", id);
						r.update("applicant_id", ids[i]);
						sql = r.getSQLUpdate("adm_applicant");
						stmt.executeUpdate(sql);
					}
				}
			}
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	void updateApplicantStatus(String[] ids, String status) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			for ( int i=0; i < ids.length; i++) {
				r.clear();
				r.add("status2", status);
				r.update("applicant_id", ids[i]);
				sql = r.getSQLUpdate("adm_applicant");
				stmt.executeUpdate(sql);
			}			
			
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	void deleteStatus(String status_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			{
				r.add("status2", "");
				r.update("status2", status_id);
				sql = r.getSQLUpdate("adm_applicant");
				stmt.executeUpdate(sql);
			}
			{
				sql = "delete from applicant_status where status_id = '" + status_id + "'";	
				stmt.executeUpdate(sql);
			}
			
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	
}