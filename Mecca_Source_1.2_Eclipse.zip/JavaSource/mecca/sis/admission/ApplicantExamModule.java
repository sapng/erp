/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.admission;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.db.DbException;
import mecca.db.SQLRenderer;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ApplicantExamModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/sis/applicant_exam.vm";
		
		String submit = getParam("command");
		String applicant_id = getParam("applicant_id");
		
		if ( "add".equals(submit) ) {
			add();		
		}
		else if ( "delete".equals(submit) ) {
			delete();
		}
		//
		if ( !"".equals(applicant_id) ) {
			Hashtable applicantDetail = new Hashtable();
			Vector examDetail = new Vector();
			list(applicant_id, applicantDetail, examDetail);
			context.put("applicantData", applicantDetail);
			context.put("applicantExamVector", examDetail);
		} else {
			context.put("applicantData", new Hashtable());
			context.put("applicantExamVector", new Vector());			
		}

		//get list of subjects
		Vector subjectList = SubjectDb.getList();
		context.put("subjectList", subjectList);
		
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	private void list(String applicant_id, Hashtable applicantDetail, Vector examDetail) throws Exception {
		String applicant_name = "";
		if ( "".equals(applicant_id) ) throw new Exception("Empty value to search!");	
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			//get applicant data
			{
				r.add("applicant_name");
				r.add("applicant_id", applicant_id);
				sql = r.getSQLSelect("adm_applicant");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) {
					applicantDetail.put("id", applicant_id);
					applicantDetail.put("name", rs.getString("applicant_name"));
				}
			}
			
			//exam subject-grade detail
			{
				r.clear();
				r.add("app.applicant_id");
				r.add("app.adm_exam_id");
				r.add("app.adm_subject_id");
				r.add("ex.adm_exam_name");
				r.add("subj.adm_subject_name");
				r.add("app.adm_subject_grade");
				r.add("gr.adm_grade_display");
				r.add("app.applicant_id", applicant_id);
				r.add("app.adm_exam_id", r.unquote("ex.adm_exam_id"));
				r.add("ex.adm_exam_id", r.unquote("subj.adm_exam_id"));
				r.add("app.adm_subject_id", r.unquote("subj.adm_subject_id"));
				r.add("subj.adm_grade_display_id", r.unquote("gr.adm_grade_display_id"));
				r.add("app.adm_subject_grade", r.unquote("gr.adm_grade_value"));
				sql = r.getSQLSelect("adm_applicant_exam app, adm_exam ex, adm_exam_subject subj, adm_display_grade gr");
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					h.put("applicant_id", rs.getString("applicant_id"));
					h.put("exam_id", rs.getString("adm_exam_id"));
					h.put("subject_id", rs.getString("adm_subject_id"));
					h.put("exam_name", rs.getString("adm_exam_name"));
					h.put("subject_name", rs.getString("adm_subject_name"));
					h.put("subject_grade", rs.getString("adm_subject_grade"));
					h.put("grade_display", rs.getString("adm_grade_display"));
					examDetail.addElement(h);					
				}
			}
		} catch ( DbException dbex ) {
			throw dbex;
		} catch ( SQLException sqlex ) {
			throw sqlex;
		} finally {
			if ( db != null ) db.close();
		}
			
		
	}
	
	private void add() throws Exception {
		String applicant_id = getParam("applicant_id");
		String subject_id = getParam("subject_id");
		String subject_grade = getParam("subject_grade");
		String exam_id = getParam("exam_id");
		
		if ( "".equals(subject_grade)  ) throw new Exception("Can not have empty fields!");
		if ( "".equals(subject_id)  ) throw new Exception("Can not have empty fields!");
		
		//subject grade must be numerical
		
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			//check if data already exists
			boolean found = false;
			{
				r.add("applicant_id");
				r.add("applicant_id", applicant_id);
				r.add("adm_exam_id", exam_id);
				r.add("adm_subject_id", subject_id);
				sql = r.getSQLSelect("adm_applicant_exam");

				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) found = true;
				else found = false;
			}
			
			if ( !found ) { //do insert data
				r.clear();
				r.add("applicant_id", applicant_id);	
				r.add("adm_exam_id", exam_id);
				r.add("adm_subject_id", subject_id);
				r.add("adm_subject_grade", subject_grade);
				sql = r.getSQLInsert("adm_applicant_exam");
				stmt.executeUpdate(sql);
			} else { //do update data
				r.clear();
				r.add("adm_subject_grade", subject_grade);
				r.update("applicant_id", applicant_id);	
				r.update("adm_exam_id", exam_id);
				r.update("adm_subject_id", subject_id);				
				sql = r.getSQLUpdate("adm_applicant_exam");
				stmt.executeUpdate(sql);
			}
			
		} catch ( DbException dbex ) {
			throw dbex;
		} catch ( SQLException sqlex ) {
			throw sqlex;
		} finally {
			if ( db != null ) db.close();
		}		
	}
	
	private void delete() throws Exception {
		String applicant_id = getParam("applicant_id");
		String exam_id = getParam("exam_id");
		String subject_id = getParam("subject_id");
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			sql = "DELETE FROM adm_applicant_exam WHERE applicant_id = '" + applicant_id + "' " +
			" AND adm_exam_id = '" + exam_id + "' AND adm_subject_id = '" + subject_id + "'";
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}		
	}
	
}