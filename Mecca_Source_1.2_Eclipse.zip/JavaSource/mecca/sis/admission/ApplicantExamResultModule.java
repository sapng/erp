/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.admission;

import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ApplicantExamResultModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/sis/applicant_exam_result.vm";
		
		String submit = getParam("command");
		String applicant_id = getParam("applicant_id");
		
		
		if ( "save".equals(submit) ) {
			save(session);
		}
		
		
		//
		if ( !"".equals(applicant_id) ) {
			Hashtable applicantDetail = new Hashtable();
			Hashtable examDetail = new Hashtable();
			//list(applicant_id, applicantDetail, examDetail);
			ExamResultData.list(applicant_id, applicantDetail, examDetail);
			context.put("applicantData", applicantDetail);
			context.put("examDetail", examDetail);
		} else {
			context.put("applicantData", new Hashtable());
			context.put("examDetail", new Hashtable());			
		}

		//get list of subjects
		Vector examInfo = SubjectDb.getExamInfo();
		session.setAttribute("examInfo", examInfo);
		context.put("examInfo", examInfo);
		
		Template template = engine.getTemplate(template_name);	
		return template;		
	} 
	
	private void save(HttpSession session) throws Exception {
		Hashtable info = new Hashtable();
		info.put("applicant_id", getParam("applicant_id"));
		Vector examInfo = (Vector) session.getAttribute("examInfo");
		for ( int i = 0; i < examInfo.size(); i++ ) {
			Hashtable exam = (Hashtable) examInfo.elementAt(i);
			String exam_id = (String) exam.get("id");
			Vector subjects = (Vector) exam.get("subjects");
			for ( int k = 0; k < subjects.size(); k++ ) {
				Hashtable subject = (Hashtable)	subjects.elementAt(k);
				String subject_id = (String) subject.get("id");
				info.put(subject_id, getParam(subject_id));
			}	
		}		
		ExamResultData.save(examInfo, info);
	}
	
}