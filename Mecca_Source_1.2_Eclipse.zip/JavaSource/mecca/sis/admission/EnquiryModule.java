/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.admission;


import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.db.SQLRenderer;
import mecca.general.CountryData;
import mecca.sis.struct.ProgramData;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class EnquiryModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/sis/enquiry.vm";
		//empty unique id
		context.put("unique_id", "");
		
		String submit = getParam("command");
		
		if ( "add".equals(submit)) {
			template_name = "vtl/sis/enquiry_save.vm";
			String id = saveFormData();	
			context.put("enquiry_id", id);
			Hashtable h = EnquiryData.getData(id);
			context.put("data", h);
		}
		
		Vector programList = ProgramData.getProgramList();
		context.put("programList", programList);
		Vector countryList = CountryData.getList();
		context.put("countryList", countryList);
		Template template = engine.getTemplate(template_name);	
		return template;		
		
	}
	
	String saveFormData() throws Exception {
		Hashtable h = getFormData();
		Db db = null;
		String sql= "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			String enquiry_id = mecca.sis.tools.UniqueStringId.get();
			
			r.add("enquiry_id", enquiry_id);
			r.add("program_code", (String) h.get("program_code"));
			r.add("name", (String) h.get("name"));
			r.add("gender", (String) h.get("gender"));
			r.add("birth_date", (String) h.get("birth_date"));
			r.add("address1", (String) h.get("address1"));
			r.add("address2", (String) h.get("address2"));
			r.add("state", (String) h.get("state"));
			r.add("city", (String) h.get("city"));
			r.add("poscode", (String) h.get("poscode"));
			r.add("country_code", (String) h.get("country"));
			r.add("phone_home", (String) h.get("phone_home"));
			r.add("phone_mobile", (String) h.get("phone_mobile"));
			r.add("email", (String) h.get("email"));
			r.add("academic_qualification", (String) h.get("academic_qualification"));
			//
			r.add("date_post", r.unquote("now()"));
			//
			r.add("academic_year", Integer.parseInt((String) h.get("academic_year")));
			r.add("academic_grade", (String) h.get("academic_grade"));
			r.add("enquiry_body", (String) h.get("enquiry_body"));
			
			sql = r.getSQLInsert("enquiry");
			stmt.executeUpdate(sql);
			
			return enquiry_id;
			
		} catch ( SQLException sqlex ) {
			throw new Exception(sqlex.getMessage() + "-" + sql);
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	Hashtable getFormData() throws Exception {
		Hashtable h = new Hashtable();
		h.put("program_code", getParam("program_list"));
		
		h.put("name", getParam("name"));
		h.put("gender", getParam("gender"));
		
		String birth_date = getParam("birth_year") + "-" + fmt(getParam("birth_month")) + "-" + fmt(getParam("birth_day"));
		h.put("birth_date", birth_date);		
		
		h.put("address1", getParam("address1"));
		h.put("address2", getParam("address2"));
		h.put("state", getParam("state"));
		h.put("city", getParam("city"));
		h.put("poscode", getParam("poscode"));
		h.put("country", getParam("country_list"));
		h.put("phone_home", getParam("phone_home"));
		h.put("phone_mobile", getParam("phone_mobile"));
		h.put("email", getParam("email"));
		h.put("academic_qualification", getParam("academic_qualification"));
		h.put("academic_year", getParam("academic_year"));
		h.put("academic_grade", getParam("academic_grade"));
		h.put("enquiry_body", getParam("enq"));
		return h;
	}
	
	String fmt(String s) {
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}
	
	
	
}
		
		