/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.admission;
 

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.db.DbException;
import mecca.db.SQLRenderer;
import mecca.sis.struct.ProgramData;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class VetApplicantBySchemeModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/sis/vet_applicant_by_scheme.vm";

		String submit = getParam("command");
		
		String scheme_id = getParam("scheme_id");
		context.put("scheme_id", scheme_id);
		String program_code = getParam("program_code");
		context.put("program_code", program_code);
		//reset
		context.put("scheme_name", "");
		context.put("ruleList", new Vector());
		context.put("groupOpList", new Vector());	
		context.put("qualifiedList", new Vector());			
		
		//get list of scheme
		Vector schemeList = getschemeList();
		context.put("schemeList", schemeList);	
		
		//get program list
		Vector programList = ProgramData.getProgramList();
		context.put("programList", programList);
		
		
		String scheme_name = session.getAttribute("scheme_name") != null ? (String) session.getAttribute("scheme_name") : "";
		String program_name = session.getAttribute("program_name") != null ? (String) session.getAttribute("program_name") : "";
		Vector ruleList = session.getAttribute("ruleList") != null ? (Vector) session.getAttribute("ruleList") : new Vector();
		Vector qualifiedList = session.getAttribute("qualifiedList") != null ? (Vector) session.getAttribute("qualifiedList") : new Vector();
		Vector subjectIdList = session.getAttribute("subjectIdList") != null ? (Vector) session.getAttribute("subjectIdList") : new Vector();
		Vector groupOpList = session.getAttribute("groupOpList") != null ?	(Vector) session.getAttribute("groupOpList") : new Vector();
		Hashtable resultMap = session.getAttribute("resultMap") != null ?	(Hashtable) session.getAttribute("resultMap") : new Hashtable();
		
		
		if ( "run".equals(submit) ) {
			//get vetting criteria
			scheme_name = getSchemeName();
			session.setAttribute("scheme_name", scheme_name);
			
			program_name = ProgramData.getProgramName(program_code);
			session.setAttribute("program_name", program_name);
			
			context.put("scheme_name", scheme_name);
			context.put("program_name", program_name);

			
			
			ruleList = new Vector();
			qualifiedList = new Vector();
			subjectIdList = new Vector();
			groupOpList = new Vector();
			resultMap = new Hashtable();
			
			prepareRuleList(ruleList, resultMap, subjectIdList, groupOpList);			
			qualifiedList = runVet(ruleList, resultMap, subjectIdList, groupOpList);	
			
			session.setAttribute("ruleList", ruleList);
			session.setAttribute("qualifiedList", qualifiedList);
			session.setAttribute("subjectIdList", subjectIdList);
			session.setAttribute("groupOpList", groupOpList);
			session.setAttribute("resultMap", resultMap);
			
			context.put("ruleList", ruleList);
			context.put("groupOpList", groupOpList);	
			context.put("qualifiedList", qualifiedList);					
		}
		else if ( "view".equals(submit) ) {
			template_name = "vtl/sis/vet_applicant_hits.vm";
			context.put("scheme_name", scheme_name);
			context.put("qualifiedList", qualifiedList);
			context.put("ruleList", ruleList);
			context.put("groupOpList", groupOpList);	
			context.put("qualifiedList", qualifiedList);					
			
		}
		else if ( "selectmarked".equals(submit) ) {
			template_name = "vtl/sis/vet_applicant_hits.vm";
			
			Hashtable appStatus = new Hashtable();
			selectMarked(appStatus, qualifiedList, scheme_id, program_code);
			
			context.put("scheme_name", scheme_name);
			context.put("qualifiedList", qualifiedList);
			context.put("ruleList", ruleList);
			context.put("groupOpList", groupOpList);	
			context.put("qualifiedList", qualifiedList);					
		}
	
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	private String getSchemeName() throws Exception {
		String scheme_id = getParam("scheme_id");
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("rule_scheme_name");
			r.add("rule_scheme_id", scheme_id);
			sql = r.getSQLSelect("adm_rule_scheme_main");
			ResultSet rs = stmt.executeQuery(sql);
			if ( rs.next() ) return rs.getString("rule_scheme_name");
			else return "";
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	private Vector getschemeList() throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("rule_scheme_id");
			r.add("rule_scheme_name");
			sql = r.getSQLSelect("adm_rule_scheme_main", "rule_scheme_name");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("id", rs.getString("rule_scheme_id"));
				h.put("name", rs.getString("rule_scheme_name"));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}	
	}	
	
	Vector runVet(Vector ruleList, Hashtable resultMap, Vector subjectIdList, Vector groupOpList) throws Exception {
		String scheme_id = getParam("scheme_id");
		String program_code = getParam("program_code");
		Vector qualifiedList = new Vector();
		
		Db db = null;
		String sql = "";
		try {
			
			Hashtable programMap = ProgramData.getProgramCodeMap();
			
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();

			//prepare applicants list and put into vector
			Vector applicantList = new Vector();			
			{
				/*
				r.clear();
				r.add("a.applicant_id");
				r.add("a.applicant_name");
				r.add("a.applicant_id", r.unquote("c.applicant_id"));
				sql = r.getSQLSelect("adm_applicant a, adm_applicant_choice c");
				*/
				
				sql = "SELECT a.applicant_id, a.applicant_name, choice1, choice2, choice3, " +
				"vet_rule_scheme_id, vet_program_id " +
				"FROM adm_applicant a, adm_applicant_choice c " +
				"WHERE a.applicant_id = c.applicant_id ";
				
				if ( !"".equals(program_code)) {
					sql += "AND (c.choice1 = '" + program_code + "' " +
					"OR c.choice2 = '" + program_code + "' " +
					"OR c.choice3 = '" + program_code + "') ";
				}
				sql += "ORDER BY a.applicant_name";
				
				//System.out.println(sql);
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					h.put("id", rs.getString("applicant_id"));
					h.put("name", mecca.db.Db.getString(rs, "applicant_name"));
					String choice1 = mecca.db.Db.getString(rs,"choice1");
					String choice2 = mecca.db.Db.getString(rs,"choice2");
					String choice3 = mecca.db.Db.getString(rs,"choice3");
					String vet_rule_scheme_id = mecca.db.Db.getString(rs,"vet_rule_scheme_id");
					String vet_program_id = mecca.db.Db.getString(rs,"vet_program_id");
					if ( vet_program_id == null ) vet_program_id = "";
					h.put("choice", "");
					if ( choice3 != null && choice3.equals(program_code) ) h.put("choice", "3rd");
					if ( choice2 != null && choice2.equals(program_code) ) h.put("choice", "2nd");
					if ( choice1 != null && choice1.equals(program_code) ) h.put("choice", "1st");
					h.put("vet_rule_scheme_id", vet_rule_scheme_id);
					h.put("vet_program_id", vet_program_id);
					
					String vet_program_name = programMap.get(vet_program_id) != null ? (String) programMap.get(vet_program_id): "";
					
					h.put("vet_program_name", vet_program_name);
					
					//System.out.println((String) h.get("name") + ", " + (String) h.get("vet_program_id"));
					applicantList.addElement(h);
				}
			}
			
		
			//PURPOSE HERE IS TO GENERATE STRING OF 1's AND 0's
			{
				for ( int i = 0; i < applicantList.size(); i++ ) {
					Hashtable applicantData = (Hashtable) applicantList.elementAt(i);
					String applicant_id =  (String) applicantData.get("id");

					r.clear();
					r.add("a.adm_subject_id");
					r.add("a.adm_subject_grade");
					r.add("a.applicant_id", applicant_id);
					r.add("a.adm_subject_id", r.unquote("f.adm_subject_id"));
					r.add("f.qualifier_id", r.unquote("r.qualifier_id"));
					r.add("r.rule_scheme_id", scheme_id);
					sql = r.getSQLSelect("adm_applicant_exam a, adm_rule_scheme r, adm_qualifier_factor f", "r.rule_sequence");
					ResultSet rs = stmt.executeQuery(sql);
					Vector result = new Vector();
					Vector resultSubjectId = new Vector();
					
					//should clear resultMap
					clearResultMap(resultMap, subjectIdList);
					
					while ( rs.next() ) {
						String subject_id = rs.getString("adm_subject_id");
						String grade = rs.getString("adm_subject_grade");
						resultMap.put(subject_id, grade);
					}
					//
					StringBuffer _bit = new StringBuffer("");
					StringBuffer _bit2 = new StringBuffer("");
					StringBuffer _bit3 = new StringBuffer("");
					String rule_group_tmp = "";
					int group_cnt = 0;
					for ( int k = 0; k < ruleList.size(); k++ ) {
						Hashtable h = (Hashtable) ruleList.elementAt(k);
						//from rule
						String subject_id1 = (String) h.get("subject_id");	
						int grade1 = Integer.parseInt((String) h.get("grade"));
						String qualifier_operator = (String) h.get("qualifier_operator");
						
						//
						String rule_group = (String) h.get("rule_group");
						boolean b = true;
						if ( !rule_group.equals(rule_group_tmp) ) {
							rule_group_tmp = rule_group;
							if ( k > 0 ) {
								if ( _bit2.toString().length() > 0 ) _bit.append("-").append(_bit2.toString());
								_bit.append(")");
								b = false;
							}
							_bit.append("(");
							_bit2 = new StringBuffer("");
						}
						//
						if ( k > 0 && b) {
							_bit2.append(((String) h.get("condition_operator")).equals("OR") ? "0":"1");
						}
						//from student
						int grade2 = Integer.parseInt((String) resultMap.get(subject_id1));
						
						
						if ( grade2 > 0 ) {
							if ( "eqless".equals(qualifier_operator) ) {
								_bit.append(grade2 <= grade1 ? "1":"0");	
							}
							if ( "eqmore".equals(qualifier_operator) ) {
								_bit.append(grade2 >= grade1 ? "1":"0");	
							}
							if ( "eq".equals(qualifier_operator) ) {
								_bit.append(grade2 == grade1 ? "1":"0");	
							}	
							if ( "more".equals(qualifier_operator) ) {
								_bit.append(grade2 > grade1 ? "1":"0");	
							}
							if ( "less".equals(qualifier_operator) ) {
								_bit.append(grade2 < grade1 ? "1":"0");	
							}
							
						} else {
							_bit.append("0");	
						}
					}
					if ( _bit2.toString().length() > 0 ) _bit.append("-").append(_bit2.toString());
					_bit.append(")");					
					for ( int j = 1; j < groupOpList.size(); j++ ) {
						_bit3.append(((String) groupOpList.elementAt(j)).equals("OR") ? "0":"1" );
					}
					String _bit_result = "";
					if ( _bit3.toString().length() > 0 ) {
						_bit_result = _bit.append("-").append(_bit3.toString()).toString();
					} else
						_bit_result = _bit.toString();
					
					Vector hitList = new Vector();
					int analyzed = VetStringAnalyzer.doProcess(_bit_result, hitList);
					if ( analyzed == 1 ) {
						applicantData.put("hitList", hitList);
						qualifiedList.addElement(applicantData);
					}
				}
			}
			
			
			return qualifiedList;			
		} catch ( DbException dbex ) {
			throw dbex;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	private void prepareRuleList(Vector ruleList, Hashtable resultMap, Vector subjectIdList, Vector groupOpList) throws Exception {
		
		String scheme_id = getParam("scheme_id");
		if ( "".equals(scheme_id) ) return;
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			r.add("r.qualifier_id");
			r.add("r.condition_operator");
			r.add("f.adm_subject_id");
			r.add("f.qualifier_operator");
			r.add("f.qualifier_subject_grade AS grade");
			r.add("r.rule_group");
			r.add("r.rule_scheme_id", scheme_id);
			r.add("r.qualifier_id", r.unquote("f.qualifier_id"));
			sql = r.getSQLSelect("adm_rule_scheme r, adm_qualifier_factor f", "r.rule_group, r.rule_sequence");
			ResultSet rs = stmt.executeQuery(sql);
			int group_num = -1;
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				String qualifier_id = rs.getString("qualifier_id");
				String condition_operator = rs.getInt("condition_operator") == 0 ? "OR":"AND";
				String subject_id = rs.getString("adm_subject_id");
				String qualifier_operator = rs.getString("qualifier_operator");
				String grade = rs.getString("grade");
				int rule_group = rs.getInt("rule_group");
				if ( group_num != rule_group ) {
					group_num = rule_group;
					groupOpList.addElement(condition_operator);
					condition_operator = "";
				}				
				h.put("qualifier_id", qualifier_id);
				h.put("subject_id", subject_id);
				h.put("group", Integer.toString(rule_group));
				h.put("qualifier_operator", qualifier_operator);
				h.put("grade", grade);
				h.put("condition_operator", condition_operator);
				h.put("rule_group", Integer.toString(rule_group));
				ruleList.addElement(h);
				
				
				resultMap.put(subject_id, "0");
				subjectIdList.addElement(subject_id);
			}
		} catch ( DbException dbex ) {
			throw dbex;
		} catch ( SQLException sqlex ) {
			throw sqlex;
		} finally {
			if ( db != null ) db.close();
		}
			
		
	}	
	
	void clearResultMap(Hashtable resultMap, Vector subjectIdList) {
		for ( int i = 0; i < subjectIdList.size(); i++ ) {
			resultMap.put((String) subjectIdList.elementAt(i), "0");	
		}
	}
	
	
	private void selectMarked(Hashtable status, Vector applicantList, String scheme_id, String program_code) throws Exception {
		String[] appIds = request.getParameterValues("app_ids");
		Vector ids = new Vector();
		if ( appIds != null ) {
			for ( int i = 0; i < appIds.length; i++ ) {
				ids.addElement(appIds[i]);
			}
		}
		
		Db db = null;
		String sql = "";
		try {
			
			Hashtable programMap = ProgramData.getProgramCodeMap();
			
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			//{
			//	sql = "UPDATE adm_applicant SET vet_rule_scheme_id = '', vet_program_id = '', vet_date = ''";	
			//	stmt.executeUpdate(sql);
			//}
			
			
			for ( int i = 0; i < applicantList.size(); i++ ) {
				Hashtable applicantData = (Hashtable) applicantList.elementAt(i);
				String applicant_id =  (String) applicantData.get("id");
				applicantData.put("marked", "no");

				
				if ( ids.contains(applicant_id) ) {
					applicantData.put("marked", "yes");
					applicantData.put("vet_program_id", program_code);
					applicantData.put("vet_program_name", (String) programMap.get(program_code));					
					r.clear();
					r.add("vet_rule_scheme_id", scheme_id);
					r.add("vet_program_id", program_code);
					r.add("vet_date", r.unquote("now()"));
					r.update("applicant_id", applicant_id);
					sql = r.getSQLUpdate("adm_applicant");
					System.out.println(sql);
					stmt.executeUpdate(sql);
				}
			}

		} finally {
			if ( db != null ) db.close();
		}		
	}
	
}