/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.admission;
 

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.db.SQLRenderer;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class OfferLetterModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/sis/offer_letter_get.vm";
		String submit = getParam("command");
		
		if ( "search".equals(submit) ) {
			template_name = "vtl/sis/offer_letter_search.vm";
			Hashtable result = getSearchApplicantByName();
			context.put("searchResult", result);
		}
		else if ( "getapplicant".equals(submit) ) {
			template_name = "vtl/sis/offer_letter_edit.vm";
			String applicant_id = getParam("applicant_id");
			Hashtable h = getOfferLetter(applicant_id);
			context.put("offerLetter", h);
		}	
		else if ( "save".equals(submit) ) {
			template_name = "vtl/sis/offer_letter_edit.vm";
			String applicant_id = getParam("applicant_id");
			saveApplicantOfferLetter(applicant_id);
			Hashtable h = getOfferLetter(applicant_id);
			context.put("offerLetter", h);			
		}		
	
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	Hashtable getSearchApplicantByName() throws Exception {
		String value = getParam("applicant_name");
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			Hashtable result = new Hashtable();
			Vector v = new Vector();
			{
				r.add("applicant_id");
				r.add("applicant_name");
				r.add("applicant_name", "%" + value + "%", "LIKE");
				sql = r.getSQLSelect("adm_applicant", "applicant_name");
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					h.put("id",  rs.getString("applicant_id"));
					h.put("name", rs.getString("applicant_name"));
					v.addElement(h);
				}
			}
			result.put("criteria", value);
			result.put("studentList", v);
			return result;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	Hashtable getOfferLetter(String applicant_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("applicant_name");
			r.add("offer_letter_addr");
			r.add("offer_letter_salutation");
			r.add("offer_letter_subject");
			r.add("offer_letter_signature");
			r.add("offer_letter_text");
			r.add("applicant_id", applicant_id);
			sql = r.getSQLSelect("adm_applicant");
			Hashtable h = new Hashtable();
			h.put("applicant_id", applicant_id);
			ResultSet rs = stmt.executeQuery(sql);
			if ( rs.next() ) {
				h.put("applicant_name", mecca.db.Db.getString(rs, "applicant_name"));
				h.put("applicant_address", mecca.db.Db.getString(rs, "offer_letter_addr"));
				h.put("salutation", mecca.db.Db.getString(rs, "offer_letter_salutation"));
				h.put("subject", mecca.db.Db.getString(rs, "offer_letter_subject"));
				h.put("signature", mecca.db.Db.getString(rs, "offer_letter_signature"));
				h.put("body", mecca.db.Db.getString(rs, "offer_letter_text"));
			}	
			return h;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	void saveApplicantOfferLetter(String applicant_id) throws Exception {
		
		String applicant_address = getParam("applicant_address");
		String salutation = getParam("salutation");
		String subject = getParam("subject");
		String body = getParam("body");
		String signature = getParam("signature");
		
		
		Db db = null;
		String sql="";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			r.add("offer_letter_text", body);
			r.add("offer_letter_addr", applicant_address);
			r.add("offer_letter_salutation", salutation);
			r.add("offer_letter_subject", subject);
			r.add("offer_letter_signature", signature);
			r.update("applicant_id", applicant_id);
			sql = r.getSQLUpdate("adm_applicant");
			stmt.executeUpdate(sql);
			
		} finally {
			if ( db != null ) db.close();
		}	
	}	
	
	
}



