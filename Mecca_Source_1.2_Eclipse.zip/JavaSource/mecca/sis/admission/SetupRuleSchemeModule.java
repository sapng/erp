/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.admission;
   

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.db.DbException;
import mecca.db.SQLRenderer;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class SetupRuleSchemeModule extends mecca.portal.velocity.VTemplate {
	
	private int current_group = 0;
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/sis/setup_rule_scheme.vm";

		String submit = getParam("command");
		
		String scheme_id = getParam("scheme_id");
		String scheme_name = getParam("scheme_name");
		context.put("scheme_id", scheme_id);
		context.put("scheme_name", scheme_name);
		
		if ( "add".equals(submit) ) {
			add(false);		
		}
		if ( "newgroup".equals(submit) ) {
			add(true);		
		}		
		else if ( "delete".equals(submit) ) {
			delete();
		}
		else if ( "createnew".equals(submit) ) {
			createnew();	
		}
		else if ( "getdata".equals(submit) ) {
			scheme_name = getdata(scheme_id);	
			context.put("scheme_name", scheme_name);
		}
		else if ( "updatename".equals(submit) ) {
			updatename();	
			context.put("scheme_name", scheme_name);
		}		
		Vector list = getListMain();
		context.put("list", list);
		Vector ruleList = new Vector();
		Vector ruleIdList = new Vector();
		Vector groupOpList = new Vector();
		prepareRuleList(ruleList, ruleIdList, groupOpList);
		context.put("ruleList", ruleList);
		context.put("groupOpList", groupOpList);
		
		String group_no = getParam("group_no");
		if ( "".equals(group_no) )
			context.put("current_group", Integer.toString(current_group));
		else
			context.put("current_group", group_no);
		
		//get list of qualifiers
		Vector qualifierList = getQualifierList(ruleIdList);
		context.put("qualifierList", qualifierList);
		
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	private Vector getListMain() throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("rule_scheme_name");
			r.add("rule_scheme_id");
			sql = r.getSQLSelect("adm_rule_scheme_main");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("name", rs.getString("rule_scheme_name"));
				h.put("id", rs.getString("rule_scheme_id"));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	private String getdata(String scheme_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("rule_scheme_name");
			r.add("rule_scheme_id", scheme_id);
			sql = r.getSQLSelect("adm_rule_scheme_main");
			ResultSet rs = stmt.executeQuery(sql);
			if ( rs.next() ) return rs.getString("rule_scheme_name");
			else return "";
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	private void createnew() throws Exception {
		String scheme_id = getParam("scheme_id");
		String scheme_name = getParam("scheme_name");
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			//check if id already exists
			r.add("rule_scheme_id");
			r.add("rule_scheme_id", scheme_id);
			sql = r.getSQLSelect("adm_rule_scheme_main");
			ResultSet rs = stmt.executeQuery(sql);
			if ( rs.next() ) throw new Exception("Rule Scheme Id already exists!");
			
			r.clear();
			r.add("rule_scheme_id", scheme_id);
			r.add("rule_scheme_name", scheme_name);
			sql = r.getSQLInsert("adm_rule_scheme_main");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	private void updatename() throws Exception {
		String scheme_id = getParam("scheme_id");
		String scheme_name = getParam("scheme_name");
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("rule_scheme_name", scheme_name);
			r.update("rule_scheme_id", scheme_id);			
			sql = r.getSQLUpdate("adm_rule_scheme_main");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	private void prepareRuleList(Vector ruleList, Vector ruleIdList, Vector groupOpList) throws Exception {
		
		String scheme_id = getParam("scheme_id");
		if ( "".equals(scheme_id) ) return;
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			r.add("r.qualifier_id");
			r.add("r.condition_operator");
			r.add("f.adm_subject_id");
			r.add("f.qualifier_operator");
			r.add("f.qualifier_subject_grade AS grade");
			r.add("gr.adm_grade_display");
			r.add("r.rule_group");
			r.add("r.rule_scheme_id", scheme_id);
			r.add("r.qualifier_id", r.unquote("f.qualifier_id"));
			r.add("ex.adm_subject_id", r.unquote("f.adm_subject_id"));
			r.add("ex.adm_grade_display_id", r.unquote("gr.adm_grade_display_id"));
			r.add("f.qualifier_subject_grade", r.unquote("gr.adm_grade_value"));
			sql = r.getSQLSelect("adm_rule_scheme r, adm_qualifier_factor f,  adm_display_grade gr, adm_exam_subject ex", "r.rule_group, r.rule_sequence");
			ResultSet rs = stmt.executeQuery(sql);
			int group_num = -1, group_cnt = 0;
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				String qualifier_id = rs.getString("qualifier_id");
				String condition_operator = rs.getInt("condition_operator") == 0 ? "OR":"AND";
				String subject_id = rs.getString("adm_subject_id");
				String qualifier_operator = rs.getString("qualifier_operator");
				String grade = rs.getString("grade");
				String grade_display = rs.getString("adm_grade_display");
				int group = rs.getInt("rule_group");
				if ( group_num != group ) {
					group_num = group;
					groupOpList.addElement(condition_operator);
					condition_operator = "";
				}
				h.put("qualifier_id", qualifier_id);
				h.put("operator", condition_operator);
				h.put("group", Integer.toString(group));
				String operator = "";
				if ("eqless".equals(qualifier_operator)) operator = "EQUAL OR LESS TO";
				else if ("eqmore".equals(qualifier_operator)) operator = "EQUAL OR MORE TO";
				else if ("eq".equals(qualifier_operator)) operator = "EQUAL TO";
				else if ("more".equals(qualifier_operator)) operator = "MORE THAN";
				else if ("less".equals(qualifier_operator)) operator = "LESS THAN";
				
				h.put("description", subject_id + " " + operator + " " + grade_display);

				ruleList.addElement(h);
				ruleIdList.addElement(qualifier_id);
			}
			current_group = group_num;
		} catch ( DbException dbex ) {
			throw dbex;
		} catch ( SQLException sqlex ) {
			throw sqlex;
		} finally {
			if ( db != null ) db.close();
		}
			
		
	}
	
	private void add(boolean isNewGroup) throws Exception {
		
		String scheme_id = getParam("scheme_id");
		String qualifier_id = getParam("qualifier_id");
		String condition_operator = getParam("condition_operator");
		String group_no = getParam("group_no");
		
		
		if ( "".equals(qualifier_id)  ) throw new Exception("Can not have empty fields!");
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			//get sequence number
			int seq = 0;
			{			
				r.add("MAX(rule_sequence) AS seq");
				r.add("rule_scheme_id", scheme_id);
				sql = r.getSQLSelect("adm_rule_scheme");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) seq = rs.getInt("seq");
			}
			
			//get group number
			if ( "".equals(group_no) ) {
				r.clear();
				r.add("MAX(rule_group) AS group_no");
				r.add("rule_scheme_id", scheme_id);
				sql = r.getSQLSelect("adm_rule_scheme");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) current_group = rs.getInt("group_no");	
			} else {
				current_group = Integer.parseInt(group_no);	
			}
			
			if ( isNewGroup ) {
				r.clear();
				r.add("MAX(rule_group) AS group_no");
				r.add("rule_scheme_id", scheme_id);
				sql = r.getSQLSelect("adm_rule_scheme");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) current_group = rs.getInt("group_no");	
				//increment by 1				
				++current_group;
			}
			
			r.clear();
			r.add("rule_scheme_id", scheme_id);
			r.add("qualifier_id", qualifier_id);	
			r.add("rule_sequence", ++seq);
			r.add("condition_operator", condition_operator);
			r.add("rule_group", current_group);
			
			sql = r.getSQLInsert("adm_rule_scheme");
			stmt.executeUpdate(sql);
			
		} catch ( DbException dbex ) {
			throw dbex;
		} catch ( SQLException sqlex ) {
			throw sqlex;
		} finally {
			if ( db != null ) db.close();
		}		
	}
	
	private void delete() throws Exception {
		String scheme_id = getParam("scheme_id");
		String qualifier_id = getParam("qualifier_id");
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			sql = "DELETE FROM adm_rule_scheme WHERE rule_scheme_id = '" + scheme_id + "' AND qualifier_id = '" + qualifier_id + "'";
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}		
	}
	

	//get qualifiers NOT IN ruleList
	private Vector getQualifierList(Vector ruleIdList) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("q.qualifier_id");
			r.add("q.adm_subject_id");
			r.add("q.qualifier_subject_grade");
			r.add("q.qualifier_operator");
			sql = r.getSQLSelect("adm_qualifier_factor q");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				String qualifier_id = rs.getString("qualifier_id");
				if ( !ruleIdList.contains(qualifier_id) ) {
					Hashtable h = new Hashtable();
					h.put("id", qualifier_id);
					h.put("subject_id", rs.getString("adm_subject_id"));
					h.put("grade", rs.getString("qualifier_subject_grade"));
					h.put("operator", rs.getString("qualifier_operator"));
					v.addElement(h);
				}
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}	
	}	
	

	
}