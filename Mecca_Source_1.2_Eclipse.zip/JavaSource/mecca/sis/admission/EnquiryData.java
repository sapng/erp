/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.admission;


import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class EnquiryData {
	
	private static String fmt(String s) {
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}
	
	static Hashtable getData(String enquiry_id) throws Exception {

		Db db = null;
		String sql= "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			

			r.add("enquiry_id");
			r.add("e.program_code");
			r.add("p.program_name");
			r.add("name");
			r.add("gender");
			r.add("birth_date");
			r.add("address1");
			r.add("address2");
			r.add("state");
			r.add("city");
			r.add("poscode");
			r.add("country_code");
			r.add("phone_home");
			r.add("phone_mobile");
			r.add("email");
			r.add("academic_qualification");
			//
			r.add("academic_year");
			r.add("academic_grade");
			r.add("enquiry_body");
			//
			//
			r.add("date_post");
			//
			r.add("date_post");
			//
			//		
			r.add("status");	
			r.add("enquiry_id", enquiry_id);
			r.add("e.program_code", r.unquote("p.program_code"));
			
			sql = r.getSQLSelect("enquiry e, program p");
			
			ResultSet rs = stmt.executeQuery(sql);
			Hashtable h = new Hashtable();
			if ( rs.next() ) {
				h = getResultSetData(rs);
			}
			return h;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	static Hashtable getResultSetData(ResultSet rs) throws Exception {
		Hashtable h = new Hashtable();
		h.put("enquiry_id", rs.getString("enquiry_id"));
		h.put("program_code", rs.getString("program_code"));
		h.put("program_name", rs.getString("program_name"));
		h.put("name", rs.getString("name"));
		h.put("gender", rs.getString("gender"));
		h.put("birth_date", rs.getString("birth_date"));		
		h.put("address1", rs.getString("address1"));
		h.put("address2", rs.getString("address2"));
		h.put("state", rs.getString("state"));
		h.put("city", rs.getString("city"));
		h.put("poscode", rs.getString("poscode"));
		h.put("country", rs.getString("country_code"));
		h.put("phone_home", rs.getString("phone_home"));
		h.put("phone_mobile", rs.getString("phone_mobile"));
		h.put("email", rs.getString("email"));
		h.put("academic_qualification", rs.getString("academic_qualification"));
		h.put("academic_year", rs.getString("academic_year"));
		h.put("academic_grade", rs.getString("academic_grade"));
		h.put("enquiry_body", rs.getString("enquiry_body"));
		h.put("date_post", rs.getString("date_post"));
		
		java.util.Date birthDate = rs.getDate("birth_date");
		
		Calendar c = new java.util.GregorianCalendar();
		c.setTime(birthDate);	
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH) + 1;
		int day = c.get(Calendar.DAY_OF_MONTH);		
		
		h.put("birth_year", new Integer(year));
		h.put("birth_month", new Integer(month));
		h.put("birth_day", new Integer(day));
		
		//h.put("birth_date_display", infusion.sis.tools.DateTool.asShortMonth((Integer) h.get("birth_year"), (Integer) h.get("birth_month"), (Integer) h.get("birth_day")));
		h.put("birth_date_display", mecca.sis.tools.DateTool.getDateFormatted(rs.getDate("birth_date")));
		
		java.util.Date postDate = rs.getDate("date_post");
		
		c.setTime(postDate);	
		year = c.get(Calendar.YEAR);
		month = c.get(Calendar.MONTH) + 1;
		day = c.get(Calendar.DAY_OF_MONTH);		
		
		
		h.put("post_year", new Integer(year));
		h.put("post_month", new Integer(month));
		h.put("post_day", new Integer(day));
		
		//h.put("post_date_display", infusion.sis.tools.DateTool.asShortMonth((Integer) h.get("post_year"), (Integer) h.get("post_month"), (Integer) h.get("post_day")));
		h.put("post_date_display", mecca.sis.tools.DateTool.getDateFormatted(rs.getDate("date_post")));

		h.put("status", mecca.db.Db.getString(rs, "status"));
				
		return h;
	}	
	
	static Vector getList() throws Exception {

		Db db = null;
		String sql= "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			

			r.add("enquiry_id");
			r.add("e.program_code");
			r.add("p.program_name");
			r.add("name");
			r.add("gender");
			r.add("birth_date");
			r.add("address1");
			r.add("address2");
			r.add("state");
			r.add("city");
			r.add("poscode");
			r.add("country_code");
			r.add("phone_home");
			r.add("phone_mobile");
			r.add("email");
			r.add("academic_qualification");
			//
			r.add("academic_year");
			r.add("academic_grade");
			r.add("enquiry_body");
			//
			//
			r.add("date_post");
			//
			//			
			r.add("status");
			r.add("e.program_code", r.unquote("p.program_code"));
			
			sql = r.getSQLSelect("enquiry e, program p", "date_post DESC");
			
			System.out.println(sql);
			
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h = getResultSetData(rs);
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	static Integer getInteger(ResultSet rs, String name) throws Exception {
		String s = rs.getString(name);
		if ( s != null ) return new Integer(s);
		else return new Integer(0);	
	}
	
	static Vector getEnquiryStatus() throws Exception { 
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			Vector v = new Vector();
			SQLRenderer r = new SQLRenderer();
			
			r.add("status_id");
			r.add("status_name");
			r.add("status_description");
			sql = r.getSQLSelect("enquiry_status", "status_name");
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next()) {
				Hashtable h = new Hashtable();
				h.put("id", mecca.db.Db.getString(rs, "status_id"));
				h.put("name", mecca.db.Db.getString(rs, "status_name"));
				h.put("description", mecca.db.Db.getString(rs, "status_description"));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	static void setEnquiryStatus(String id, String status) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.update("enquiry_id", id);
			r.add("status", status);
			sql = r.getSQLUpdate("enquiry");
			stmt.executeUpdate(sql);
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	static void addNewStatus(String id, String name, String description, String enquiry_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			boolean found = false;
			{
				sql = "select status_id from enquiry_status where status_id = '" + id + "'";
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next()) found = true;
			}	
			if ( !found ) {
				{
					r.clear();
					r.add("status_id", id);
					r.add("status_name", name);
					r.add("status_description", description);
					sql = r.getSQLInsert("enquiry_status");
					stmt.executeUpdate(sql);	
				}	
				{
					r.clear();
					r.add("status", id);
					r.update("enquiry_id", enquiry_id);
					sql = r.getSQLUpdate("enquiry");
					stmt.executeUpdate(sql);
				}
			}
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
}