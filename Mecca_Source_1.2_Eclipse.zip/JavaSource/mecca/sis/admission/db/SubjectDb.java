/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.admission.db;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.DbException;
import mecca.db.SQLRenderer;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class SubjectDb {

	public static Vector getList() throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("subj.adm_exam_id");
			r.add("adm_subject_id");
			r.add("adm_subject_name");
			r.add("subj.adm_exam_id", r.unquote("ex.adm_exam_id"));
			sql = r.getSQLSelect("adm_exam_subject subj, adm_exam ex");	
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("exam_id", rs.getString("adm_exam_id"));
				h.put("id", rs.getString("adm_subject_id"));
				h.put("name", rs.getString("adm_subject_name"));
				v.addElement(h);
			}
			return v;
		} catch ( DbException dbex ) {
			throw dbex;
		} catch ( SQLException sqlex ) {
			throw sqlex;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Vector getExamInfo() throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			//prepare grade detail
			Vector gradeIdList = new Vector();
			{
				r.clear();
				r.add("adm_grade_display_id");
				sql = r.getSQLSelect("adm_display_grade_main");
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					gradeIdList.addElement(rs.getString("adm_grade_display_id"));	
				}
			}
			
			Hashtable gradeDisplay = new Hashtable();
			int maxvalue = 0;
			for ( int i = 0; i < gradeIdList.size(); i++ ) {
				String grade_id = (String) gradeIdList.elementAt(i);
				r.clear();
				r.add("adm_grade_value");
				r.add("adm_grade_display");
				r.add("adm_grade_display_id", grade_id);
				sql = r.getSQLSelect("adm_display_grade", "adm_grade_value");
				ResultSet rs = stmt.executeQuery(sql);
				Hashtable h = new Hashtable();
				int value = 0;
				while ( rs.next() ) {
					value = rs.getInt("adm_grade_value");
					String display = rs.getString("adm_grade_display");
					h.put(new Integer(value), display);
				}
				h.put("display_id", grade_id);
				h.put("max", new Integer(value));
				gradeDisplay.put(grade_id, h);
			}
			
			//get exam list
			Vector examList = new Vector();
			{
				r.clear();
				r.add("adm_exam_id");
				r.add("adm_exam_name");
				r.add("display");
				sql = r.getSQLSelect("adm_exam");
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					h.put("id", rs.getString("adm_exam_id"));
					h.put("name", rs.getString("adm_exam_name"));			
					h.put("display", mecca.db.Db.getString(rs, "display"));
					examList.addElement(h);
				}	
			}
			
			for ( int i = 0; i < examList.size(); i++ ) {
				Hashtable exam = (Hashtable) examList.elementAt(i);
				r.clear();
				r.add("subj.adm_exam_id");
				r.add("adm_subject_id");
				r.add("adm_subject_name");
				r.add("adm_grade_display_id");
				r.add("subj.adm_exam_id", r.unquote("ex.adm_exam_id"));
				r.add("ex.adm_exam_id", (String) exam.get("id"));
				sql = r.getSQLSelect("adm_exam_subject subj, adm_exam ex");	
				ResultSet rs = stmt.executeQuery(sql);
				Vector subjects = new Vector();
				while ( rs.next() ) {
					
					Hashtable h = new Hashtable();
					h.put("exam_id", rs.getString("adm_exam_id"));
					h.put("id", rs.getString("adm_subject_id"));
					h.put("name", rs.getString("adm_subject_name"));
					String grade_id = rs.getString("adm_grade_display_id");
					h.put("grade_id", grade_id);
					if ( gradeDisplay.get(grade_id) != null ) {
						h.put("gradeDisplay", gradeDisplay.get(grade_id));
					}
					subjects.addElement(h);
				}
				exam.put("subjects", subjects);
			}
			
			return examList;
			
		} catch ( DbException dbex ) {
			throw dbex;
		} catch ( SQLException sqlex ) {
			throw sqlex;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Hashtable getSubjectGrade() throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			Vector v = new Vector();
			{
				r.add("adm_subject_id");
				sql = r.getSQLSelect("adm_exam_subject");
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					v.addElement(rs.getString("adm_subject_id"));	
				}
			}
			Hashtable subjects = new Hashtable();
			for ( int i=0; i < v.size(); i++ ) {
				String subject_id = (String) v.elementAt(i);
				r.clear();
				r.add("grade_value");
				r.add("grade_display");
				r.add("adm_subject_id", subject_id);
				sql = r.getSQLSelect("adm_subject_grade");
				Hashtable h = new Hashtable();
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					int value = rs.getInt("grade_value");
					String display = rs.getString("grade_display");
					h.put(new Integer(value), display);
				}
				subjects.put(subject_id, h);
			}
			return subjects;
		} finally {
			if ( db != null ) db.close();
		}			
				
	}
	
	public static Hashtable getDisplayGrade() throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			Vector ids = new Vector();
			{
				r.add("adm_grade_display_id");
				sql = r.getSQLSelect("adm_display_grade_main");
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					ids.addElement(rs.getString("adm_grade_display_id"));
				}
			}
			
			Hashtable grades = new Hashtable();
			for ( int i = 0; i < ids.size(); i++ ) {
				String id = (String) ids.elementAt(i);	
				r.clear();
				r.add("adm_grade_value");
				r.add("adm_grade_display");
				r.add("adm_grade_display_id", id);
				sql = r.getSQLSelect("adm_display_grade", "adm_grade_value");
				ResultSet rs = stmt.executeQuery(sql);
				Hashtable h = new Hashtable();
				int cnt = 0;
				while ( rs.next() ) {
					cnt++;
					int value = rs.getInt("adm_grade_value");
					String display = rs.getString("adm_grade_display");
					h.put(new Integer(value), display);
				}
				h.put("max", new Integer(cnt));
				grades.put(id, h);
			}
			grades.put("gradeList", ids);
			return grades;
		} finally {
			if ( db != null ) db.close();
		}			
	}
	
}
