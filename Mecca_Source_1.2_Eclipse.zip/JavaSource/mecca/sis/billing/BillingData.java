/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.billing;


import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.DbDelegator;
import mecca.db.SQLRenderer;
import mecca.db.UniqueID;
import mecca.sis.billing.ReportData.NameComparator;
import mecca.sis.registration.StudentData;
import mecca.sis.struct.PeriodData;
import mecca.util.DateTool;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class BillingData {  
	
	static String[] monthname= {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
	
	public static String formatDate(int year, int month, int day) {
		String strdate = day + " " + monthname[month-1] + ", " + year;
		return strdate;
	}
	
	public static Hashtable getStudentInfo(String student_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			Hashtable h = new Hashtable();
			{
				r.add("id", student_id);
				r.add("name");
				r.add("address1");
				r.add("address2");
				r.add("address3");
				r.add("city");
				r.add("state");
				r.add("poscode");
				r.add("country_code");
				r.add("phone");
				sql = r.getSQLSelect("student");
				ResultSet rs = stmt.executeQuery(sql);
				
				if ( rs.next() ) {
					h.put("id", student_id);
					h.put("name", mecca.db.Db.getString(rs, "name"));
					h.put("address1", mecca.db.Db.getString(rs, "address1"));
					h.put("address2", mecca.db.Db.getString(rs, "address2"));
					h.put("address3", mecca.db.Db.getString(rs, "address3"));
					h.put("city", mecca.db.Db.getString(rs, "city"));
					h.put("poscode", mecca.db.Db.getString(rs, "poscode"));
					h.put("state", mecca.db.Db.getString(rs, "state"));
					String code = mecca.db.Db.getString(rs, "country_code");
					h.put("country_code", code);
					String countryname = mecca.general.CountryData.getCountryName(code);
					h.put("country", countryname);
					h.put("phone", mecca.db.Db.getString(rs, "phone"));
				}
			}
			{
				r.clear();
				r.add("student_id", student_id);
				r.add("c.intake_session");
				r.add("c.program_code");
				r.add("s.session_name");
				r.add("p.program_name");
				r.add("c.intake_session", r.unquote("s.session_id"));
				r.add("c.program_code", r.unquote("p.program_code"));
				sql = r.getSQLSelect("student_course c, session s, program p");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) {
					h.put("intake_session", mecca.db.Db.getString(rs, "intake_session"));
					h.put("program_code", mecca.db.Db.getString(rs, "program_code"));
					h.put("session_name", mecca.db.Db.getString(rs, "session_name"));
					h.put("program_name", mecca.db.Db.getString(rs, "program_name"));
				} else {
					h.put("intake_session", "" );
					h.put("program_code", "" );
					h.put("session_name", "");
					h.put("program_name", "");
				}	
			}
			return h;
		} finally {
			if ( db != null ) db.close();
		}	
	}


	
	public static void getPayment(Statement stmt, String student_id) throws Exception {
		String sql = "";
		
	}
	
	public static Hashtable getBillingInfo(String student_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("student_id", student_id);
			r.add("bill_no");
			r.add("bill_date");
			r.add("amount_total");
			sql = r.getSQLSelect("student_billing");
			ResultSet rs = stmt.executeQuery(sql);
			Hashtable info = new Hashtable();
			Vector v = new Vector();
			float total = 0.0f;
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("student_id", student_id);
				h.put("bill_no", mecca.db.Db.getString(rs, "bill_no"));
				h.put("bill_date", getDateFormatted(rs.getDate("bill_date")));				
				float amount_total = rs.getFloat("amount_total");
				total += amount_total;
				h.put("amount_total", getDecimalFormatted(amount_total));
				v.addElement(h);
			}
			info.put("items", v);
			info.put("total", Float.toString(total));
			
			return info;
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	public static void createBilling(Vector fees, String bill_no, Hashtable studentInfo, Hashtable billDate) throws Exception {
		String student_id = (String) studentInfo.get("id");
		String bill_date = ((Integer) billDate.get("year")).intValue() + "-" + fmt((Integer) billDate.get("month")) + "-" + fmt((Integer) billDate.get("day"));
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			boolean found = false;
			{
				r.clear();
				r.add("student_id", student_id);
				r.add("bill_no", bill_no);
				r.add("bill_date");
				sql = r.getSQLSelect("student_billing");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) found = true;
			}			
			//new student_billing
			if ( !found ) {
				r.clear();
				r.add("student_id", student_id);
				r.add("bill_no", bill_no);
				r.add("bill_date", bill_date);
				sql = r.getSQLInsert("student_billing");
				//System.out.println(sql);
				stmt.executeUpdate(sql);
			} else {
				r.clear();
				r.update("student_id", student_id);
				r.update("bill_no", bill_no);
				r.add("bill_date", bill_date);
				sql = r.getSQLUpdate("student_billing");
				stmt.executeUpdate(sql);				
			}
			
			//remove first
			{
				r.clear();
				r.add("student_id", student_id);
				r.add("bill_no", bill_no);
				sql = r.getSQLDelete("student_billing_detail");
				stmt.executeUpdate(sql);
				
			}
			
			//create items
			float amount_total = 0.0f;
			for ( int i=0; i < fees.size(); i++ ) {
				Hashtable fee = (Hashtable) fees.elementAt(i);
				r.clear();
				r.add("student_id", student_id);
				r.add("bill_no", bill_no);
				r.add("fee_id", (String) fee.get("id"));
				float amount = ((Float) fee.get("amount")).floatValue();
				amount_total += amount;
				r.add("amount", amount);
				
				//
				r.add("period_id", (String) fee.get("period_id"));
				r.add("session_id", (String) fee.get("session_id"));
				//xxxx
				//System.out.println(sql);
				
				sql = r.getSQLInsert("student_billing_detail");
				stmt.executeUpdate(sql);
			}
			//update amount_total
			{
				r.clear();
				r.update("student_id", student_id);
				r.update("bill_no", bill_no);
				r.add("amount_total", amount_total);
				sql = r.getSQLUpdate("student_billing");
				stmt.executeUpdate(sql);				
			}
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static String fmt(String s) {
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}
	
	public static String fmt(int i) {
	    String s = Integer.toString(i);
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}
	
	public static String fmt(Integer i) {
	    String s = Integer.toString(i.intValue());
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}
	
	public static Hashtable getStudentBilling(Hashtable studentInfo, String bill_no) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			Hashtable info = new Hashtable();
			SQLRenderer r = new SQLRenderer();
			
			String student_id = (String) studentInfo.get("id");
			//String session_id = (String) studentInfo.get("intake_session");
			String program_code = (String) studentInfo.get("program_code");

			//student_billing_detail
			float amount_total = 0.0f;
			{
				r.clear();
				r.add("d.student_id", student_id);
				r.add("d.bill_no", bill_no);
				r.add("fs.program_code", program_code);
				//r.add("fs.session_id", session_id);
				r.add("d.fee_id", r.unquote("fs.fee_id"));
				r.add("d.fee_id");
				r.add("fs.fee_code");
				r.add("fs.fee_description");
				r.add("d.amount");				
				sql = r.getSQLSelect("student_billing_detail d, fee_structure_program fs");
				ResultSet rs = stmt.executeQuery(sql);
				//System.out.println(sql);
				Vector v = new Vector();
				int cnt = 0;
				while ( rs.next() ) {
					Hashtable h = new Hashtable();	
					h.put("docnum", bill_no);
					h.put("item", Integer.toString(++cnt));
					h.put("id",	mecca.db.Db.getString(rs, "fee_id"));						
					h.put("code", mecca.db.Db.getString(rs, "fee_code"));
					h.put("description", mecca.db.Db.getString(rs, "fee_description"));
					float amount = rs.getFloat("amount");
					amount_total += amount;
					h.put("amount", new Float(amount));
					h.put("amount_formatted", getDecimalFormatted(amount));
					h.put("amountFormatted", getDecimalFormatted(amount));
					v.addElement(h);
				}	
				info.put("detail", v);			
			}
			
			//student_billing header
			
			{
				r.clear();
				r.add("student_id", student_id);
				r.add("bill_no", bill_no);
				r.add("bill_date");
				r.add("amount_total");
				sql = r.getSQLSelect("student_billing");
				ResultSet rs = stmt.executeQuery(sql);
				Hashtable h = new Hashtable();
				if ( rs.next() ) {
					h.put("student_id", student_id);
					h.put("bill_no", bill_no);
					h.put("bill_date", getDateFormatted(rs.getDate("bill_date")));	
					//h.put("amount_total", new Float(amount_total));
					h.put("amount_total", Float.toString(amount_total));
					h.put("amount_total_formatted", getDecimalFormatted(amount_total));
					
					//amount total in words
					h.put("amount_total_words", new NumberWordsFormat().convert(amount_total));
				}
				info.put("header", h);
			}
						
			return info;
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	public static void delete(String student_id, String bill_no) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			sql = "delete from student_billing_detail where student_id = '" + student_id + "' and bill_no = '" + bill_no + "'";
			stmt.executeUpdate(sql);
			sql = "delete from student_billing where student_id = '" + student_id + "' and bill_no = '" + bill_no + "'";
			stmt.executeUpdate(sql);			
		} finally {
			if ( db != null ) db.close();
		}	
	}	
	
	public static void saveAmountTotal(String student_id, String bill_no, float amount_total) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.update("student_id", student_id);
			r.update("bill_no", bill_no);
			r.add("amount_total", amount_total);
			sql = r.getSQLUpdate("student_billing");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}	
	
	public static void saveBillingInfo(String[] fee_ids, float[] amounts, String student_id, String bill_no) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			float amount_total = 0.0f;
			Vector zeros = new Vector();
			for ( int i = 0; i < fee_ids.length; i++ ) {
				float amount = amounts[i];
				if ( amount != 0.0f ) {
					r.clear();
					r.update("student_id", student_id);
					r.update("bill_no", bill_no);
					r.update("fee_id", fee_ids[i]);
					r.add("amount", amount);
					sql = r.getSQLUpdate("student_billing_detail");
					stmt.executeUpdate(sql);				
					amount_total += amount;
				} else {
					zeros.addElement(fee_ids[i]);
				}
			}
			//delete Zero amount values
			{
				for ( int i = 0; i < zeros.size(); i++ ) {
					r.clear();
					r.add("student_id", student_id);
					r.add("bill_no", bill_no);
					r.add("fee_id", (String) zeros.elementAt(i));
					sql = r.getSQLDelete("student_billing_detail");
					stmt.executeUpdate(sql);				
				}				
				
			}
			{
				r.clear();
				r.update("student_id", student_id);
				r.update("bill_no", bill_no);
				r.add("amount_total", amount_total);
				sql = r.getSQLUpdate("student_billing");
				stmt.executeUpdate(sql);
			}		
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Hashtable getTotalBillingDetail(String student_id) throws Exception {
	    Hashtable h = StudentData.getEnrollmentInfo(student_id);
	    return getTotalBillingDetail(h);
	}
	
	public static Hashtable getTotalBillingDetail(Hashtable studentInfo) throws Exception {
		Hashtable periodRef = PeriodData.getPeriodNameRef("");
		String student_id = (String) studentInfo.get("id");
		//String session = (String) studentInfo.get("intake_session");
		String program_code = (String) studentInfo.get("program_code");
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			Hashtable info = new Hashtable();
			r.add("d.student_id", student_id);
			r.add("b.bill_no");
			r.add("b.bill_date");
			r.add("f.fee_code");
			r.add("f.fee_description");
			r.add("d.amount");	
			r.add("d.session_id");
			r.add("s.session_name");
			r.add("d.period_id");
			r.add("d.session_id", r.unquote("s.session_id"));			
			r.add("d.bill_no", r.unquote("b.bill_no"));
			r.add("d.student_id", r.unquote("b.student_id"));
			r.add("d.fee_id", r.unquote("f.fee_id"));
			sql = r.getSQLSelect("student_billing b, session s, student_billing_detail d, fee_structure_program f", "s.start_date asc");
			
			//System.out.println(sql);
			
			
			Vector v = new Vector();
			ResultSet rs = stmt.executeQuery(sql);
			float amount_total = 0.0f;
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("type", "Charge");
				String no = Db.getString(rs, "bill_no");
				h.put("bill_no", no);
				h.put("no", no);
				java.util.Date date = rs.getDate("bill_date");
				h.put("date", date);
				h.put("date_formatted", getDateFormatted(date));
				h.put("bill_date", getDateFormatted(date));
				h.put("fee_code", mecca.db.Db.getString(rs, "fee_code"));
				h.put("fee_description", mecca.db.Db.getString(rs, "fee_description"));
				float amount = rs.getFloat("amount");
				amount_total += amount;
				h.put("amount", new Float(amount));
				h.put("amount_formatted", getDecimalFormatted(amount));
				h.put("session_id", Db.getString(rs, "session_id"));
				h.put("session_name", Db.getString(rs, "session_name"));
				String period_id = Db.getString(rs, "period_id");
				h.put("period_id", period_id);
				h.put("period_name", (String) periodRef.get(period_id));	
				
				v.addElement(h);
			}
			info.put("detail", v);
			info.put("amount_total", new Float(amount_total));
			info.put("amount_total_formatted", getDecimalFormatted(amount_total));
			info.put("total", new Float(amount_total));
			return info;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void addMore(Hashtable studentInfo, String bill_no, String fee_id) throws Exception {
		String student_id = (String) studentInfo.get("id");
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			float billed = 0.0f;
			
			{
				sql= "select fee_amount from fee_structure_program where fee_id = '" + fee_id + "'";
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) billed = rs.getFloat("fee_amount");
			}
			
			{
				r.add("student_id", student_id);
				r.add("bill_no", bill_no);
				r.add("fee_id", fee_id);
				r.add("amount", billed);
				sql = r.getSQLInsert("student_billing_detail");
				stmt.executeUpdate(sql);			
			}
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static synchronized String getInvoiceNo() throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			return getInvoiceNo(stmt);

		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	public static synchronized String getInvoiceNo(Statement stmt) throws Exception {
		String sql = "";
		String strNo = "";
		String prefix = "";
		char[] cf = {'0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',};
		int num_size = 0, current_num = 0;
		SQLRenderer r = new SQLRenderer();
		{
			r.add("doc_name", "student_invoice");
			r.add("doc_prefix");
			r.add("doc_num_size");
			r.add("doc_current_num");
			sql = r.getSQLSelect("billing_doc");
			ResultSet rs = stmt.executeQuery(sql);
			if ( rs.next() ) {
				prefix = rs.getString("doc_prefix");
				num_size = rs.getInt("doc_num_size");
				current_num = rs.getInt("doc_current_num");
				strNo = prefix + new java.text.DecimalFormat(new String(cf, 0, num_size)).format(++current_num);					
			}
		}
		{
			sql = "update billing_doc set doc_current_num = " + current_num + " where doc_name = 'student_invoice'";	
			stmt.executeUpdate(sql);
		}
		return strNo;
	}
	
	public static String getDateFormatted(java.util.Date date) {
	    if ( date != null )
	        return new java.text.SimpleDateFormat ("d MMM, yyyy").format(date);
	    else
	        return "";
 	}
 	
	public static String getDecimalFormatted(float number) {
		return new java.text.DecimalFormat("#,###,###.00").format(number);
	} 
	
	
	public static String createInvoice(Statement stmt, Vector fees, String student_id, String session_id, String period_id, Hashtable billDate) throws Exception {
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		boolean found = false;
		String invoiceNo = "";
		{
		    r.clear();
		    r.add("bill_no");
		    r.add("student_id", student_id);
		    r.add("session_id", session_id);
		    r.add("additional", 0);
		    sql = r.getSQLSelect("student_billing");
		    ResultSet rs = stmt.executeQuery(sql);
		    if ( rs.next() ) {
		        invoiceNo = rs.getString("bill_no");
		    }
		}	    
	    if ( "".equals(invoiceNo) ) invoiceNo = getInvoiceNo(stmt);
	    createInvoice(stmt, fees, invoiceNo, student_id, session_id, period_id, billDate);
	    return invoiceNo;
	}
	
	public static void createInvoice(Vector fees, String student_id, String session_id, String period_id, Hashtable billDate) throws Exception {

		Db db = null;
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			//String invoiceNo = BillingData.getInvoiceNo(stmt);
			//createInvoice(stmt, fees, invoiceNo, student_id, session_id, period_id, billDate);
			createInvoice(stmt, fees, student_id, session_id, period_id, billDate);
		} finally {
			if ( db != null ) db.close();
		}
	
	}	
	
	public static void createInvoice(Statement stmt, Vector fees, String bill_no, String student_id, String session_id, String period_id, Hashtable billDate) throws Exception {
		String bill_date = ((Integer) billDate.get("year")).intValue() + "-" + fmt((Integer) billDate.get("month")) + "-" + fmt((Integer) billDate.get("day"));
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		boolean found = false;
		
		//delete all invoices

		{
			r.clear();
			r.add("bill_no", bill_no);
			sql = r.getSQLDelete("student_billing_detail");
			stmt.executeUpdate(sql);
		    
			r.clear();
			r.add("bill_no", bill_no);
			sql = r.getSQLDelete("student_billing");
			stmt.executeUpdate(sql);
		}

		{
			r.clear();
			r.add("student_id", student_id);
			r.add("bill_no", bill_no);
			r.add("bill_date", bill_date);
			r.add("session_id", session_id);
			//r.add("period_id", period_id);
			sql = r.getSQLInsert("student_billing");
			//System.out.println(sql);
			stmt.executeUpdate(sql);
		}

		float amount_total = 0.0f;
		//create items
		for ( int i=0; i < fees.size(); i++ ) {
			Hashtable fee = (Hashtable) fees.elementAt(i);
			int additional = ((Integer) fee.get("additional")).intValue();
			//System.out.println("addi=" + additional);
			if ( additional == 0 ) {
				r.clear();
				r.add("student_id", student_id);
				r.add("bill_no", bill_no);
				r.add("fee_id", (String) fee.get("id"));
				r.add("session_id", session_id);
				r.add("period_id", period_id);
				float amount = ((Float) fee.get("amount")).floatValue();
				amount_total += amount;
				r.add("amount", amount);
				sql = r.getSQLInsert("student_billing_detail");
				//System.out.println(sql);
				stmt.executeUpdate(sql);
			}
		}
		//update amount_total
		{
			r.clear();
			r.update("student_id", student_id);
			r.update("bill_no", bill_no);
			r.add("amount_total", amount_total);
			sql = r.getSQLUpdate("student_billing");
			stmt.executeUpdate(sql);				
		}
		
	}	
	
	public static void addItemInvoiceAdditional(String student_id, String bill_no, String session_id, String period_id, Hashtable billDate, Hashtable fee) throws Exception {
		Db db = null;
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			addItemInvoiceAdditional(stmt, student_id, bill_no, session_id, period_id, billDate, fee);
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void addItemInvoiceAdditional(Statement stmt, String student_id, String bill_no, String session_id, String period_id, Hashtable billDate, Hashtable fee) throws Exception {
		String bill_date = ((Integer) billDate.get("year")).intValue() + "-" + fmt((Integer) billDate.get("month")) + "-" + fmt((Integer) billDate.get("day"));
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		
		boolean found = false;
		{
			r.clear();
			r.add("bill_no");
			r.add("student_id", student_id);
			r.add("bill_no", bill_no);
			sql = r.getSQLSelect("student_billing");
			//System.out.println(sql);
			ResultSet rs = stmt.executeQuery(sql);
			if ( rs.next() ) found = true;
		}

		if ( !found ) {
			r.clear();
			r.add("student_id", student_id);
			r.add("bill_no", bill_no);
			r.add("bill_date", bill_date);
			r.add("session_id", session_id);
			//r.add("period_id", period_id);
			r.add("additional", 1);
			sql = r.getSQLInsert("student_billing");
			//System.out.println(sql);
			stmt.executeUpdate(sql);
		}

		float amount_total = 0.0f;
		{
			sql = "select amount_total from student_billing where bill_no = '" + bill_no + "'";
			ResultSet rs = stmt.executeQuery(sql);
			if ( rs.next() ) {
				amount_total = rs.getFloat(1);
			}
		}
		//create item
		{

			r.clear();
			r.add("student_id", student_id);
			r.add("bill_no", bill_no);
			r.add("fee_id", (String) fee.get("id"));
			r.add("session_id", session_id);
			r.add("period_id", period_id);
			float amount = 0.0f;
			if ( fee.get("amount") instanceof Float )
				amount = ((Float) fee.get("amount")).floatValue();
			else if ( fee.get("amount") instanceof String )
				amount = Float.parseFloat((String) fee.get("amount"));
			amount_total += amount;
			r.add("amount", amount);
			sql = r.getSQLInsert("student_billing_detail");
			//System.out.println(sql);
			stmt.executeUpdate(sql);
		}
		//update amount_total

		{
			r.clear();
			r.update("student_id", student_id);
			r.update("bill_no", bill_no);
			r.add("amount_total", amount_total);
			sql = r.getSQLUpdate("student_billing");
			stmt.executeUpdate(sql);				
		}		
	}
	
	
	
	public static Vector getRefundableList() throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			sql = "select s.id, s.name, sum(r.amount_total) - sum(b.amount_total) balance " +
			"from student s, student_receipt r, student_billing b " +
			"where s.id = r.student_id " +
			"and s.id = b.student_id " +
			"group by s.id " +
			"having balance > 0 " +
			"";
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("student_id", rs.getString(1));
				h.put("student_name", rs.getString(2));
				float amount = rs.getFloat(3);
				h.put("refund_amount_value", new Float(amount));
				h.put("refund_amount", getDecimalFormatted(amount));
				v.addElement(h);
			}
			Collections.sort(v, new NameComparator());
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	public static Hashtable getInvoiceSessionMap(String student_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("student_id", student_id);
			r.add("additional", 0);
			r.add("session_id");
			r.add("bill_no");
			r.add("amount_total");
			r.add("bill_date");

			sql = r.getSQLSelect("student_billing");
			ResultSet rs = stmt.executeQuery(sql);
			Hashtable map = new Hashtable();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("bill_no", rs.getString("bill_no"));
				h.put("amount", getDecimalFormatted(rs.getFloat("amount_total")));
				h.put("bill_date", DateTool.getDateFormatted(Db.getDate(rs, "bill_date")));
				map.put(rs.getString("session_id"), h);
			}
			return map;
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void deleteInvoice(String bill_no) throws Exception {
		Db db = null;
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			deleteInvoice(stmt, bill_no);
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void doPayment(String student_id, Vector paymentList) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			for ( int i=0; i < paymentList.size(); i++ ) {
				Hashtable h = (Hashtable) paymentList.elementAt(i);
				String invoice_no = (String) h.get("invoice_no");
				float amount_invoice = ((Float) h.get("amount_invoice")).floatValue();
				float amount_paid = ((Float) h.get("amount_paid")).floatValue();
				float amount_unpaid = ((Float) h.get("amount_balance")).floatValue();
				Hashtable paymentDate = (Hashtable) h.get("date");
				int yr = ((Integer) paymentDate.get("year")).intValue();
				int mn = ((Integer) paymentDate.get("month")).intValue();
				int dy = ((Integer) paymentDate.get("day")).intValue();
				String date = DateTool.getDateStr(yr, mn, dy);
				r.clear();
				r.update("student_id", student_id);
				r.update("invoice_no", invoice_no);
				r.add("payment_date", date);
				r.add("amount_invoice", amount_invoice);
				r.add("amount_paid", amount_paid);
				r.add("amount_unpaid", amount_unpaid);
				sql = r.getSQLUpdate("student_payment");
				stmt.executeUpdate(sql);
			}
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Vector getBillingList(String student_id) throws Exception {
		Db db = null;
		
		try {
			
			db = new Db();
			Statement stmt = db.getStatement();	
			return getBillingList(stmt, student_id);
		} finally {
			if ( db != null ) db.close();
		}			
	}
	
	public static Vector getBillingList(Statement stmt, String student_id) throws Exception {
		//Hashtable periodRef = PeriodData.getPeriodNameRef("");
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		r.add("student_id", student_id);
		r.add("bill_no");
		r.add("bill_date");
		r.add("session_id");
		r.add("amount_total");
		sql = r.getSQLSelect("student_billing", "bill_date asc");
		ResultSet rs = stmt.executeQuery(sql);
		Vector v = new Vector();
		while ( rs.next() ) {
			Hashtable h = new Hashtable();
			h.put("student_id", student_id);
			h.put("bill_no", mecca.db.Db.getString(rs, "bill_no"));
			h.put("bill_date", getDateFormatted(Db.getDate(rs, "bill_date")));
			String session_id = rs.getString("session_id");
			h.put("session_id", session_id);
			h.put("amount_total", new Float(rs.getFloat("amount_total")));
			h.put("amount_total_formatted", getDecimalFormatted(rs.getFloat("amount_total")));
			v.addElement(h);
		}
		return v;

	}	
	
	public static void createPaymentList(String student_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			Vector invoiceList = getBillingList(stmt, student_id);
			Vector invoiceNoList = getInvoiceNoList(stmt, student_id);
			//iterate thru invoice list
			//if invoice NOT IN payment list then create

			for ( int i=0; i < invoiceList.size(); i++ ) {
				Hashtable h = (Hashtable) invoiceList.elementAt(i);
				String invoice_no = (String) h.get("bill_no");
				if ( !invoiceNoList.contains(invoice_no)) {
					float amount_invoice = ((Float) h.get("amount_total")).floatValue();
					r.clear();
					r.add("student_id", student_id);
					r.add("invoice_no", invoice_no);
					r.add("amount_unpaid", amount_invoice);
					r.add("amount_invoice", amount_invoice);
					r.add("amount_paid", 0.0f);
					sql = r.getSQLInsert("student_payment");
					stmt.executeUpdate(sql);
				}
			}
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Vector getPaymentList(String student_id) throws Exception {
		Db db = null;
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			return getPaymentList(stmt, student_id);
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	public static Vector getPaymentList(Statement stmt, String student_id) throws Exception {

		String sql = "";
		SQLRenderer r = new SQLRenderer();
		r.add("invoice_no");
		r.add("payment_date");
		r.add("amount_invoice");
		r.add("amount_paid");
		r.add("amount_unpaid");
		r.add("student_id", student_id);
		sql = r.getSQLSelect("student_payment");
		ResultSet rs = stmt.executeQuery(sql);
		Vector v = new Vector();
		while ( rs.next() ) {
			String invoice_no = rs.getString("invoice_no");
			java.util.Date date = Db.getDate(rs, "payment_date");
			float amount_invoice = rs.getFloat("amount_invoice");
			float amount_paid = rs.getFloat("amount_paid");
			float amount_unpaid = rs.getFloat("amount_unpaid");
			Hashtable h = new Hashtable();
			h.put("invoice_no", invoice_no);
			h.put("date", DateTool.getDateFormatted(date));
			h.put("amount_invoice", new Float(amount_invoice));
			h.put("amount_paid", new Float(amount_paid));
			h.put("amount_unpaid", new Float(amount_unpaid));
			v.addElement(h);
		}
		return v;

	}
	
	public static Vector getInvoiceNoList(String student_id) throws Exception {
		Db db = null;
		try {
			db = new Db();
			return getInvoiceNoList(db.getStatement(), student_id);
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Vector getInvoiceNoList(Statement stmt, String student_id) throws Exception {
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		r.add("invoice_no");
		sql = r.getSQLSelect("student_payment");
		ResultSet rs = stmt.executeQuery(sql);
		Vector v = new Vector();
		while ( rs.next() ) {
			v.addElement(rs.getString(1));
		}
		return v;

	}	
	
	public static void deleteInvoice(Statement stmt, String bill_no) throws Exception {
		String sql = "DELETE FROM student_billing_detail where bill_no = '" + bill_no + "'";
		stmt.executeUpdate(sql);
		sql = "DELETE FROM student_billing where bill_no = '" + bill_no + "'";
		stmt.executeUpdate(sql);
	}
	
}