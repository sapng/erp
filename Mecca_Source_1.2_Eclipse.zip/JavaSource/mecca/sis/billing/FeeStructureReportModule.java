/* ************************************************************************
 * Copyright 2005 University ERP Project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.sis.billing;

import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.sis.registration.SessionData;
import mecca.sis.struct.PeriodData;
import mecca.sis.struct.ProgramData;
import mecca.util.DateTool;

import org.apache.velocity.Template;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.00
 */
public class FeeStructureReportModule extends mecca.portal.velocity.VTemplate {

	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/sis/billing/fee_structure_report.vm";
		String submit = getParam("command");
		
		Vector programList = ProgramData.getList();
		context.put("programList", programList);
		
		//String program_code = getParam("program_list");
		//context.put("program_code", program_code);
		
		//String current_session = !"".equals(getParam("session_list")) ? getParam("session_list") : SessionData.getCurrentSessionId();
		//context.put("current_session", current_session);	
		

		context.put("feeList", new Vector());		
		context.put("isGenerated", new Boolean(false));
		
		context.put("isSelected", new Boolean(false));
		if ( "getProgram".equals(submit) ) {
			String programCode = getParam("program_list");
			Vector schemes = ProgramData.getPeriodStructureList2(programCode);
			context.put("periodSchemes", schemes);	

			if ( schemes.size() == 1 ) {
				prepareReport(session);
			}
		} else if ( "getReport".equals(submit) ) {
			prepareReport(session);
		}


		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	void prepareReport(HttpSession session) throws Exception {
		context.put("isSelected", new Boolean(true));
		String programCode = getParam("program_list");
		context.put("program_code", programCode);
		String period_scheme = getParam("period_scheme");
		context.put("period_scheme", period_scheme);
		Vector periodStructure =  PeriodData.getPeriodStructure(period_scheme);
		context.put("periodStructure", periodStructure);		
		Vector intakeList = SessionData.getIntakeBatch(period_scheme);
		context.put("intakeList", intakeList);
		int additional = 0;
		//for each intake_session get fee_structure
		Hashtable intakeFeeMap = new Hashtable();
		Db db = null;
		try {
			db = new Db();
			for ( int i=0; i < intakeList.size(); i++ ) {
				Hashtable h = (Hashtable) intakeList.elementAt(i);
				String intake_session = (String) h.get("id");
				Hashtable feeData = FeeData.getTotalFeePeriodMap(db.getStatement(), programCode, period_scheme, intake_session, additional);
				intakeFeeMap.put(intake_session, feeData);
			}			
			context.put("intakeFeeMap", intakeFeeMap);
		} finally {
			if ( db != null ) db.close();
		}

	}
	
}
