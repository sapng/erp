/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.sis.billing;

import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.sis.registration.MatricNumber;
import mecca.sis.registration.SessionData;
import mecca.sis.registration.StudentData;
import mecca.util.DateTool;

import org.apache.velocity.Template;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.00
 */
public class DepositPaymentModule extends mecca.portal.velocity.VTemplate  {

	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/sis/billing/deposit_payment.vm";
		String submit = getParam("command");
		
		String student_id = !"".equals(getParam("student_id")) ? getParam("student_id") : "";
		context.put("student_id", student_id);
		context.put("isSelect", new Boolean(false));
		
		Hashtable dateTime = DateTool.getCurrentDateTime();
		context.put("dateTime", dateTime);	
		
		if ( "doPayment".equals(submit) ) {
			template_name = "vtl/sis/billing/deposit_payment_done.vm";
			doPayment(session);
		}
		
		
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	void doPayment(HttpSession session) throws Exception {
		
		String yr = getParam("bill_year"), mn = getParam("bill_month"), dy = getParam("bill_day");
		Hashtable paymentDate = new Hashtable();
		paymentDate.put("year", yr);
		paymentDate.put("month", mn);
		paymentDate.put("day", dy);	
		context.put("date", paymentDate);
		
		String icno = getParam("icno");
		String student_name = getParam("student_name");
		String amount = getParam("amount");
		String matric = MatricNumber.createMatric();
		
		Hashtable info = new Hashtable();
		info.put("icno", icno);
		info.put("student_name", student_name);
		info.put("amount", amount);
		info.put("matric", matric);
		context.put("info", info);
		
		savePayment(info, paymentDate);

	}	
	
	void savePayment(Hashtable info, Hashtable paymentDate) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
		} finally {
			if ( db != null ) db.close();
		}
	}
	

	
}
