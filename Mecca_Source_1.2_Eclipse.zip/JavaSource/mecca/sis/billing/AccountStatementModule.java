/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.billing;


import java.util.Hashtable;

import javax.servlet.http.HttpSession;

import mecca.sis.registration.StudentData;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class AccountStatementModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/sis/billing/account_statement_get.vm";
		String submit = getParam("command");
		
		Hashtable studentInfo = session.getAttribute("studentInfo") != null ? (Hashtable) session.getAttribute("studentInfo") : new Hashtable();
 
		//from search result
		if ( "getstudent".equals(submit) ) submit = "get";		
				
		if ( "get".equals(submit) ) {
			template_name = "vtl/sis/billing/account_statement.vm";
			String student_id = getParam("student_id");
			
			//student info
			Hashtable studentDetail = StudentData.getStudent(student_id);
			context.put("studentDetail", studentDetail);			
			studentInfo = StudentData.getEnrollmentInfo(student_id);
			session.setAttribute("studentInfo", studentInfo);
			context.put("studentInfo", studentInfo);
						
			Hashtable accInfo = AccountData.getAccount(student_id);
			context.put("accInfo", accInfo);
		}
		else if ( "search".equals(submit) ) {
			template_name = "vtl/sis/register/student_search.vm";
			Hashtable result = mecca.sis.SearchUtils.getSearchByName(getParam("student_name"));
			context.put("searchResult", result);
		}			
		
		
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
}			