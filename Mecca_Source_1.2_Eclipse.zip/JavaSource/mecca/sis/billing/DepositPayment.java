/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.sis.billing;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;
import mecca.sis.registration.IntakeStatus;
import mecca.sis.registration.MatricNumber;
import mecca.sis.registration.SessionData;
import mecca.sis.registration.StudentData;
import mecca.sis.struct.ProgramData;
import mecca.util.DateTool;

/**
 * @author Shamsul Bahrin bin Abd Mutalib
 *
 * @version 0.1
 */
public class DepositPayment {

	public static String fmt(String s) {
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}
	
	public static String fmt(int i) {
	    String s = Integer.toString(i);
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}
	
	public static String fmt(Integer i) {
	    String s = Integer.toString(i.intValue());
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}		
	
	public static boolean preRegisterStudent(Hashtable info, Hashtable paymentDate) throws Exception {
		String student_id = (String) info.get("student_id");
		
		
		
	    if ( "".equals( student_id ) ) {
	        student_id = MatricNumber.createMatric();
	        //check whether this matric number exist
	        if ( existStudentId(student_id) ) return false;
	        info.put("student_id", student_id);
	        
	        //--
	        
	    }
	    /*
	    String program_code = (String) info.get("program_code");
	    String student_id = (String) info.get("student_id");
	    createInvoice(student_id, program_code, paymentDate);
	    */
	    //--
	    clearBillingData(student_id);
	    //--
	    
	    
	    preRegister(info, paymentDate);
	    return true;
	}
	
	public static void clearBillingData(String student_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			sql = "delete from student_billing where student_id = '" + student_id + "'";
			stmt.executeUpdate(sql);
			sql = "delete from student_billing_detail where student_id = '" + student_id + "'";
			stmt.executeUpdate(sql);
			sql = "delete from student_receipt where student_id = '" + student_id + "'";
			stmt.executeUpdate(sql);
			sql = "delete from student_receipt_detail where student_id = '" + student_id + "'";
			stmt.executeUpdate(sql);			
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static boolean existStudentId(String id) throws Exception {
		Db db = null;
		try {
			db = new Db();
			String sql = "select id from student where id = '" + id + "'";
			ResultSet rs = db.getStatement().executeQuery(sql);
			if ( rs.next() ) return true;
			else return false;
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void createInvoice(String student_id, String program_code, Hashtable billDate) throws Exception {
	    int path_no = 0; //default path
	    String date_paid = ((Integer) billDate.get("year")).intValue() + "-" + DateTool.fmt((Integer) billDate.get("month")) + "-" + DateTool.fmt((Integer) billDate.get("day"));
	    Hashtable sessionInfo = SessionData.getCurrentSession(path_no, date_paid);
	    String session_id = (String) sessionInfo.get("session_id");

	    Hashtable studentInfo = StudentData.getEnrollmentInfo1(student_id, session_id);
	    String period_id = (String) studentInfo.get("period_id");
	    String intake_session = (String) studentInfo.get("intake_session");
		Hashtable feeInfo  = FeeData.getStudyFee(program_code, period_id, intake_session);
		Vector feeList = (Vector) feeInfo.get("feeList");	    
		
		BillingData.createInvoice(feeList, student_id, session_id, period_id, billDate);
	    
	}	
	
	public static void createInvoice(String student_id, String program_code, String session_id, Hashtable billDate) throws Exception {
	    int path_no = 0; //default path
	    String date_paid = ((Integer) billDate.get("year")).intValue() + "-" + DateTool.fmt((Integer) billDate.get("month")) + "-" + DateTool.fmt((Integer) billDate.get("day"));
	    //Hashtable sessionInfo = SessionData.getCurrentSession(path_no, date_paid);
	    //String session_id = (String) sessionInfo.get("session_id");

	    Hashtable studentInfo = StudentData.getEnrollmentInfo1(student_id, session_id);
	    String period_id = (String) studentInfo.get("period_id");
	    String intake_session = (String) studentInfo.get("intake_session");
		Hashtable feeInfo  = FeeData.getStudyFee(program_code, period_id, intake_session);
		Vector feeList = (Vector) feeInfo.get("feeList");	    
		
		BillingData.createInvoice(feeList, student_id, session_id, period_id, billDate);
	    
	}	
	
	public static void preRegister(Hashtable info, Hashtable paymentDate) throws Exception {
	    String date_paid = ((Integer) paymentDate.get("year")).intValue() + "-" + fmt((Integer) paymentDate.get("month")) + "-" + fmt((Integer) paymentDate.get("day"));
	    String student_id = (String) info.get("student_id");
	    
	    
	    
	    String session_id = (String) info.get("session_id");
	    String remark = (String) info.get("remark");
	    int intake_month = 0;
	    int intake_year = 0;
    	intake_month = Integer.parseInt((String) info.get("intake_month"));
    	intake_year = Integer.parseInt((String) info.get("intake_year"));
    	
	    	
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			String program_code = (String) info.get("program_code");
			
			SQLRenderer r = new SQLRenderer();
			boolean found = false;
			String receipt_no = "";			
			{
			    r.add("student_id");
			    r.add("receipt_no");
			    //r.add("icno", (String) info.get("icno"));
			    r.add("student_id", student_id);
			    //r.add("intake_month", intake_month);
			    //r.add("intake_year", intake_year);
			    sql = r.getSQLSelect("student_deposit");
			    ResultSet rs = stmt.executeQuery(sql);
			    if ( rs.next() ) {
			        info.put("student_id", rs.getString("student_id"));
			        receipt_no = rs.getString("receipt_no");
			        info.put("receipt_no", receipt_no);
			        found = true;
			    }
			}
			
			//System.out.println("STUDENT = " + student_id);
			//System.out.println((String) info.get("student_id"));
			
			
			if ( !found ) { //INSERT
				//generate new receipt no
			    receipt_no = ReceiptData.getReceiptNo();							
				{
				    r.clear();
					r.add("student_id", (String) info.get("student_id"));
					r.add("icno", (String) info.get("icno"));
					r.add("amount_paid", ((Float) info.get("amount_paid")).floatValue());
					r.add("date_paid", date_paid);
					r.add("program_code", program_code);
					r.add("receipt_no", receipt_no);
					r.add("remark", remark);
					r.add("intake_month", intake_month);
					r.add("intake_year", intake_year);
					sql = r.getSQLInsert("student_deposit");
					
					stmt.executeUpdate(sql);
				}
				{
				    r.clear();
					r.add("name", (String) info.get("student_name"));
					r.add("icno", (String) info.get("icno"));
					r.add("id", (String) info.get("student_id"));
					r.add("centre_id", (String) info.get("centre_id"));				
					sql = r.getSQLInsert("student");
					stmt.executeUpdate(sql);
				    
				}
				
			} 
			else { //UPDATE
			   {
			       
				    r.clear();
					r.update("student_id", (String) info.get("student_id"));
					r.add("icno", (String) info.get("icno"));
					r.add("amount_paid", ((Float) info.get("amount_paid")).floatValue());
					r.add("date_paid", date_paid);
					r.add("program_code", program_code);
					r.add("remark", remark);
					r.add("intake_month", intake_month);
					r.add("intake_year", intake_year);					
					sql = r.getSQLUpdate("student_deposit");
					//System.out.println(sql);
					stmt.executeUpdate(sql);
				}
				{
				    r.clear();
					r.add("name", (String) info.get("student_name"));
					r.add("icno", (String) info.get("icno"));
					r.add("centre_id", (String) info.get("centre_id"));				
					r.update("id", (String) info.get("student_id"));
					sql = r.getSQLUpdate("student");
					stmt.executeUpdate(sql);
				    
				}
				
				//get receipt no for this pre-registration
				{
					r.clear();
				}
			 
			}
			
			//register program
			//String session_id = "";
			//student_id = "";
			if ( !"".equals(program_code) ){
			    int path_no = 0; //default path
			    //String date_paid = (String) paymentDate.get("year") + "-" + fmt((String) paymentDate.get("month")) + "-" + fmt((String) paymentDate.get("day"));
			    //-- GET SESSION ID BASED ON DATE PAID
			    //Hashtable sessionInfo = SessionData.getCurrentSession(path_no, date_paid);
			    //session_id = (String) sessionInfo.get("session_id");
			    student_id = (String) info.get("student_id");
			    Hashtable regInfo = new Hashtable();
			    regInfo.put("student_id", (String) info.get("student_id"));
			    regInfo.put("track_id", "0");
			    regInfo.put("intake_session", session_id);
			    regInfo.put("program_code", program_code);
			    regInfo.put("intake_month", new Integer(intake_month));
			    regInfo.put("intake_year", new Integer(intake_year));
			    
			    StudentData.registerProgram(regInfo);
			    
			    //create invoice
			    createInvoice(student_id, program_code, session_id, paymentDate);			    
			    
				//create payment
			    String fee_id = "";
				{
				    //get which fee to deduct from
				    Hashtable studentInfo = StudentData.getEnrollmentInfo1(student_id, session_id);
				    
				    //System.out.println("studentInfo = " + studentInfo);
				    
				    String period_id = (String) studentInfo.get("period_id");
				    sql = "select MIN(priority) AS priority, fee_id from fee_structure_program " +
				    "where program_code = '" + program_code + "' and period_id ='" + period_id + "' " +
					" and intake_session = '" + session_id + "' " +
				    "GROUP BY program_code, period_id";
				    ResultSet rs = stmt.executeQuery(sql);
				    if ( rs.next() ) {
				        fee_id = rs.getString("fee_id");
				    }
				    
				    //ReceiptData.createReceipt(Vector fees, String receipt_no, Hashtable studentInfo, Hashtable receiptDate) throws Exception {
				    //Vector fees = FeeData.getBillingFeeList(student_id, new String[] {fee_id});
				    Vector fees = FeeData.getBillingFeeList(student_id);

				    //create the payment receipt
				    ReceiptData.createReceipt(fees, receipt_no, studentInfo, paymentDate);
				    ReceiptData.saveReceiptInfo( new String[] {fee_id}, new float[] {((Float)info.get("amount_paid")).floatValue()}, student_id, receipt_no);
				    
				}
			    
			}
			
		} finally {
			if ( db != null ) db.close();
		}
	} 
	
	public static Hashtable getPaymentInfoByMatric(String id) throws Exception {
	    Db db = null;
	    String sql = "";
	    try {
	        db = new Db();
	        Statement stmt = db.getStatement();
	        return getPaymentInfoByMatric(stmt, id);
	    } finally {
	        if ( db != null ) db.close();
	    }
	}
	
	public static Hashtable getPaymentInfoByMatric(Statement stmt, String id) throws Exception {
	    Hashtable programMap = ProgramData.getProgramCodeMap(stmt);
	    String sql = "";
        SQLRenderer r = new SQLRenderer();
        //get student matric from student table
        {
            r.add("student_id", id);
            r.add("date_paid");
            r.add("amount_paid");
            r.add("s.name");
            r.add("s.icno");
            r.add("d.program_code");
            r.add("receipt_no");
            r.add("s.centre_id");
            r.add("d.intake_session");
            r.add("d.intake_month");
            r.add("d.intake_year");
            r.add("d.remark");
            r.add("d.student_id", r.unquote("s.id"));
            sql = r.getSQLSelect("student_deposit d, student s");
            ResultSet rs = stmt.executeQuery(sql);
            Hashtable h = new Hashtable();
            String centre_id = "";
            if ( rs.next() ) {
                h.put("student_id", id);
                h.put("student_name", rs.getString("name"));
                h.put("icno", rs.getString("icno"));
                java.util.Date date_paid = rs.getDate("date_paid");
                h.put("dateYMD", DateTool.getYMD(date_paid));
                h.put("date_paid", DateTool.getDateFormatted(date_paid));
                float amount = rs.getFloat("amount_paid");
                h.put("amount_paid", new Float(amount));
                h.put("amount_paid_f", BillingData.getDecimalFormatted(amount));
                String program_code = Db.getString(rs, "program_code");
                h.put("program_code", program_code);
                String program_name = (String) programMap.get(program_code);
                h.put("program_name", program_name != null ? program_name : "");
                centre_id = Db.getString(rs, "centre_id");
                h.put("centre_id", centre_id);
                h.put("receipt_no", Db.getString(rs, "receipt_no"));
                h.put("session_id", Db.getString(rs, "intake_session"));
                h.put("intake_month", new Integer( rs.getInt("intake_month")));
                h.put("intake_year", new Integer( rs.getInt("intake_year")));
                h.put("remark", Db.getString(rs, "remark"));
        		BillingUtil u = new BillingUtil();
        		u.toWordsEng(amount);
        		String ringgit = u.getRinggit();
        		String sen = u.getSen();					
        		String money = "RINGGIT MALAYSIA: " + ringgit.toUpperCase() + (!"".equals(sen) ? " AND CENT "  + sen.toUpperCase() + " ONLY" : " ONLY");
        		h.put("amount_word", money);                
            }
            {
            	sql = "select centre_code, centre_name from learning_centre where centre_id = '" + centre_id + "'";
            	rs = stmt.executeQuery(sql);
            	if ( rs.next() ) {
            		h.put("centre_code", Db.getString(rs, "centre_code"));
            		h.put("centre_name", Db.getString(rs, "centre_name"));
            	}
            }
            return h;
        }
	}	
	
	public static void getPaymentList() throws Exception {
	    
	}
	
}
