/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.billing;



import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.db.SQLRenderer;
import mecca.sis.registration.SessionData;
import mecca.sis.registration.StudentData;
import mecca.sis.struct.Period;
import mecca.sis.struct.PeriodData;
import mecca.sis.struct.ProgramData;
import mecca.util.DateTool;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class FeeStructureModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/sis/billing/fee_structure.vm";
		String submit = getParam("command");
		
		Vector programList = ProgramData.getList();
		context.put("programList", programList);
		
		String program_code = getParam("program_list");
		context.put("program_code", program_code);
		
		//Vector sessionList = SessionData.getListDesc();
		//context.put("sessionList", sessionList);
		
		
		String current_session = !"".equals(getParam("session_list")) ? getParam("session_list") : SessionData.getCurrentSessionId();
		context.put("current_session", current_session);	
		
		Hashtable dateTime = DateTool.getCurrentDateTime();
		context.put("dateTime", dateTime);		
		
		context.put("feeList", new Vector());		
		context.put("isGenerated", new Boolean(false));
		
		context.put("isSelected", new Boolean(false));

		if ( "add".equals(submit) ) {
			submit = "get";
			String period_scheme = getParam("period_scheme");
			context.put("period_scheme", period_scheme);	
			String period_id = getParam("period_id");
			context.put("period_id", period_id);
			String intake_session = getParam("intake_session");
			context.put("intake_session", intake_session);
			Hashtable h = new Hashtable();
			h.put("period_id", getParam("period_id"));
			h.put("period_scheme", getParam("period_scheme"));
			h.put("code", getParam("fee_code"));
			h.put("description", getParam("fee_description"));
			h.put("amount", getParam("fee_amount"));
			h.put("program_code", getParam("program_list"));
			h.put("intake_session", intake_session);
			h.put("additional", new Integer(Integer.parseInt(getParam("fee_type"))));
			FeeData.add(h);
			prepare(session);
		}
		else if ( "delete".equals(submit )) {
		    submit = "get";
			String intake_session = getParam("intake_session");
			context.put("intake_session", intake_session);		    
			Hashtable h = new Hashtable();
			h.put("period_id", getParam("period_id"));
			h.put("code", getParam("fee_code"));
			h.put("program_code", getParam("program_list"));
			h.put("intake_session", intake_session);
		    FeeData.delete(h);
		    prepare(session);
		}
		
		if ( "getProgram".equals(submit) ) {
			String programCode = getParam("program_list");
			Vector schemes = ProgramData.getPeriodStructureList2(programCode);
			context.put("periodSchemes", schemes);	

			if ( schemes.size() == 1 ) {
				//prepare(session);
				String period_scheme = getParam("period_scheme");
				if ( "".equals(period_scheme) ) {
					Hashtable h = (Hashtable) schemes.elementAt(0);
					period_scheme = (String) h.get("period_scheme");
				}				
				context.put("period_scheme", period_scheme);
				Vector intakeList = SessionData.getIntakeBatch(period_scheme);
				context.put("intakeList", intakeList);				
			}

		} else if ( "getIntakeList".equals(submit)) {
			String period_scheme = getParam("period_scheme");
			context.put("period_scheme", period_scheme);
			Vector intakeList = SessionData.getIntakeBatch(period_scheme);
			context.put("intakeList", intakeList);
			
		} else if ( "getFeeStructure".equals(submit) ) {
			prepare(session);
		}	
		
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	void prepare(HttpSession session) throws Exception {
		context.put("isSelected", new Boolean(true));
		String programCode = getParam("program_list");
		
		String period_scheme = getParam("period_scheme");
		context.put("period_scheme", period_scheme);
		
		String intake_session = getParam("intake_session");
		context.put("intake_session", intake_session);
		//System.out.println("intake_session=" + intake_session);
		
		Vector periodStructure =  PeriodData.getPeriodStructure(period_scheme);
		context.put("periodStructure", periodStructure);
		
		Vector periodChildList = getPeriodChildList(periodStructure);
		context.put("periodChildList", periodChildList);
		
		String program_name = ProgramData.getProgramName(programCode);
		context.put("program_name", program_name);
		String sessionId = getParam("session_list");
		if ( "".equals(sessionId) ) {
		    sessionId = SessionData.getCurrentSessionId();
		}
		context.put("session_id", sessionId);	
		
		Hashtable feeData = FeeData.getFeePeriodMap(programCode, period_scheme, intake_session);
		context.put("feeData", feeData);	
		 
		Vector feeCodes = FeeData.getCodeList();
		context.put("feeCodes", feeCodes);
	}
	
	
	Vector getPeriodChildList(Vector v) throws Exception {
		Vector list = new Vector();
		for ( int i=0; i < v.size(); i++) {
			Period p = (Period) v.elementAt(i);
			if ( !p.hasChild() ) list.addElement(p);
		}
		return list;
	}
	
	


	
}