/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.billing;


import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import mecca.db.Db;
import mecca.sis.struct.PeriodData;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class AccountData { 
	
	public static Hashtable getAccount(String student_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			Hashtable info = new Hashtable();
			Hashtable paid = new Hashtable();
			{
				sql = "select f.fee_id, SUM(d.amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_receipt_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					String amount = mecca.db.Db.getString(rs,"fee_amount");
					paid.put(fee_id, amount);
				}
			}
			
			
			Vector v = new Vector();
			Hashtable total = new Hashtable();
			{
				sql = "select f.fee_id, f.fee_code, f.fee_description, SUM(f.fee_amount) AS fee_amount, ";
				sql += " f.period_id, f.period_scheme ";
				sql += " from fee_structure_program f, student_billing_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				ResultSet rs = stmt.executeQuery(sql);
				float total_billed = 0.0f;
				float total_paid = 0.0f;
				float total_balance = 0.0f;
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					h.put("id", fee_id);
					h.put("code", mecca.db.Db.getString(rs, "fee_code"));
					h.put("description", mecca.db.Db.getString(rs, "fee_description"));
					float amount_billed = rs.getFloat("fee_amount");
					total_billed += amount_billed;
					//check for payment for this fee
					String payment = (String) paid.get(fee_id);
					float amount_paid = 0.0f;
					float amount_balance = 0.0f;
					if ( payment != null ) {
						amount_paid = Float.parseFloat(payment);
						amount_balance = amount_billed - amount_paid;
						
						h.put("amount",  BillingData.getDecimalFormatted(amount_balance));	
						h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));						
						h.put("amount_paid", BillingData.getDecimalFormatted(amount_paid));
					} else {
						amount_paid = 0.0f;
						amount_balance = amount_billed;
												
						h.put("amount",  BillingData.getDecimalFormatted(amount_billed));	
						h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));
						h.put("amount_paid", "0.00");
					}
					total_paid += amount_paid;
					total_balance += amount_balance;
					
					String period_id = rs.getString("period_id");
					String period_scheme = rs.getString("period_scheme");
					String period_name = PeriodData.getLongPeriodName(period_id, period_scheme);
					h.put("period_name", period_name);
					
					v.addElement(h);
				}
				
				total.put("billed", BillingData.getDecimalFormatted(total_billed));
				total.put("paid", BillingData.getDecimalFormatted(total_paid));
				total.put("balance",  BillingData.getDecimalFormatted(total_balance));					
			}
		
			info.put("detail", v);
			info.put("total", total);
			return info;
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	
}