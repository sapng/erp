/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.billing;


import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class FeeStructureData {
	
	public static Vector getList(String program_code, String period_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			return getList(stmt, program_code, period_id);
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Vector getList(Statement stmt, String program_code, String period_id) throws Exception {
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		r.add("program_code", program_code);
		r.add("period_id", period_id);
		r.add("fee_id");
		r.add("fee_code");
		r.add("fee_description");
		r.add("fee_amount");
		sql = r.getSQLSelect("fee_structure_program");
		ResultSet rs = stmt.executeQuery(sql);
		Vector v = new Vector();
		while ( rs.next() ) {
			Hashtable h = new Hashtable();
			h.put("id", mecca.db.Db.getString(rs, "fee_id"));
			h.put("code", mecca.db.Db.getString(rs, "fee_code"));
			h.put("description", mecca.db.Db.getString(rs, "fee_description"));
			h.put("amount",  BillingData.getDecimalFormatted(rs.getFloat("fee_amount")));
			v.addElement(h);
		}
		return v;
	}
	
	public static Vector getList(String program_code, String period_id, String[] ids) throws Exception {
		List fees = Arrays.asList(ids);
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("program_code", program_code);
			r.add("period_id", period_id);
			r.add("fee_code");
			r.add("fee_id");			
			r.add("fee_description");
			r.add("fee_amount");
			sql = r.getSQLSelect("fee_structure_program");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				String code = mecca.db.Db.getString(rs, "fee_code");
				String id = mecca.db.Db.getString(rs, "fee_id");
				if ( fees.contains(id) ) {
					h.put("code", code);
					h.put("id", id);
					h.put("description", mecca.db.Db.getString(rs, "fee_description"));
					h.put("amount",  BillingData.getDecimalFormatted(rs.getFloat("fee_amount")));
					v.addElement(h);
				}
			}
			return v;
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Vector getListMore(String program_code, String period_id, String[] ids) throws Exception {
		List fees = Arrays.asList(ids);
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("program_code", program_code);
			r.add("period_id", period_id);
			r.add("fee_code");
			r.add("fee_id");			
			r.add("fee_description");
			r.add("fee_amount");
			sql = r.getSQLSelect("fee_structure_program");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				String code = mecca.db.Db.getString(rs, "fee_code");
				String id = mecca.db.Db.getString(rs, "fee_id");
				if ( !fees.contains(id) ) {
					h.put("code", code);
					h.put("id", id);
					h.put("description", mecca.db.Db.getString(rs, "fee_description"));
					h.put("amount",  BillingData.getDecimalFormatted(rs.getFloat("fee_amount")));
					v.addElement(h);
				}
			}
			return v;
			
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	public static Vector getListMore(String program_code, String period_id, Hashtable billingInfo) throws Exception {	
			Vector details = (Vector) billingInfo.get("detail");
			String[] ids = new String[details.size()];
			for ( int i=0; i<details.size(); i++ ) {
				Hashtable detail = (Hashtable) details.elementAt(i);
				ids[i] = (String) detail.get("id");
			}
			return getListMore(program_code, period_id, ids);
	}
	
	public static void add(Hashtable h) throws Exception {
		String fee_id = mecca.sis.tools.UniqueStringId.get();
		String fee_code = (String) h.get("code");
		String fee_description = (String) h.get("description");
		String fee_amount = (String) h.get("amount");
		
		String program_code = (String) h.get("program_code");
		String period_id = (String) h.get("period_id");
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			boolean found = false;
			{
				r.add("fee_code");
				r.add("fee_code", fee_code);
				r.add("program_code", program_code);
				r.add("period_id",  period_id);
				sql = r.getSQLSelect("fee_structure_program");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) found = true;
			}
			
			if ( !found ) {
				r.clear();
				r.add("fee_id", fee_id);
				r.add("fee_code", fee_code);
				r.add("fee_description", fee_description);
				r.add("fee_amount", Float.parseFloat(fee_amount));
				r.add("program_code", program_code);
				r.add("period_id",  period_id);				
				sql = r.getSQLInsert("fee_structure_program");
				stmt.executeUpdate(sql);
			}
			else {
				r.clear();
				r.update("fee_code", fee_code);
				r.update("program_code", program_code);
				r.update("period_id",  period_id);				
				r.add("fee_description", fee_description);
				r.add("fee_amount", Float.parseFloat(fee_amount));
				sql = r.getSQLUpdate("fee_structure_program");
				stmt.executeUpdate(sql);				
			}
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void delete(Hashtable h) throws Exception {
		String program_code = (String) h.get("program_code");
		String period_id = (String) h.get("period_id");
		String fee_code = (String) h.get("code");
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("program_code", program_code);
			r.add("period_id", period_id);
			r.add("fee_code", fee_code);
			sql = r.getSQLDelete("fee_structure_program");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	public static Vector getBillingFeeList(String student_id, String period_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			Hashtable paid = new Hashtable();
			{
				sql = "select f.fee_id, SUM(d.amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_receipt_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					String amount = mecca.db.Db.getString(rs,"fee_amount");
					paid.put(fee_id, amount);
				}
			}
			
			
			Vector v = new Vector();
			{
				sql = "select f.fee_id, f.fee_code, f.fee_description, SUM(f.fee_amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_billing_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					h.put("id", fee_id);
					h.put("code", mecca.db.Db.getString(rs, "fee_code"));
					h.put("description", mecca.db.Db.getString(rs, "fee_description"));
					float amount_billed = rs.getFloat("fee_amount");
					//check for payment for this fee
					String payment = (String) paid.get(fee_id);
					if ( payment != null ) {
						float amount_paid = Float.parseFloat(payment);
						float amount_balance = amount_billed - amount_paid;
						h.put("amount",  BillingData.getDecimalFormatted(amount_balance));	
						h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));						
						h.put("amount_paid", BillingData.getDecimalFormatted(amount_paid));
					} else {
						h.put("amount",  BillingData.getDecimalFormatted(amount_billed));	
						h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));
						h.put("amount_paid", "0.00");
					}
					v.addElement(h);
				}
			}

			return v;
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Vector getBillingFeeList(String student_id, String[] feearray) throws Exception {
		List fees = Arrays.asList(feearray);
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			Hashtable paid = new Hashtable();
			{
				sql = "select f.fee_id, SUM(d.amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_receipt_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					String amount = mecca.db.Db.getString(rs,"fee_amount");
					paid.put(fee_id, amount);
				}
			}
			
			
			Vector v = new Vector();
			{
				sql = "select f.fee_id, f.fee_code, f.fee_description, SUM(f.fee_amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_billing_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					if ( fees.contains(fee_id) ) {
						h.put("id", fee_id);
						h.put("code", mecca.db.Db.getString(rs, "fee_code"));
						h.put("description", mecca.db.Db.getString(rs, "fee_description"));
						float amount_billed = rs.getFloat("fee_amount");
						//check for payment for this fee
						String payment = (String) paid.get(fee_id);
						if ( payment != null ) {
							float amount_paid = Float.parseFloat(payment);
							float amount_balance = amount_billed - amount_paid;
							h.put("amount",  BillingData.getDecimalFormatted(amount_balance));	
							h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));						
							h.put("amount_paid", BillingData.getDecimalFormatted(amount_paid));
						} else {
							h.put("amount",  BillingData.getDecimalFormatted(amount_billed));	
							h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));
							h.put("amount_paid", "0.00");
						}
						v.addElement(h);
					}
				}
			}

			return v;
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Vector getBillingFeeListMore(String student_id, String[] feearray) throws Exception {
		List fees = Arrays.asList(feearray);
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			Hashtable paid = new Hashtable();
			{
				sql = "select f.fee_id, SUM(d.amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_receipt_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					String amount = mecca.db.Db.getString(rs,"fee_amount");
					paid.put(fee_id, amount);
				}
			}
			
			
			Vector v = new Vector();
			{
				sql = "select f.fee_id, f.fee_code, f.fee_description, SUM(f.fee_amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_billing_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					if ( !fees.contains(fee_id) ) {
						h.put("id", fee_id);
						h.put("code", mecca.db.Db.getString(rs, "fee_code"));
						h.put("description", mecca.db.Db.getString(rs, "fee_description"));
						float amount_billed = rs.getFloat("fee_amount");
						//check for payment for this fee
						String payment = (String) paid.get(fee_id);
						if ( payment != null ) {
							float amount_paid = Float.parseFloat(payment);
							float amount_balance = amount_billed - amount_paid;
							h.put("amount",  BillingData.getDecimalFormatted(amount_balance));	
							h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));						
							h.put("amount_paid", BillingData.getDecimalFormatted(amount_paid));
						} else {
							h.put("amount",  BillingData.getDecimalFormatted(amount_billed));	
							h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));
							h.put("amount_paid", "0.00");
						}
						v.addElement(h);
					}
				}
			}

			return v;
			
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	public static Vector getBillingFeeListMore(String student_id, Hashtable receiptInfo) throws Exception {
		Vector details = (Vector) receiptInfo.get("detail");
		String[] ids = new String[details.size()];
		for ( int i=0; i<details.size(); i++ ) {
			Hashtable detail = (Hashtable) details.elementAt(i);
			ids[i] = (String) detail.get("id");
		}
		return getBillingFeeListMore(student_id, ids);
	}
	
	
}