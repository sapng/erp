/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.sis.billing;

import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.sis.registration.SessionData;
import mecca.sis.registration.StudentData;
import mecca.sis.struct.PeriodData;
import mecca.sis.struct.ProgramData;
import mecca.util.DateTool;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin bin Abd Mutalib
 *
 * @version 0.1
 */
public class InvoiceGenerateModule  extends mecca.portal.velocity.VTemplate {

	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/sis/billing/fee_generate.vm";
		String submit = getParam("command");
		
		Vector programList = ProgramData.getList();
		context.put("programList", programList);
		
		String program_code = getParam("program_list");
		context.put("program_code", program_code);
		
		Vector sessionList = SessionData.getListDesc();
		context.put("sessionList", sessionList);
		
		String current_session = !"".equals(getParam("session_list")) ? getParam("session_list") : SessionData.getCurrentSessionId();
		context.put("session_id", current_session);	
		
		String period_scheme = getParam("period_scheme");
		context.put("period_scheme", period_scheme);			
		
		Hashtable dateTime = DateTool.getCurrentDateTime();
		context.put("dateTime", dateTime);		
		context.put("isProgramSelected", new Boolean(false));
		context.put("isTrackSelected", new Boolean(false));
		context.put("isGenerated", new Boolean(false));
		context.put("isSelected", new Boolean(false));
	
		if ( "getProgram".equals(submit) ) {
			Vector schemes = ProgramData.getPeriodStructureList2(program_code);
			context.put("periodSchemes", schemes);
			context.put("isProgramSelected", new Boolean(true));
		} else if ( "getTrack".equals(submit) ) {
		    context.put("isProgramSelected", new Boolean(true));
		    context.put("isTrackSelected", new Boolean(true));
		} else if ( "createInvoices".equals(submit) ) {
		    createInvoices(session);
		    context.put("isGenerated", new Boolean(true));
		    context.put("isProgramSelected", new Boolean(true));
		    context.put("isTrackSelected", new Boolean(true));
		}		
		
		Template template = engine.getTemplate(template_name);	
		return template;		
	} 
	
	void createInvoices(HttpSession session) throws Exception {
		String programCode = getParam("program_list");
		//Vector feeList = FeeData.getList(programCode);
		String period_scheme = getParam("period_scheme");
		context.put("period_scheme", period_scheme);
		
		Hashtable periodRef = PeriodData.getPeriodNameRef("");
		
		String session_id = getParam("session_list");
		if ( "".equals(session_id) ) {
		    session_id = SessionData.getCurrentSessionId();
		}
		context.put("session_id", session_id);

		String yr = getParam("bill_year"), mn = getParam("bill_month"), dy = getParam("bill_day");
		Hashtable billDate = new Hashtable();
		billDate.put("year", yr);
		billDate.put("month", mn);
		billDate.put("day", dy);		
		Db db = null;
		String sql = "";
		Vector statusList = new Vector();
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			//
			Vector studentList = new Vector();
			studentList = StudentData.getStudentListAlternateTrack(stmt, period_scheme, session_id, programCode);
			if ( studentList.size() == 0 ) studentList = StudentData.getStudentList(stmt, session_id, programCode);
			
			if ( studentList.size() > 0 ) {
			    for ( int i=0; i < studentList.size(); i++ ) {
			        Hashtable h = (Hashtable) studentList.elementAt(i);
			        String student_id = (String) h.get("id");
			        String student_name = (String) h.get("name");
			        String period_id = (String) h.get("period_id");
			        
			        //System.out.println(student_id + "=" + period_id);
			        
			        //status list
			        Hashtable status = new Hashtable();
			        status.put("student_id", student_id);
			        status.put("student_name", student_name);
			        status.put("period_id", period_id);
			        status.put("period_name", (String) periodRef.get(period_id));

			        Hashtable feeInfo = FeeData.getStudyFee(stmt, programCode, period_id);
			        Vector feeList = (Vector) feeInfo.get("feeList");
			        if ( feeList.size() > 0 ) {
			            //String invoiceNo = BillingData.getInvoiceNo(stmt);
			            //BillingData.createInvoice(stmt, feeList, invoiceNo, student_id, session_id, period_id, billDate);
			            
			            BillingData.createInvoice(stmt, feeList, student_id, session_id, period_id, billDate);
			            status.put("success", new Boolean(true));
			            status.put("feeList", feeList);
			            status.put("amount_total", BillingData.getDecimalFormatted(((Float) feeInfo.get("amountTotal")).floatValue()));
			        }
			        else {
			            System.out.println("Fee Structure Does NOT Exist For " + programCode + "/" + period_id);
			            status.put("success", new Boolean(false));
			            status.put("feeList", feeList);
			            status.put("amount_total", "0");
			        }
			        statusList.addElement(status);
			    }
			}
			context.put("studentList", studentList);
			context.put("statusList", statusList);
			
		} finally {
			if ( db != null ) db.close();
		}
	}	
}
