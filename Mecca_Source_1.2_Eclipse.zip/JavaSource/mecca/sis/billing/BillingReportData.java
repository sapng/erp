/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.billing;


import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import mecca.db.Db;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class BillingReportData { 
	public static Hashtable getReport() throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			Hashtable report = new Hashtable();
			Vector v = new Vector();
			Vector fees = new Vector();
			{
				sql = "select distinct f.fee_code ";
				sql += "from fee_structure_program f, ";
				sql += "student_billing_detail d ";
				sql += "where f.fee_id = d.fee_id ";
				ResultSet rs = stmt.executeQuery(sql);	
				while ( rs.next() ) {
					fees.addElement(mecca.db.Db.getString(rs, "fee_code"));
				}
			}
			report.put("fees", fees);
			float total = 0.0f;
			{
				sql = "select d.student_id, f.fee_code, sum(amount) as amount, s.name,  p.program_name ";
				sql += "from fee_structure_program f, ";
				sql += "student_billing_detail d, student s, student_course sc, program p ";
				sql += "where f.fee_id = d.fee_id  ";
				sql += "and d.student_id = s.id ";
				sql += "and d.student_id = sc.student_id ";
				sql += "and sc.program_code = p.program_code ";
				sql += "group by d.student_id, f.fee_code ";
				sql += "order by s.name ";
				ResultSet rs = stmt.executeQuery(sql);
				String temp_id = "";
				String temp_name = "";
				String temp_program = "";
				float sub_total = 0.0f;
				
				Hashtable bill = new Hashtable();
				while ( rs.next() ) {
					String student_id = mecca.db.Db.getString(rs, "student_id");
					String name = mecca.db.Db.getString(rs, "name");
					String program_name = mecca.db.Db.getString(rs, "program_name");
					if ( !temp_id.equals(student_id) ) {
						if ( !"".equals(temp_id) ) {
							Hashtable rec = new Hashtable();
							rec.put("student_id", temp_id);
							rec.put("name", temp_name);
							rec.put("program_name", temp_program);
							rec.put("bill", bill);
							rec.put("sub_total", BillingData.getDecimalFormatted(sub_total));
							v.addElement(rec);
						}
						temp_id = student_id;	
						temp_name = name;
						temp_program = program_name;
						bill = new Hashtable();
						sub_total = 0.0f;
					}
					String fee_code =  mecca.db.Db.getString(rs, "fee_code");
					float amount = rs.getFloat("amount");
					sub_total += amount;
					total += amount;
					bill.put(fee_code, BillingData.getDecimalFormatted(amount));
				}	
				if ( !"".equals(temp_id) ) {
					Hashtable rec = new Hashtable();
					rec.put("student_id", temp_id);
					rec.put("name", temp_name);
					rec.put("program_name", temp_program);
					rec.put("bill", bill);
					rec.put("sub_total", BillingData.getDecimalFormatted(sub_total));
					v.addElement(rec);
				}				
						
			}
			report.put("data", v);
			report.put("total", BillingData.getDecimalFormatted(total));
			return report;
		} finally {
			if ( db != null ) db.close();
		}	
	}
	


}