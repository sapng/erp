/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.sis.billing;


import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;
import mecca.sis.struct.PeriodData;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class FeeData {
	
	public static Vector getCodeList() throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			sql = "select code, name, additional from fee_code order by code";
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("code", rs.getString(1));
				h.put("name", rs.getString(2));
				h.put("additional", new Integer(rs.getInt(3)));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Vector getCodeList(int additional) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			sql = "select code, name from fee_code" +
			" where additional = " + additional +
			" order by code";
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("code", rs.getString(1));
				h.put("name", rs.getString(2));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	public static Vector getList(String program_code) throws Exception {
	    Hashtable periodRef = PeriodData.getPeriodNameRef("");
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("program_code", program_code);
			//r.add("session_id", session_id);
			r.add("fee_id");
			r.add("fee_code");
			r.add("fee_description");
			r.add("fee_amount");
			r.add("f.period_id");
			r.add("f.period_id", r.unquote("p.period_id"));
			sql = r.getSQLSelect("fee_structure_program f, period p", "period_sequence");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("id", mecca.db.Db.getString(rs, "fee_id"));
				h.put("code", mecca.db.Db.getString(rs, "fee_code"));
				h.put("description", mecca.db.Db.getString(rs, "fee_description"));
				h.put("amount",  BillingData.getDecimalFormatted(rs.getFloat("fee_amount")));
				
				String period_id = Db.getString(rs, "period_id");
				String period_name = (String) periodRef.get(period_id);
				h.put("period_id", period_id);
				h.put("period_name", period_name);
				v.addElement(h);
			}
			return v;
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Hashtable getList(String program_code, String period_scheme) throws Exception {
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			Vector v = new Vector();
			Hashtable fees = new Hashtable();
			Vector periodIds = new Vector();
			{
				sql = "select period_id " +
				"from period where period_root_id = '" + period_scheme + "'";
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					periodIds.addElement(rs.getString(1));
				}
			}
			Vector feeList = null;
			for ( int i=0; i < periodIds.size(); i++) {
				String period_id = (String) periodIds.elementAt(i);
				Hashtable feeInfo = getStudyFee(stmt, program_code, period_id);
				feeList = (Vector) feeInfo.get("feeList");
				fees.put(period_id, feeList);
			}
			
			return fees;
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Hashtable getFeePeriodMap(String program_code, String period_scheme, String intake) throws Exception {
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			return getFeePeriodMap(stmt, program_code, period_scheme, intake);
			
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	public static Hashtable getFeePeriodMap(Statement stmt, String program_code, String period_scheme, String intake) throws Exception {

		String sql = "";
		Vector v = new Vector();
		Hashtable fees = new Hashtable();
		Vector periodIds = new Vector();
		{
			sql = "select period_id " +
			"from period where period_root_id = '" + period_scheme + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next() ) {
				periodIds.addElement(rs.getString(1));
			}
		}
		Vector feeList = null;
		for ( int i=0; i < periodIds.size(); i++) {
			String period_id = (String) periodIds.elementAt(i);
			Hashtable feeInfo = getStudyFee(stmt, program_code, period_id, intake);
			feeList = (Vector) feeInfo.get("feeList");
			fees.put(period_id, feeList);
		}
		
		return fees;

	}	
	
	public static Hashtable getStudyFee(String program_code, String period_id) throws Exception {
		return getStudyFee(program_code, period_id, "");
	}
	
	public static Hashtable getStudyFee(String program_code, String period_id, String intake_session) throws Exception {
		Db db = null;
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			return getStudyFee(stmt, program_code, period_id, intake_session);
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	public static Hashtable getStudyFee(Statement stmt, String program_code, String period_id) throws Exception {
		
		return getStudyFee(stmt, program_code, period_id, "");
	}
	

	public static Hashtable getStudyFee(Statement stmt, String program_code, String period_id, String intake_session) throws Exception {
		return getStudyFee(stmt, program_code, period_id, intake_session, "");
	}
	
	public static Hashtable getStudyFee(Statement stmt, String program_code, String period_id, String intake_session, String type) throws Exception {
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		r.add("program_code", program_code);
		r.add("period_id", period_id);
		r.add("f.code", r.unquote("p.fee_code"));
		if ( !"".equals(intake_session)) {
			r.add("p.intake_session", intake_session);
		}
		if ( "C".equals(type) ) r.add("f.additional", 0);
		else if ( "A".equals(type) ) r.add("f.additional", 1);
		r.add("p.fee_id");
		r.add("p.fee_code");
		r.add("p.fee_description");
		r.add("p.fee_amount");
		r.add("p.priority");
		r.add("f.additional");
		sql = r.getSQLSelect("fee_structure_program p, fee_code f", "additional, priority");
		
		//System.out.println(sql);
		ResultSet rs = stmt.executeQuery(sql);
		Vector v = new Vector();
		Hashtable info = new Hashtable();
		float total = 0.0f;
		while ( rs.next() ) {
			Hashtable h = new Hashtable();
			h.put("period_id", period_id);
			String code = mecca.db.Db.getString(rs, "fee_code");
			
			//System.out.println(period_id + "=" + code);
			
			h.put("id", mecca.db.Db.getString(rs, "fee_id"));
			h.put("code", code);
			h.put("description", mecca.db.Db.getString(rs, "fee_description"));
			float amount = rs.getFloat("fee_amount");
			total += amount;
			h.put("amount", new Float(amount));
			h.put("amount_formatted",  BillingData.getDecimalFormatted(amount));
			h.put("priority", new Integer(rs.getInt("priority")));
			h.put("additional", new Integer(rs.getInt("additional")));
			v.addElement(h);
			
		}
		info.put("feeList", v);
		info.put("amountTotal", new Float(total));
		info.put("amountTotal_formatted",  BillingData.getDecimalFormatted(total));
		return info;
	}
	
	
	public static Hashtable getTotalFeePeriodMap(Statement stmt, String program_code, String period_scheme, String intake, int additional) throws Exception {

		String sql = "";
		Vector v = new Vector();
		Hashtable fees = new Hashtable();
		Vector periodIds = new Vector();
		{
			sql = "select period_id " +
			"from period where period_root_id = '" + period_scheme + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next() ) {
				periodIds.addElement(rs.getString(1));
			}
		}
		Vector feeList = null;
		for ( int i=0; i < periodIds.size(); i++) {
			String period_id = (String) periodIds.elementAt(i);
			Hashtable feeInfo = getStudyFeeTotal(stmt, program_code, period_id, intake, additional);
			//System.out.println()
			fees.put(period_id, feeInfo);
		}
		
		return fees;

	}	
	
	public static Hashtable getStudyFeeTotal(String program_code, String period_id, String intake_session, int additional) throws Exception {
		Db db = null;
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			return getStudyFeeTotal(stmt, program_code, period_id, intake_session, additional);
		} finally {
			if ( db != null ) db.close();
		}
	}		
	
	public static Hashtable getStudyFeeTotal(Statement stmt, String program_code, String period_id, int additional) throws Exception {
		
		return getStudyFeeTotal(stmt, program_code, period_id, "", additional);
	}		
	
	
	public static Hashtable getStudyFeeTotal(Statement stmt, String program_code, String period_id, String intake_session, int additional) throws Exception {
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		r.add("program_code", program_code);
		r.add("period_id", period_id);
		r.add("f.code", r.unquote("p.fee_code"));
		if ( !"".equals(intake_session)) {
			r.add("p.intake_session", intake_session);
		}
		if ( additional > -1 )
			r.add("f.additional", additional);
		r.add("SUM(p.fee_amount) AS amount");
		sql = r.getSQLSelect("fee_structure_program p, fee_code f");
		sql += " GROUP BY p.period_id";
		
		//System.out.println(sql);
		ResultSet rs = stmt.executeQuery(sql);
		Vector v = new Vector();
		Hashtable fee = new Hashtable();
		float total = 0.0f;
		while ( rs.next() ) {
			float amount = rs.getFloat("amount");
			total += amount;
			fee.put("amount", new Float(total));
			fee.put("amount_formatted", BillingData.getDecimalFormatted(amount));
		}
		return fee;
	}	
	
	public static Hashtable getStudyFeeForDeposit(Statement stmt, String program_code, String period_id) throws Exception {
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		r.add("fee_id");
		r.add("fee_code");
		r.add("fee_description");
		r.add("fee_amount");
		r.add("priority");
		r.add("program_code", program_code);
		r.add("period_id", period_id);
		sql = r.getSQLSelect("fee_structure_program", "priority");
		//System.out.println(sql);
		ResultSet rs = stmt.executeQuery(sql);
		Vector v = new Vector();
		Hashtable info = new Hashtable();
		float total = 0.0f;
		while ( rs.next() ) {
			Hashtable h = new Hashtable();
			h.put("period_id", period_id);
			String code = mecca.db.Db.getString(rs, "fee_code");
			
			//System.out.println(period_id + "=" + code);
			
			h.put("id", mecca.db.Db.getString(rs, "fee_id"));
			h.put("code", code);
			h.put("description", mecca.db.Db.getString(rs, "fee_description"));
			float amount = rs.getFloat("fee_amount");
			total += amount;
			h.put("amount", new Float(amount));
			h.put("amount_formatted",  BillingData.getDecimalFormatted(amount));
			h.put("priority", new Integer(rs.getInt("priority")));
			v.addElement(h);
			
		}
		info.put("feeList", v);
		info.put("amountTotal", new Float(total));
		return info;
	}	
	
	public static Vector getList(String program_code, String[] ids) throws Exception {
	    
	    //map fee code with session id
	    
		List fees = Arrays.asList(ids);
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("program_code", program_code);
			//r.add("session_id", session_id);
			r.add("fee_code");
			r.add("fee_id");			
			r.add("fee_description");
			r.add("fee_amount");
			r.add("period_id");
			sql = r.getSQLSelect("fee_structure_program");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				String code = mecca.db.Db.getString(rs, "fee_code");
				String id = mecca.db.Db.getString(rs, "fee_id");
				if ( fees.contains(id) ) {
					h.put("code", code);
					h.put("id", id);
					h.put("description", mecca.db.Db.getString(rs, "fee_description"));
					float amount = rs.getFloat("fee_amount");
					h.put("amount",  new Float(amount));
					h.put("amountFormatted", BillingData.getDecimalFormatted(amount));
					h.put("period_id", rs.getString("period_id"));
					//h.put("session_id", (String) sessionMap.get(id));
					v.addElement(h);
				}
			}
			return v;
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Vector getListMore(String program_code, String[] ids) throws Exception {
		List fees = Arrays.asList(ids);
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("program_code", program_code);
			//r.add("session_id", session_id);
			r.add("fee_code");
			r.add("fee_id");			
			r.add("fee_description");
			r.add("fee_amount");
			sql = r.getSQLSelect("fee_structure_program");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				String code = mecca.db.Db.getString(rs, "fee_code");
				String id = mecca.db.Db.getString(rs, "fee_id");
				if ( !fees.contains(id) ) {
					h.put("code", code);
					h.put("id", id);
					h.put("description", mecca.db.Db.getString(rs, "fee_description"));
					h.put("amount",  BillingData.getDecimalFormatted(rs.getFloat("fee_amount")));
					v.addElement(h);
				}
			}
			return v;
			
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	public static Vector getListMore(String program_code, Hashtable billingInfo) throws Exception {	
			Vector details = (Vector) billingInfo.get("detail");
			String[] ids = new String[details.size()];
			for ( int i=0; i<details.size(); i++ ) {
				Hashtable detail = (Hashtable) details.elementAt(i);
				ids[i] = (String) detail.get("id");
			}
			return getListMore(program_code, ids);
	}
	

	
	public static String add(Hashtable h) throws Exception {
		String fee_id = mecca.sis.tools.UniqueStringId.get();
		String fee_code = (String) h.get("code");
		String fee_description = (String) h.get("description");
		String fee_amount = (String) h.get("amount");
		int additional = ((Integer) h.get("additional")).intValue();
		
		String program_code = (String) h.get("program_code");
		String period_id = (String) h.get("period_id");
		String period_scheme = (String) h.get("period_scheme");
		String intake_session = (String) h.get("intake_session");

		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			boolean found = false;
			{
				r.clear();
				r.add("code");
				r.add("code", fee_code);
				sql = r.getSQLSelect("fee_code");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) found = true;
				
			}
			if ( !found ) {
				r.clear();
				r.add("code", fee_code);
				r.add("name", fee_description);
				r.add("additional", additional);
				sql = r.getSQLInsert("fee_code");
				stmt.executeUpdate(sql);
			}
			found = false;
			int priority = 0;
			{
				r.clear();
				r.add("MAX(priority) AS priority");
				r.add("program_code", program_code);
				r.add("period_id",  period_id);
				r.add("period_scheme", period_scheme);
				r.add("intake_session", intake_session);
				sql = r.getSQLSelect("fee_structure_program");
				
				sql += "GROUP BY program_code, period_id";
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) {
				    priority = rs.getInt("priority");
				}
				priority++;
			}
			{
				r.clear();
				r.add("fee_id");
				r.add("fee_code", fee_code);
				r.add("program_code", program_code);
				r.add("period_id",  period_id);
				r.add("period_scheme", period_scheme);
				r.add("intake_session", intake_session);
				sql = r.getSQLSelect("fee_structure_program");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) {
				    found = true;
				    fee_id = rs.getString(1);
				}
			}
			
			
			if ( !found ) {
				r.clear();
				r.add("fee_id", fee_id);
				r.add("fee_code", fee_code);
				r.add("fee_description", fee_description);
				r.add("fee_amount", Float.parseFloat(fee_amount));
				r.add("program_code", program_code);
				r.add("period_id",  period_id);		
				r.add("period_scheme", period_scheme);
				r.add("intake_session", intake_session);
				r.add("priority", priority);
				sql = r.getSQLInsert("fee_structure_program");
				
				System.out.println(sql);
				
				stmt.executeUpdate(sql);
			}
			else {
				r.clear();
				r.update("fee_code", fee_code);
				r.update("program_code", program_code);
				r.update("period_id",  period_id);		
				r.update("period_scheme", period_scheme);	
				r.update("intake_session", intake_session);
				r.add("fee_description", fee_description);
				r.add("fee_amount", Float.parseFloat(fee_amount));
				sql = r.getSQLUpdate("fee_structure_program");
				//System.out.println(sql);
				stmt.executeUpdate(sql);				
			}
			
			return fee_id;
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void delete(Hashtable h) throws Exception {
		String program_code = (String) h.get("program_code");
		String period_id = (String) h.get("period_id");
		String fee_code = (String) h.get("code");
		String intake_session = (String) h.get("intake_session");
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("program_code", program_code);
			r.add("period_id", period_id);
			r.add("fee_code", fee_code);
			r.add("intake_session", intake_session);
			sql = r.getSQLDelete("fee_structure_program");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	public static Vector getBillingFeeList(String student_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			Hashtable paid = new Hashtable();
			{
				sql = "select f.fee_id, SUM(d.amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_receipt_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					String amount = mecca.db.Db.getString(rs,"fee_amount");
					paid.put(fee_id, amount);
				}
			}
			
			
			Vector v = new Vector();
			{
				sql = "select f.fee_id, f.fee_code, f.fee_description, SUM(f.fee_amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_billing_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					h.put("id", fee_id);
					h.put("code", mecca.db.Db.getString(rs, "fee_code"));
					h.put("description", mecca.db.Db.getString(rs, "fee_description"));
					float amount_billed = rs.getFloat("fee_amount");
					//check for payment for this fee
					String payment = (String) paid.get(fee_id);
					if ( payment != null ) {
						float amount_paid = Float.parseFloat(payment);
						float amount_balance = amount_billed - amount_paid;
						h.put("amount",  BillingData.getDecimalFormatted(amount_balance));	
						h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));						
						h.put("amount_paid", BillingData.getDecimalFormatted(amount_paid));
						h.put("amount_float",  new Float(amount_balance));	
						h.put("amount_billed_float", new Float(amount_billed));						
						h.put("amount_paid_float", new Float(amount_paid));								
					} else {
						h.put("amount",  BillingData.getDecimalFormatted(amount_billed));	
						h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));
						h.put("amount_paid", "0.00");
						h.put("amount_float",  new Float(amount_billed));
						h.put("amount_billed_float", new Float(amount_billed));						
						h.put("amount_paid_float", new Float(0.0f));							
					}
					v.addElement(h);
				}
			}

			return v;
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Vector getBillingFeeList(String student_id, String[] feearray) throws Exception {
		List fees = Arrays.asList(feearray);
		
		System.out.println("xxx" + fees.size());
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			Hashtable paid = new Hashtable();
			{
				sql = "select f.fee_id, SUM(d.amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_receipt_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					String amount = mecca.db.Db.getString(rs,"fee_amount");
					paid.put(fee_id, amount);
				}
			}
			
			
			Vector v = new Vector();
			{
				sql = "select f.fee_id, f.fee_code, f.fee_description, SUM(f.fee_amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_billing_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				System.out.println(sql);
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					System.out.println(fee_id);
					if ( fees.contains(fee_id) ) {
						h.put("id", fee_id);
						h.put("code", mecca.db.Db.getString(rs, "fee_code"));
						h.put("description", mecca.db.Db.getString(rs, "fee_description"));
						float amount_billed = rs.getFloat("fee_amount");
						//check for payment for this fee
						String payment = (String) paid.get(fee_id);
						if ( payment != null ) {
							float amount_paid = Float.parseFloat(payment);
							float amount_balance = amount_billed - amount_paid;
							h.put("amount",  BillingData.getDecimalFormatted(amount_balance));	
							h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));						
							h.put("amount_paid", BillingData.getDecimalFormatted(amount_paid));
							h.put("amount_float",  new Float(amount_balance));	
							h.put("amount_billed_float", new Float(amount_billed));						
							h.put("amount_paid_float", new Float(amount_paid));							
						} else {
							h.put("amount",  BillingData.getDecimalFormatted(amount_billed));	
							h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));
							h.put("amount_paid", "0.00");
							h.put("amount_float",  new Float(amount_billed));
							h.put("amount_billed_float", new Float(amount_billed));						
							h.put("amount_paid_float", new Float(0.0f));									
						}
						v.addElement(h);
					}
				}
			}

			return v;
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Vector getBillingFeeListMore(String student_id, String[] feearray) throws Exception {
		List fees = Arrays.asList(feearray);
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			Hashtable paid = new Hashtable();
			{
				sql = "select f.fee_id, SUM(d.amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_receipt_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					String amount = mecca.db.Db.getString(rs,"fee_amount");
					paid.put(fee_id, amount);
				}
			}
			
			
			Vector v = new Vector();
			{
				sql = "select f.fee_id, f.fee_code, f.fee_description, SUM(f.fee_amount) AS fee_amount ";
				sql += " from fee_structure_program f, student_billing_detail d ";
				sql += " where f.fee_id = d.fee_id and d.student_id = '" + student_id + "' ";
				sql += " group by f.fee_id";
				
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					String fee_id = mecca.db.Db.getString(rs, "fee_id");
					if ( !fees.contains(fee_id) ) {
						h.put("id", fee_id);
						h.put("code", mecca.db.Db.getString(rs, "fee_code"));
						h.put("description", mecca.db.Db.getString(rs, "fee_description"));
						float amount_billed = rs.getFloat("fee_amount");
						//check for payment for this fee
						String payment = (String) paid.get(fee_id);
						if ( payment != null ) {
							float amount_paid = Float.parseFloat(payment);
							float amount_balance = amount_billed - amount_paid;
							h.put("amount",  BillingData.getDecimalFormatted(amount_balance));	
							h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));						
							h.put("amount_paid", BillingData.getDecimalFormatted(amount_paid));
						} else {
							h.put("amount",  BillingData.getDecimalFormatted(amount_billed));	
							h.put("amount_billed", BillingData.getDecimalFormatted(amount_billed));
							h.put("amount_paid", "0.00");
						}
						v.addElement(h);
					}
				}
			}

			return v;
			
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	public static Vector getBillingFeeListMore(String student_id, Hashtable receiptInfo) throws Exception {
		Vector details = (Vector) receiptInfo.get("detail");
		String[] ids = new String[details.size()];
		for ( int i=0; i<details.size(); i++ ) {
			Hashtable detail = (Hashtable) details.elementAt(i);
			ids[i] = (String) detail.get("id");
		}
		return getBillingFeeListMore(student_id, ids);
	}
	
	
}