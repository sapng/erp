/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.library;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;
import mecca.db.UniqueID;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ItemData {

	public static Vector getList(String group) throws Exception {
		Db db = null;
		String sql = "";
		Vector v = new Vector();
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.clear();
			r.add("item_id");
			r.add("item_name");
			r.add("file_name");
			r.add("item_description");
			r.add("group_id", group);
			sql = r.getSQLSelect("library_item");
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next() ) {
				Item item = new Item();
				item.setId(rs.getString("item_id"));
				item.setName(rs.getString("item_name"));
				item.setFileName(rs.getString("file_name"));
				item.setDescription(Db.getString(rs, "item_description"));
				item.setGroupId(group);
				v.addElement(item);
			}
			
		} finally {
			if ( db != null ) db.close();
		}	
		return v;
	}
	
	public static void add(Item item) throws Exception {
		Db db = null;
		String sql = "";
		try {
			String uid = Long.toString(UniqueID.get());
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("item_id", uid);
			r.add("item_name", item.getName());
			r.add("item_description", item.getDescription());
			r.add("file_name", item.getFileName());
			r.add("group_id", item.getGroupId());
			sql = r.getSQLInsert("library_item");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}	
		
	}
	
	public static void delete(String id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("item_id", id);
			sql = r.getSQLDelete("library_item");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}	
		
	}	
	
	public static void delete(String[] ids) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			for ( int i=0; i < ids.length; i++ ) {
				r.clear();
				r.add("item_id", ids[i]);
				sql = r.getSQLDelete("library_item");
				stmt.executeUpdate(sql);
			}
		} finally {
			if ( db != null ) db.close();
		}	
		
	}		


}