/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.library;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;
import mecca.db.UniqueID;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class GroupData {

	public static Vector getList(String category) throws Exception {
		Db db = null;
		String sql = "";
		Vector v = new Vector();
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.clear();
			r.add("group_id");
			r.add("group_name");
			r.add("category_id");
			r.add("category_id", category);
			sql = r.getSQLSelect("library_group");
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next() ) {
				Group g = new Group();
				g.setId(rs.getString("group_id"));
				g.setName(rs.getString("group_name"));
				g.setCategoryId(rs.getString("category_id"));
				v.addElement(g);
			}
		} finally {
			if ( db != null ) db.close();
		}	
		return v;
	}
	
	public static Group getData(String group) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.clear();
			r.add("group_id");
			r.add("group_name");
			r.add("c.category_id");
			r.add("category_name");
			r.add("group_id", group);			
			r.add("g.category_id", r.unquote("c.category_id"));
			sql = r.getSQLSelect("library_group g, library_category c");
			ResultSet rs = stmt.executeQuery(sql);
			Group g = new Group();
			if ( rs.next() ) {
				g.setId(rs.getString("group_id"));
				g.setName(rs.getString("group_name"));
				g.setCategoryId(rs.getString("category_id"));
				g.setCategoryName(rs.getString("category_name"));
			}
			return g;
		} finally {
			if ( db != null ) db.close();
		}	
	}	

	public static void add(Group g) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			String uid = Long.toString(UniqueID.get());
			r.add("group_id", uid);
			r.add("group_name", g.getName());
			r.add("category_id", g.getCategoryId());
			sql = r.getSQLInsert("library_group");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}	
	
	public static void delete(String id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			r.add("group_id", id);
			sql = r.getSQLDelete("library_item");
			stmt.executeUpdate(sql);
						
			r.clear();
			r.add("group_id", id);
			sql = r.getSQLDelete("library_group");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}	
		
	}			


}