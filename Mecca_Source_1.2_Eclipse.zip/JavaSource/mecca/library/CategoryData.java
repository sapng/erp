/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.library;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;
import mecca.db.UniqueID;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class CategoryData {

	public static Vector getList() throws Exception {
		Db db = null;
		String sql = "";
		Vector v = new Vector();
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.clear();
			r.add("category_id");
			r.add("category_name");
			r.add("category_type");
			sql = r.getSQLSelect("library_category");
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next() ) {
				Category c = new Category();
				c.setId(rs.getString("category_id"));
				c.setName(rs.getString("category_name"));
				c.setType(rs.getString("category_type"));
				v.addElement(c);
			}
		} finally {
			if ( db != null ) db.close();
		}	
		return v;
	}
	
	public static Category getData(String id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.clear();
			r.add("category_id", id);
			r.add("category_name");
			r.add("category_type");
			sql = r.getSQLSelect("library_category");
			ResultSet rs = stmt.executeQuery(sql);
			Category c = new Category();
			if ( rs.next() ) {
				
				c.setId(id);
				c.setName(rs.getString("category_name"));
				c.setType(rs.getString("category_type"));
			}
			return c;
		} finally {
			if ( db != null ) db.close();
		}	
	}	

	public static void add(Category c) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			String uid = Long.toString(UniqueID.get());
			r.add("category_id", uid);
			r.add("category_name", c.getName());
			r.add("category_type", c.getType());
			sql = r.getSQLInsert("library_category");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}	
	
	public static void delete(String id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			r.add("category_id", id);
			sql = r.getSQLDelete("library_group");
			stmt.executeUpdate(sql);
			
			
			r.clear();
			r.add("category_id", id);
			sql = r.getSQLDelete("library_category");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}	
		
	}			


}