/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.crm;

import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ManageEnquiryModule extends mecca.portal.velocity.VTemplate {
	
	protected boolean isLastPage = false;
	protected int LIST_ROWS = 10;		
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/crm/list_enquiry.vm";
		
		String submit = getParam("command");
		
		if ( "open".equals(submit)) {
			template_name = "vtl/crm/enquiry_open.vm";
			
			Vector statusList = EnquiryData.getEnquiryStatus();
			context.put("statusList", statusList);	
			
			Vector categoryList = EnquiryData.getCategoryList();
			context.put("categoryList", categoryList);				
					
			String enquiry_id = getParam("enquiry_id");
			Hashtable h = EnquiryData.getData(enquiry_id);
			context.put("data", h);
		}
		else if ( "change_status".equals(submit) ) {
			String status = getParam("status");
			String enquiry_id = getParam("enquiry_id");
			
			context.put("enquiry_id", enquiry_id);
			
			if ("create".equals(status)) {
				template_name = "vtl/crm/enquiry_new_status.vm";
			}
			else {
				EnquiryData.setEnquiryStatus(enquiry_id, status);	
				template_name = "vtl/crm/enquiry_open.vm";
				
				Vector statusList = EnquiryData.getEnquiryStatus();
				context.put("statusList", statusList);	
						
				Hashtable h = EnquiryData.getData(enquiry_id);
				context.put("data", h);				
			}
			
		}	
		else if ( "add_status".equals(submit)) {
			template_name = "vtl/crm/enquiry_open.vm";
			String status_id = getParam("status_name");
			String status_name = getParam("status_name");
			String status_description = getParam("status_description");
			String enquiry_id = getParam("enquiry_id");
			context.put("enquiry_id", enquiry_id);
			if ( !"".equals(status_id) && !"".equals(status_name) && !"".equals(status_description) ){
				EnquiryData.addNewStatus(status_id, status_name, status_description, enquiry_id);
			}
			Vector statusList = EnquiryData.getEnquiryStatus();
			context.put("statusList", statusList);
			Hashtable h = EnquiryData.getData(enquiry_id);
			context.put("data", h);
				
		} 
		else if ( "update".equals(submit) ) {
			String enquiry_id = getParam("enquiry_id");	
			context.put("enquiry_id", enquiry_id);
			
			Hashtable reqData = getFormData();
			reqData.put("enquiry_id", enquiry_id);
			
			EnquiryData.update(reqData);
			
			//EnquiryData.update(enquiry_id, status, category, comment);

			Vector statusList = EnquiryData.getEnquiryStatus();
			context.put("statusList", statusList);	
			
			Vector categoryList = EnquiryData.getCategoryList();
			context.put("categoryList", categoryList);					
						
			Hashtable h = EnquiryData.getData(enquiry_id);
			context.put("data", h);				
			
			template_name = "vtl/crm/enquiry_open.vm";			
		}	
		else if ( "escalate".equals(submit) ) {
			String enquiry_id = getParam("enquiry_id");	
			context.put("enquiry_id", enquiry_id);			
			
			template_name = "vtl/crm/list_responsible.vm";	
			Vector responsibles = ResponsiblesData.getList();
			Vector escalations = EnquiryData.getResponsibleList(enquiry_id);
			//remove in responsibles if exists in escalations
			for ( int i=0; i < escalations.size(); i++ ) {
				responsibles.remove((ResponsibleInfo) escalations.elementAt(i));				
			}
			context.put("responsibles", responsibles);
			context.put("escalations", escalations);
		} 		
		else if ( "doEscalate".equals(submit) ) {
			String enquiry_id = getParam("enquiry_id");	
			
			doEscalate(session);
			
			Vector statusList = EnquiryData.getEnquiryStatus();
			context.put("statusList", statusList);	
			Vector categoryList = EnquiryData.getCategoryList();
			context.put("categoryList", categoryList);					
			Hashtable h = EnquiryData.getData(enquiry_id);
			context.put("data", h);				
			template_name = "vtl/crm/enquiry_open.vm";	
		} 	
		else if ( "doRemoveEscalate".equals(submit) ) {
			String enquiry_id = getParam("enquiry_id");	
			
			doRemoveEscalate(session);
			
			Vector statusList = EnquiryData.getEnquiryStatus();
			context.put("statusList", statusList);	
			Vector categoryList = EnquiryData.getCategoryList();
			context.put("categoryList", categoryList);					
			Hashtable h = EnquiryData.getData(enquiry_id);
			context.put("data", h);				
			template_name = "vtl/crm/enquiry_open.vm";	
		}	
		else if ( "openReply".equals(submit) ) {
			String responsible_id = getParam("responsible_id");
			String enquiry_id = getParam("enquiry_id");
			context.put("responsible_id", responsible_id);
			context.put("enquiry_id", enquiry_id);
			//openReply(responsible_id, enquiry_id);
			ResponsibleInfo info = EnquiryData.getResponsibleReply(enquiry_id, responsible_id);
			context.put("info", info);				
			Hashtable h = EnquiryData.getData(enquiry_id);
			context.put("data", h);				
			template_name = "vtl/crm/reply.vm";	
		}	
		else if ( "reply".equals(submit) ) {
			String responsible_id = getParam("responsible_id");
			String enquiry_id = getParam("enquiry_id");
			String reply = getParam("reply");
			context.put("responsible_id", responsible_id);
			context.put("enquiry_id", enquiry_id);
			EnquiryData.addReply(enquiry_id, responsible_id, reply);
			
			Vector statusList = EnquiryData.getEnquiryStatus();
			context.put("statusList", statusList);	
			Vector categoryList = EnquiryData.getCategoryList();
			context.put("categoryList", categoryList);					
			Hashtable h = EnquiryData.getData(enquiry_id);
			context.put("data", h);				
			template_name = "vtl/crm/enquiry_open.vm";				
			
		}			
		else if ( "list".equals(submit) ) {
			prepareList(session);
			displayPreviousList(session);
		} 					
		else if ( "delete".equals(submit) ) {
			EnquiryData.delete(getParam("enquiry_id"));
			prepareList(session);
			displayPreviousList(session);	
		}
		else if ( "goPage".equals(submit) ) {
			int page = Integer.parseInt(getParam("pagenum"));
			getRows(session, page);
			session.setAttribute("page_number", new Integer(page));			
		} 			
		else {
			//Vector enquiryList = EnquiryData.getList();
			//context.put("enquiryList", enquiryList);
			
			Vector statusList = EnquiryData.getEnquiryStatus();
			context.put("statusList", statusList);	
			prepareList(session);
			getRows(session, 1);
			session.setAttribute("page_number", new Integer(1));
			context.put("page_number", new Integer(1));							
		}
		
		Template template = engine.getTemplate(template_name);	
		return template;		
		
	}
	
	
	
	void openReply(String responsible_id, String enquiry_id) throws Exception {
		ResponsibleInfo info = EnquiryData.getResponsibleReply(enquiry_id, responsible_id);
		context.put("info", info);	
	}
	
	void displayPreviousList(HttpSession session) throws Exception {
		int page = session.getAttribute("page_number") != null ?
				   ((Integer) session.getAttribute("page_number")).intValue() : 1;
		getRows(session, page);
	}
	
	void doEscalate(HttpSession session) throws Exception {
		String enquiry_id = getParam("enquiry_id");
		String[] responsibles = request.getParameterValues("responsibles");
		if ( responsibles != null ) {
			EnquiryData.addEscalate(enquiry_id, responsibles);
		}	
	}
	
	void doRemoveEscalate(HttpSession session) throws Exception {
		String enquiry_id = getParam("enquiry_id");
		String[] responsibles = request.getParameterValues("escalations");
		if ( responsibles != null ) {
			EnquiryData.removeEscalate(enquiry_id, responsibles);
		}	
	}	
	
	void updateEnquiry(HttpSession session) throws Exception {
		String enquiry_id = getParam("enquiry_id");
		String status = getParam("status");
		String category = getParam("category");
		String comment = getParam("comment");
		EnquiryData.update(enquiry_id, status, category, comment);	
	}
	
	Hashtable getFormData() throws Exception {
		Hashtable h = new Hashtable();
		
		h.put("name", getParam("name"));
		h.put("address1", getParam("address1"));
		h.put("address2", getParam("address2"));
		h.put("state", getParam("state"));
		h.put("city", getParam("city"));
		h.put("poscode", getParam("poscode"));
		h.put("country", getParam("country_list"));
		h.put("phone_home", getParam("phone_home"));
		h.put("phone_mobile", getParam("phone_mobile"));
		h.put("email", getParam("email"));
		h.put("enquiry_body", getParam("enquiry"));
		h.put("status", getParam("status"));
		h.put("category", getParam("category"));
		h.put("comment", getParam("comment"));
		return h;
	}	
	
	//-- start paging methods
	
	void prepareList(HttpSession session) throws Exception {
		Vector list = EnquiryData.getList();
		//System.out.println("enquiry size=" + list.size());
		int pages =  list.size() / LIST_ROWS;
		double leftover = ((double)list.size() % (double)LIST_ROWS);
		if ( leftover > 0.0 ) ++pages;
		context.put("pages", new Integer(pages));	
		session.setAttribute("pages", new Integer(pages));
		session.setAttribute("enquiryList", list);
		

	}	
	
	void getRows(HttpSession session, int page) throws Exception {
		Vector list = (Vector) session.getAttribute("enquiryList");
		Vector items = getPage(page, LIST_ROWS, list);
		context.put("items", items);	
		context.put("page_number", new Integer(page));
		context.put("pages", (Integer) session.getAttribute("pages" ));			
	}
	
	Vector getPage(int page, int size, Vector list) throws Exception {
		int elementstart = (page - 1) * size;
		int elementlast = 0;
		//int elementlast = page * size < list.size() ? (page * size) - 1 : list.size() - 1;
		if ( page * size < list.size() ) {
			elementlast = (page * size) - 1;
			isLastPage = false;
			context.put("eol", new Boolean(false));
		} else {
			elementlast = list.size() - 1;
			isLastPage = true;
			context.put("eol", new Boolean(true));
		}
		if ( page == 1 ) context.put("bol", new Boolean(true));
		else context.put("bol", new Boolean(false));
		Vector v = new Vector();
		for ( int i = elementstart; i < elementlast + 1; i++ ) {
			v.addElement(list.elementAt(i));
		}
		
		return v;
	}
	
	//---- end paging methods		
	
} 