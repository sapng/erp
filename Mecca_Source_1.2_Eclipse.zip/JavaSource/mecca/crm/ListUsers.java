/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.crm;

import javax.servlet.http.HttpSession;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ListUsers {
	
	static int LIST_ROWS = 10;		
	
	public static void list(HttpSession session) throws Exception {
		
		
	}
	/*
	//-- start paging methods
	
	static void prepareList(HttpSession session, org.apache.velocity.context.Context context) throws Exception {
		Vector list = EnquiryData.getList();
		System.out.println("enquiry size=" + list.size());
		int pages =  list.size() / LIST_ROWS;
		double leftover = ((double)list.size() % (double)LIST_ROWS);
		if ( leftover > 0.0 ) ++pages;
		context.put("pages", new Integer(pages));	
		session.setAttribute("pages", new Integer(pages));
			
		session.setAttribute("enquiryList", list);
		getRows(session, context, 1);
		session.setAttribute("page_number", "1");
		context.put("page_number", new Integer(1));	
	}	
	
	static void getRows(HttpSession session, org.apache.velocity.context.Context context, int page, boolean isLastPage) throws Exception {
		Vector list = (Vector) session.getAttribute("enquiryList");
		Vector items = getPage(context, page, LIST_ROWS, list, isLastPage);
		context.put("items", items);	
		context.put("page_number", new Integer(page));
		context.put("pages", (Integer) session.getAttribute("pages" ));			
	}
	
	static Vector getPage(org.apache.velocity.context.Context context, int page, int size, Vector list, boolean isLastPage) throws Exception {
		int elementstart = (page - 1) * size;
		int elementlast = 0;
		//int elementlast = page * size < list.size() ? (page * size) - 1 : list.size() - 1;
		if ( page * size < list.size() ) {
			elementlast = (page * size) - 1;
			isLastPage = false;
			context.put("eol", new Boolean(false));
		} else {
			elementlast = list.size() - 1;
			isLastPage = true;
			context.put("eol", new Boolean(true));
		}
		if ( page == 1 ) context.put("bol", new Boolean(true));
		else context.put("bol", new Boolean(false));
		Vector v = new Vector();
		for ( int i = elementstart; i < elementlast + 1; i++ ) {
			v.addElement(list.elementAt(i));
		}
		
		return v;
	}
	
	//---- end paging methods			
	
	*/
}