/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.crm;

import java.util.Hashtable;

import javax.servlet.http.HttpSession;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class EnquiryModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/crm/enquiry.vm";
		//empty unique id
		context.put("unique_id", "");
		
		String submit = getParam("command");
		
		if ( "add".equals(submit)) {
			template_name = "vtl/crm/enquiry_save.vm";
			String id = EnquiryData.saveFormData(getFormData());	
			context.put("enquiry_id", id);
			Hashtable h = EnquiryData.getData(id);
			context.put("data", h);
		}
		
		Template template = engine.getTemplate(template_name);	
		return template;		
		
	}
	

	
	Hashtable getFormData() throws Exception {
		Hashtable h = new Hashtable();
		h.put("program_code", getParam("program_list"));
		
		h.put("name", getParam("name"));
		h.put("gender", getParam("gender"));
		
		String birth_date = getParam("birth_year") + "-" + fmt(getParam("birth_month")) + "-" + fmt(getParam("birth_day"));
		h.put("birth_date", birth_date);		
		
		h.put("address1", getParam("address1"));
		h.put("address2", getParam("address2"));
		h.put("state", getParam("state"));
		h.put("city", getParam("city"));
		h.put("poscode", getParam("poscode"));
		h.put("country", getParam("country_list"));
		h.put("phone_home", getParam("phone_home"));
		h.put("phone_mobile", getParam("phone_mobile"));
		h.put("email", getParam("email"));
		h.put("academic_qualification", getParam("academic_qualification"));
		h.put("academic_year", getParam("academic_year"));
		h.put("academic_grade", getParam("academic_grade"));
		h.put("enquiry_body", getParam("enq"));
		return h;
	}
	
	String fmt(String s) {
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}
	
	
	
}
		
		