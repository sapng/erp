/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.crm;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ResponsiblesData {

	public static Vector getList() throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			rdata(r);
			sql = r.getSQLSelect("hd_responsibles r, users u");
			
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				v.addElement(getResultSetData(rs));
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}		
	}
	
	
	static void rdata(SQLRenderer r) {
		r.add("res_id");
		r.add("res_email");
		r.add("res_phone_office");
		r.add("res_phone_mobile");
		r.add("res_phone_home");
		r.add("user_name");
		r.add("r.res_id", r.unquote("u.user_login"));
	}	
	
	static ResponsibleInfo getResultSetData(ResultSet rs) throws Exception {
		ResponsibleInfo r = new ResponsibleInfo();
		r.id = Db.getString(rs, "res_id");
		r.email = Db.getString(rs, "res_email");
		r.telOffice = Db.getString(rs, "res_phone_office");
		r.telHome = Db.getString(rs, "res_phone_home");
		r.telMobile = Db.getString(rs, "res_phone_mobile");
		r.name = Db.getString(rs, "user_name");
		return r;
	}
}
