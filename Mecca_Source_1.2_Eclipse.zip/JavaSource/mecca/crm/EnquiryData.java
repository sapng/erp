/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.crm;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;
import mecca.db.UniqueID;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class EnquiryData {
	
	static String putLineBreak(String str) {
		StringBuffer txt = new StringBuffer(str);
		char c = '\n';
		while (txt.toString().indexOf(c) > -1) {
			int pos = txt.toString().indexOf(c);
			txt.replace(pos, pos + 1, "<br>");
		}
		return txt.toString();
	}	
	
	private static String fmt(String s) {
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}
	
	private static String fmt(int i) {
		String s = Integer.toString(i);
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}
	
	private static String dateString() throws Exception {
		Calendar c = new java.util.GregorianCalendar();		
		c.setTime(new java.util.Date());	
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH) + 1;
		int day = c.get(Calendar.DAY_OF_MONTH);				
		return year + "-" + fmt(month) + "-" + fmt(day);
	}			
	
	public static String saveFormData(Hashtable h) throws Exception {
		Db db = null;
		String sql= "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			String enquiry_id = Long.toString(mecca.db.UniqueID.get());
			
			r.add("enquiry_id", enquiry_id);
			r.add("name", (String) h.get("name"));
			r.add("gender", (String) h.get("gender"));
			r.add("birth_date", (String) h.get("birth_date"));
			r.add("address1", (String) h.get("address1"));
			r.add("address2", (String) h.get("address2"));
			r.add("state", (String) h.get("state"));
			r.add("city", (String) h.get("city"));
			r.add("poscode", (String) h.get("poscode"));
			r.add("country_code", (String) h.get("country"));
			r.add("phone_home", (String) h.get("phone_home"));
			r.add("phone_mobile", (String) h.get("phone_mobile"));
			r.add("email", (String) h.get("email"));
			r.add("academic_qualification", (String) h.get("academic_qualification"));
			//
			r.add("date_post", r.unquote("now()"));
			//
			r.add("academic_year", h.get("academic_year") != null ? 
						           Integer.parseInt((String) h.get("academic_year")) : 
						           0);
			r.add("academic_grade", (String) h.get("academic_grade"));
			r.add("enquiry_body", (String) h.get("enquiry_body"));
			
			sql = r.getSQLInsert("enquiry");
			stmt.executeUpdate(sql);
			
			return enquiry_id;
			
		} catch ( SQLException sqlex ) {
			throw new Exception(sqlex.getMessage() + "-" + sql);
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	static Hashtable getData(String enquiry_id) throws Exception {

		Db db = null;
		String sql= "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			Hashtable h = null;
			{		
				rdata(r);
				r.add("enquiry_id", enquiry_id);
				sql = r.getSQLSelect("enquiry");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) {
					h = getResultSetData(rs);
				}
			}
			
			if ( h != null ) {
				r.clear();
				r.add("enquiry_id", enquiry_id);
				r.add("responsible_id");
				r.add("date_escalate");
				r.add("reply_text");
				r.add("user_name");
				r.add("e.responsible_id", r.unquote("u.user_login"));
				sql = r.getSQLSelect("hd_escalation e, users u");
				ResultSet rs = stmt.executeQuery(sql);
				Vector responsibles = new Vector();
				while ( rs.next() ) {
					Hashtable res = new Hashtable();
					res.put("responsible_id", rs.getString("responsible_id"));
					res.put("responsible_name", rs.getString("user_name"));
					res.put("reply_text", Db.getString(rs, "reply_text"));
					
					java.util.Date escalateDate = rs.getDate("date_escalate");

					
					if ( escalateDate != null ) {
						Calendar c = new java.util.GregorianCalendar();
						c.setTime(escalateDate);	
						int year = c.get(Calendar.YEAR);
						int month = c.get(Calendar.MONTH) + 1;
						int day = c.get(Calendar.DAY_OF_MONTH);		
						res.put("escalate_year", new Integer(year));
						res.put("escalate_month", new Integer(month));
						res.put("escalate_day", new Integer(day));
						res.put("date_escalate", new java.text.SimpleDateFormat ("d MMM, yyyy").format(rs.getDate("date_escalate")));
					}					
					responsibles.addElement(res);
				}
				h.put("responsibles", responsibles);	
			}			
			
			return h;
		} finally {
			if ( db != null ) db.close();
		}
	}
	

	
	static void rdata(SQLRenderer r) throws Exception {
		r.add("enquiry_id");
		r.add("name");
		r.add("gender");
		r.add("birth_date");
		r.add("address1");
		r.add("address2");
		r.add("state");
		r.add("city");
		r.add("poscode");
		r.add("country_code");
		r.add("phone_home");
		r.add("phone_mobile");
		r.add("email");
		r.add("academic_qualification");
		//
		r.add("academic_year");
		r.add("academic_grade");
		r.add("enquiry_body");
		//
		r.add("date_post");
		r.add("date_opened");
		r.add("date_closed");
		//			
		r.add("status");
		r.add("category_id");	
		r.add("comment");	
	}
	
	
	static Hashtable getResultSetData(ResultSet rs) throws Exception {
		Hashtable h = new Hashtable();
		h.put("enquiry_id", rs.getString("enquiry_id"));
		h.put("name", rs.getString("name"));
		h.put("gender", rs.getString("gender"));
		h.put("birth_date", rs.getString("birth_date"));		
		h.put("address1", rs.getString("address1"));
		h.put("address2", rs.getString("address2"));
		h.put("state", rs.getString("state"));
		h.put("city", rs.getString("city"));
		h.put("poscode", rs.getString("poscode"));
		h.put("country", rs.getString("country_code"));
		h.put("phone_home", rs.getString("phone_home"));
		h.put("phone_mobile", rs.getString("phone_mobile"));
		h.put("email", rs.getString("email"));
		h.put("academic_qualification", rs.getString("academic_qualification"));
		h.put("academic_year", rs.getString("academic_year"));
		h.put("academic_grade", rs.getString("academic_grade"));
		h.put("enquiry_body", rs.getString("enquiry_body"));
		h.put("date_post", rs.getString("date_post"));
		
		java.util.Date birthDate = rs.getDate("birth_date");
		Calendar c = new java.util.GregorianCalendar();		
		
		int year = 0, month = 0, day = 0;
		if ( birthDate != null ) {

			c.setTime(birthDate);	
			year = c.get(Calendar.YEAR);
			month = c.get(Calendar.MONTH) + 1;
			day = c.get(Calendar.DAY_OF_MONTH);		
			
			h.put("birth_year", new Integer(year));
			h.put("birth_month", new Integer(month));
			h.put("birth_day", new Integer(day));
			
			h.put("birth_date_display", 
				new java.text.SimpleDateFormat ("d MMM, yyyy").format(rs.getDate("birth_date")));
		} else {
			h.put("birth_year", new Integer(0));
			h.put("birth_month", new Integer(0));
			h.put("birth_day", new Integer(0));
			
			h.put("birth_date_display", "");
		}
		
		java.util.Date postDate = rs.getDate("date_post");
		if ( postDate != null ) {
			c.setTime(postDate);	
			year = c.get(Calendar.YEAR);
			month = c.get(Calendar.MONTH) + 1;
			day = c.get(Calendar.DAY_OF_MONTH);		
			h.put("post_year", new Integer(year));
			h.put("post_month", new Integer(month));
			h.put("post_day", new Integer(day));
			h.put("post_date_display", new java.text.SimpleDateFormat ("d MMM, yyyy").format(rs.getDate("date_post")));
		}
			
		java.util.Date openedDate = rs.getDate("date_opened");
		if ( openedDate != null ) {
			c.setTime(openedDate);	
			year = c.get(Calendar.YEAR);
			month = c.get(Calendar.MONTH) + 1;
			day = c.get(Calendar.DAY_OF_MONTH);		
			h.put("opened_year", new Integer(year));
			h.put("opened_month", new Integer(month));
			h.put("opened_day", new Integer(day));
			h.put("opened_date_display", new java.text.SimpleDateFormat ("d MMM, yyyy").format(rs.getDate("date_opened")));
		}
		
		java.util.Date closedDate = rs.getDate("date_closed");
		if ( closedDate != null ) {
			c.setTime(closedDate);	
			year = c.get(Calendar.YEAR);
			month = c.get(Calendar.MONTH) + 1;
			day = c.get(Calendar.DAY_OF_MONTH);		
			h.put("closed_year", new Integer(year));
			h.put("closed_month", new Integer(month));
			h.put("closed_day", new Integer(day));
			h.put("closed_date_display", new java.text.SimpleDateFormat ("d MMM, yyyy").format(rs.getDate("date_closed")));
		}
		

		h.put("status", Db.getString(rs, "status"));
		h.put("category_id", Db.getString(rs, "category_id"));
		h.put("comment", Db.getString(rs, "comment"));
				
		return h;
	}	
	
	
	static Vector getList() throws Exception {

		Db db = null;
		String sql= "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			rdata(r);
			
			sql = r.getSQLSelect("enquiry", "date_post DESC");
			
			//System.out.println(sql);
			
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h = getResultSetData(rs);
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	static Vector getList(String responsible_id) throws Exception {

		Db db = null;
		String sql= "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			rdata(r);
			
			r.add("e.enquiry_id", r.unquote("r.enquiry_id"));
			r.add("r.responsible_id", responsible_id);
			
			sql = r.getSQLSelect("enquiry e, hd_escalation r", "date_post DESC");
			
			//System.out.println(sql);
			
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h = getResultSetData(rs);
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	static Vector getList(String dateFrom, String dateTo) throws Exception {

		Db db = null;
		String sql= "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			rdata(r);
			
			sql = r.getSQLSelect("enquiry e, hd_escalation r", "date_post DESC");
			
			//System.out.println(sql);
			
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h = getResultSetData(rs);
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	
	static Integer getInteger(ResultSet rs, String name) throws Exception {
		String s = rs.getString(name);
		if ( s != null ) return new Integer(s);
		else return new Integer(0);	
	}
	
	static Vector getEnquiryStatus() throws Exception { 
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			Vector v = new Vector();
			SQLRenderer r = new SQLRenderer();
			
			r.add("status_id");
			r.add("status_name");
			r.add("status_description");
			sql = r.getSQLSelect("enquiry_status", "status_name");
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next()) {
				Hashtable h = new Hashtable();
				h.put("id", Db.getString(rs, "status_id"));
				h.put("name", Db.getString(rs, "status_name"));
				h.put("description", Db.getString(rs, "status_description"));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}
	

	
	static void setEnquiryStatus(String id, String status) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.update("enquiry_id", id);
			r.add("status", status);
			sql = r.getSQLUpdate("enquiry");
			stmt.executeUpdate(sql);
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	static void addNewStatus(String id, String name, String description, String enquiry_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			boolean found = false;
			{
				sql = "select status_id from enquiry_status where status_id = '" + id + "'";
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next()) found = true;
			}	
			if ( !found ) {
				{
					r.clear();
					r.add("status_id", id);
					r.add("status_name", name);
					r.add("status_description", description);
					sql = r.getSQLInsert("enquiry_status");
					stmt.executeUpdate(sql);	
				}	
				{
					r.clear();
					r.add("status", id);
					r.update("enquiry_id", enquiry_id);
					sql = r.getSQLUpdate("enquiry");
					stmt.executeUpdate(sql);
				}
			}
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	static Vector getCategoryList() throws Exception { 
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			Vector v = new Vector();
			SQLRenderer r = new SQLRenderer();
			
			r.add("category_id");
			r.add("category_name");
			r.add("category_description");
			sql = r.getSQLSelect("hd_categories", "category_name");
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next()) {
				Hashtable h = new Hashtable();
				h.put("id", Db.getString(rs, "category_id"));
				h.put("name", Db.getString(rs, "category_name"));
				h.put("description", Db.getString(rs, "category_description"));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	static void addNewCategory(String name, String description, String enquiry_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			String uid = Long.toString(UniqueID.get());
			{
				r.clear();
				r.add("category_id", uid);
				r.add("category_name", name);
				r.add("category_description", description);
				sql = r.getSQLInsert("hd_categories");
				stmt.executeUpdate(sql);	
			}	
			{
				r.clear();
				r.add("category_id", uid);
				r.update("enquiry_id", enquiry_id);
				sql = r.getSQLUpdate("enquiry");
				stmt.executeUpdate(sql);
			}

		} finally {
			if ( db != null ) db.close();
		}
	}
	
	static void setEnquiryCategory(String id, String category) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.update("enquiry_id", id);
			r.add("category_id", category);
			sql = r.getSQLUpdate("enquiry");
			stmt.executeUpdate(sql);
			
		} finally {
			if ( db != null ) db.close();
		}
	}				
	
	static void update(String id, String status, String category, String comment) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.update("enquiry_id", id);
			r.add("status", status);
			r.add("category_id", category);
			r.add("comment", comment);
			sql = r.getSQLUpdate("enquiry");
			
			stmt.executeUpdate(sql);
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void update(Hashtable h) throws Exception {
		Db db = null;
		String sql= "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			String enquiry_id = (String) h.get("enquiry_id");
			r.update("enquiry_id", enquiry_id);
			r.add("name", (String) h.get("name"));
			r.add("address1", (String) h.get("address1"));
			r.add("address2", (String) h.get("address2"));
			r.add("state", (String) h.get("state"));
			r.add("city", (String) h.get("city"));
			r.add("poscode", (String) h.get("poscode"));
			r.add("country_code", (String) h.get("country"));
			r.add("phone_home", (String) h.get("phone_home"));
			r.add("phone_mobile", (String) h.get("phone_mobile"));
			r.add("email", (String) h.get("email"));
			r.add("enquiry_body", (String) h.get("enquiry_body"));
			r.add("status", (String) h.get("status"));
			r.add("category_id", (String) h.get("category"));
			r.add("comment", (String) h.get("comment"));			
			
			sql = r.getSQLUpdate("enquiry");
			stmt.executeUpdate(sql);
			
			
		} catch ( SQLException sqlex ) {
			throw new Exception(sqlex.getMessage() + "-" + sql);
		} finally {
			if ( db != null ) db.close();
		}
	}			
	
	static void addEscalate(String enquiry_id, String[] responsibles) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			Calendar c = new java.util.GregorianCalendar();		
			c.setTime(new java.util.Date());	
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH) + 1;
			int day = c.get(Calendar.DAY_OF_MONTH);				
			String date_escalate = year + "-" + fmt(month) + "-" + fmt(day);
			
			for ( int i=0; i < responsibles.length; i++ ) {
				boolean found = false;
				{
					r.clear();	
					r.add("enquiry_id");
					r.add("enquiry_id", enquiry_id);
					r.add("responsible_id", responsibles[i]);
					sql = r.getSQLSelect("hd_escalation");
					ResultSet rs = stmt.executeQuery(sql);
					if ( rs.next() ) found = true;					
				}
				
				if ( !found ) {
					r.clear();
					r.add("enquiry_id", enquiry_id);
					r.add("responsible_id", responsibles[i]);
					r.add("date_escalate", date_escalate);
					sql = r.getSQLInsert("hd_escalation");
					stmt.executeUpdate(sql);
				}
			}
			
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	static void removeEscalate(String enquiry_id, String[] responsibles) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			for ( int i=0; i < responsibles.length; i++ ) {
				r.clear();
				r.add("enquiry_id", enquiry_id);
				r.add("responsible_id", responsibles[i]);
				sql = r.getSQLDelete("hd_escalation");
				stmt.executeUpdate(sql);
			}
			
		} finally {
			if ( db != null ) db.close();
		}	
	}	
	
	public static Vector getResponsibleList(String enquiry_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			resdata(r, enquiry_id);
			sql = r.getSQLSelect("hd_escalation e, hd_responsibles r, users u");
			
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				v.addElement(getResponsibleData(rs));
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}		
	}
	
	static void resdata(SQLRenderer r, String enquiry_id) {
		resdata(r, enquiry_id, "");
	}
	
	static void resdata(SQLRenderer r, String enquiry_id, String responsible_id) {
		r.add("res_id");
		r.add("res_email");
		r.add("res_phone_office");
		r.add("res_phone_mobile");
		r.add("res_phone_home");
		r.add("user_name");
		r.add("reply_text");
		r.add("r.res_id", r.unquote("u.user_login"));
		r.add("r.res_id", r.unquote("e.responsible_id"));
		r.add("e.enquiry_id", enquiry_id);
		if ( !"".equals(responsible_id) ) {
			r.add("res_id", responsible_id);
		}
	}	
	
	static ResponsibleInfo getResponsibleData(ResultSet rs) throws Exception {
		ResponsibleInfo r = new ResponsibleInfo();
		r.id = Db.getString(rs, "res_id");
		r.email = Db.getString(rs, "res_email");
		r.telOffice = Db.getString(rs, "res_phone_office");
		r.telHome = Db.getString(rs, "res_phone_home");
		r.telMobile = Db.getString(rs, "res_phone_mobile");
		r.name = Db.getString(rs, "user_name");
		r.replyText = Db.getString(rs, "reply_text");
		return r;
	}
	
	public static ResponsibleInfo getResponsibleReply(String enquiry_id, String responsible_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			resdata(r, enquiry_id, responsible_id);
			sql = r.getSQLSelect("hd_escalation e, hd_responsibles r, users u");
			
			ResultSet rs = stmt.executeQuery(sql);
			ResponsibleInfo info = new ResponsibleInfo();
			if ( rs.next() ) {
				info = getResponsibleData(rs);
			}
			return info;
		} finally {
			if ( db != null ) db.close();
		}		
	}	
	
	static void addReply(String enquiry_id, String responsible_id, String reply) throws Exception {
		Db db = null;		
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			boolean found = false;
			{
				r.add("enquiry_id");
				r.add("enquiry_id", enquiry_id);
				r.add("responsible_id", responsible_id);
				sql = r.getSQLSelect("hd_escalation");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) found = true;
			}
			
			if ( !found ) {
				r.clear();
				r.add("enquiry_id", enquiry_id);
				r.add("responsible_id", responsible_id);
				r.add("reply_text", reply);
				r.add("date_reply", dateString());
				sql = r.getSQLInsert("hd_escalation");
				stmt.executeUpdate(sql);
			}
			else {
				r.clear();
				r.update("enquiry_id", enquiry_id);
				r.update("responsible_id", responsible_id);
				r.add("reply_text", reply);
				r.add("date_reply", dateString());
				sql = r.getSQLUpdate("hd_escalation");
				stmt.executeUpdate(sql);				
			}
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	static void delete(String enquiry_id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("enquiry_id", enquiry_id);
			sql = r.getSQLDelete("hd_escalation");
			stmt.executeUpdate(sql);
			sql = r.getSQLDelete("enquiry");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}
			
	}
	

	
}