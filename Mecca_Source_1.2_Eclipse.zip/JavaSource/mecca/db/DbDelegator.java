/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.db;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 *
 *

 */
public class DbDelegator {
    
	public Vector select(String entityName, Vector data, Hashtable whereData) throws Exception {
		Db db = null;
		try {
			db = new Db();
			SQLPStmtRenderer r = new SQLPStmtRenderer();
			for ( int i = 0; i < data.size(); i++ ) r.add( (String) data.elementAt(i) );
			if ( whereData != null ) {
				String key = "";
				for ( Enumeration e = whereData.keys(); e.hasMoreElements(); ) {
					key = (String) e.nextElement();
					r.add( key, whereData.get(key) );
				}
			}
			PreparedStatement pstmt = r.getPStmtSelect(db.getConnection(), entityName);
			Vector results = new Vector();
			String fieldName = "";
			ResultSet rs = pstmt.executeQuery();
			while ( rs.next() ) {
				Hashtable hashTable = new Hashtable(); 
				for ( int i = 0; i < data.size(); i++ ) {
					fieldName = (String) data.elementAt(i);
					hashTable.put(fieldName, rs.getString(fieldName));
				}
				results.addElement(hashTable);
			}
			return results;
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	public Vector selectDistinct(String entityName, Vector data, Hashtable whereData, String orderBy) throws Exception {
		Db db = null;
		try {
			db = new Db();
			SQLPStmtRenderer r = new SQLPStmtRenderer();
			for ( int i = 0; i < data.size(); i++ ) r.add( (String) data.elementAt(i) );
			if ( whereData != null ) {
				String key = "";
				for ( Enumeration e = whereData.keys(); e.hasMoreElements(); ) {
					key = (String) e.nextElement();
					r.add( key, whereData.get(key) );
				}
			}
			PreparedStatement pstmt = r.getPStmtSelectDistinct(db.getConnection(), entityName, orderBy);
			Vector results = new Vector();
			String fieldName = "";
			ResultSet rs = pstmt.executeQuery();
			while ( rs.next() ) {
				Hashtable hashTable = new Hashtable(); 
				for ( int i = 0; i < data.size(); i++ ) {
					fieldName = (String) data.elementAt(i);
					hashTable.put(fieldName, rs.getString(fieldName));
				}
				results.addElement(hashTable);
			}
			return results;
		} finally {
			if ( db != null ) db.close();
		}	
	}		
	
	
	
	public void insert(String entityName, Hashtable data) throws Exception {
		Db db = null;
		try {
			db = new Db();
			SQLPStmtRenderer r = new SQLPStmtRenderer();
			String key = "";
			for ( Enumeration e = data.keys(); e.hasMoreElements(); ) {
			    key = (String) e.nextElement();
			    r.add(key, data.get(key));
			}
			PreparedStatement pstmt = r.getPStmtInsert(db.getConnection(), entityName);
			pstmt.executeUpdate();
		} finally {
			if ( db != null ) db.close();
		}	
		
	}
	
	

	public void update(String entityName, Hashtable updateData, Hashtable whereData) throws Exception {
		Db db = null;
		try {
			db = new Db();
			SQLPStmtRenderer r = new SQLPStmtRenderer();
			String key = "";
			for ( Enumeration e = updateData.keys(); e.hasMoreElements(); ) {
			    key = (String) e.nextElement();
			    r.add(key, updateData.get(key));
			}
			for ( Enumeration e = whereData.keys(); e.hasMoreElements(); ) {
			    key = (String) e.nextElement();
			    r.update(key, whereData.get(key));
			}
			PreparedStatement pstmt = r.getPStmtUpdate(db.getConnection(), entityName);
			pstmt.executeUpdate();			
			
		} finally {
			if ( db != null ) db.close();
		}	
		
	}	
	

	public void delete(String entityName, Hashtable data) throws Exception {
		Db db = null;
		try {
			db = new Db();
			SQLPStmtRenderer r = new SQLPStmtRenderer();
			String key = "";
			for ( Enumeration e = data.keys(); e.hasMoreElements(); ) {
			    key = (String) e.nextElement();
			    r.add(key, data.get(key));
			}
			PreparedStatement pstmt = r.getPStmtDelete(db.getConnection(), entityName);
			pstmt.executeUpdate();
		} finally {
			if ( db != null ) db.close();
		}	
		
	}			

	
}	
