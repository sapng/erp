/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.db;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ConnectionProperties
{

    private static ConnectionProperties instance;
    private ResourceBundle rb;
    private String driver;
    private String url;
    private String user;
    private String password;
    private String lookupName;
    private String dbserver;
    private boolean useLookup;

    private ConnectionProperties(String resource)
        throws MissingResourceException
    {
        rb = ResourceBundle.getBundle(resource);
        read();
    }    
    

    public static synchronized ConnectionProperties getInstance(String resource)
    {
	    if ( "".equals(resource) ) resource = "dbconnection";
        if(instance == null)
            try
            {
                instance = new ConnectionProperties(resource);
            }
            catch(MissingResourceException missingresourceexception)
            {
                instance = null;
            }
           
        
        return instance;
    }
    
    public static ConnectionProperties getInstance() {
			return getInstance("");
    }

    public String getLookup()
    {
        return lookupName;
    }

    public String getDriver()
    {
        return driver;
    }

    public String getUrl()
    {
        return url;
    }

    public String getUser()
    {
        return user;
    }

    public String getPassword()
    {
        return password;
    }

    public String getDbserver()
    {
        return dbserver;
    }

    public boolean isUseLookup()
    {
        return useLookup;
    }

    
	public void read() {
		useLookup = true;
		readLookup();
		if ( (lookupName == null) || (lookupName.equals("")) ) {
			useLookup = false;
			readDriver();
			readUrl();
			readUser();
			readPassword();
		}
	} 
	
	private void readLookup() {
		try {
			lookupName = rb.getString("lookupname");
		} 
		catch ( MissingResourceException ex ) 
		{ 
			//Log.print(ex.getMessage()); 
		}
	}	   

    private void readDriver()
    {
        try
        {
            driver = rb.getString("driver");
        }
        catch(MissingResourceException missingresourceexception)
        {
            //Log.print(missingresourceexception.getMessage());
        }
    }

    private void readUrl()
    {
        try
        {
            url = rb.getString("url");
        }
        catch(MissingResourceException missingresourceexception)
        {
            //Log.print(missingresourceexception.getMessage());
        }
    }

    private void readUser()
    { 
        try
        {
            user = rb.getString("user");
        }
        catch(MissingResourceException missingresourceexception)
        {
            //Log.print(missingresourceexception.getMessage());
        }
    }

    private void readPassword()
    {
        try
        {
            password = rb.getString("password");
        }
        catch(MissingResourceException missingresourceexception)
        {
            //Log.print(missingresourceexception.getMessage());
        }
    }
}