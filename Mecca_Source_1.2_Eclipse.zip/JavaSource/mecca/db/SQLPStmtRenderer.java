/*
 * Created on Apr 20, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package mecca.db;

import java.util.Vector;

import java.sql.PreparedStatement;
import java.sql.Connection;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class SQLPStmtRenderer extends SQLRenderer {
    
	public PreparedStatement getPStmtSelect(Connection conn, String table) throws Exception {
		return getPStmtSelect(conn, table, "");
	}
	
	public PreparedStatement getPStmtSelectDistinct(Connection conn, String table, String orderby)  throws Exception{
		return getPStmtSelect(conn, table, orderby, "distinct");
	}
	
	public PreparedStatement getPStmtSelect(Connection conn, String table, String orderby)  throws Exception {
		return getPStmtSelect(conn, table, orderby, "");
	}    

	public PreparedStatement getPStmtSelect(Connection conn, String table, String orderby, String option) throws Exception {
	    PreparedStatement pstmt = null;
		boolean inGroup = false;
		Vector v1 = new Vector(), v2 = new Vector();
		for ( int i=0; i < v.size(); i++ ) {
			SQLRenderer.Item item = (SQLRenderer.Item) v.elementAt(i);
			if ( item.column.equals("(") || item.column.equals(")")) {
			    v2.add(item);
			} else if ( item.data == null ){
			    v1.add(item);
			} else {
			    v2.add(item);
			}
		}
		
		String sql = "SELECT ";
		if ( "distinct".equals(option) ) sql += " DISTINCT ";
		for ( int i=0; i < v1.size(); i++ ) {
			SQLRenderer.Item item = (SQLRenderer.Item) v1.elementAt(i);
			sql += item.column + ((i < v1.size() - 1) ? ", ": " ");
		}
		sql += " FROM " + table;
		boolean afterBracket = false;
		
		if ( v2.size() > 0 ) {
			sql += " WHERE ";
			for ( int i=0; i < v2.size(); i++ ) {
				SQLRenderer.Item item = (SQLRenderer.Item) v2.elementAt(i);
				if ( i > 0) {
					if ( item.column.equals(")")) {
					    sql += ") AND ";
					    afterBracket = true;
					} else if ( !afterBracket ) {
					    sql += " AND ";
					}
				}
				if ( item.column.equals("(")) {
				    sql += " (";
				    afterBracket = true;
				} else if (!item.column.equals(")")) {
					if ( item.data instanceof String ) sql += item.column + " " + item.operator + " ? ";
					else if ( item.data instanceof Integer ) sql += item.column + " " + item.operator + " ? ";
					else if ( item.data instanceof Boolean ) sql += item.column + " " + item.operator + " ? ";
					else if ( item.data instanceof Float ) sql += item.column  + " " + item.operator + " ? ";
					else if ( item.data instanceof Unquote ) sql += item.column + " " + item.operator + " " + (Unquote) item.data + " ";
					afterBracket = false;
				}
			}
		}
			
			
		if ( !"".equals(orderby) ) {
			sql += " ORDER BY " + orderby;
		}
		
		pstmt = conn.prepareStatement(sql);

		if ( v2.size() > 0 ) {
			for ( int i=0; i < v2.size(); i++ ) {
				SQLRenderer.Item item = (SQLRenderer.Item) v2.elementAt(i);
				if (!item.column.equals(")") ||  !item.column.equals("(")) {
					if ( item.data instanceof String ) 
					    pstmt.setString(i+1, (String) item.data);
					else if ( item.data instanceof Integer ) 
					    pstmt.setInt(i+1, ((Integer) item.data).intValue());
					else if ( item.data instanceof Boolean )
					    pstmt.setBoolean(i+1, ((Boolean) item.data).booleanValue());
					else if ( item.data instanceof Float ) 
					    pstmt.setFloat(i+1, ((Float) item.data).floatValue());
				}
			}
		}
		
		return pstmt;
	
	}
	
	public PreparedStatement getPStmtUpdate(Connection conn, String table) throws Exception {
	    PreparedStatement pstmt = null;
		String sql = " UPDATE " + table;
		if ( v.size() > 0 ) {
			sql += " SET ";
			for ( int i=0; i < v.size(); i++ ) {
				SQLRenderer.Item item = (SQLRenderer.Item) v.elementAt(i);
				if ( item.data instanceof Unquote ) sql += item.column + " = " + (Unquote) item.data + " ";
				else sql += item.column + " = ? ";
				sql += (i < v.size() - 1) ? ", ": " ";
			}				
		}
		//vwhere IS A MUST!
		if ( vwhere.size() > 0 ) {
			sql += " WHERE ";
			for ( int i=0; i < vwhere.size(); i++ ) {
				SQLRenderer.Item item = (SQLRenderer.Item) vwhere.elementAt(i);
				if ( item.data instanceof Unquote ) sql += item.column + " = " + (Unquote) item.data + " ";
				else sql += item.column + " = ? ";
				sql += (i < vwhere.size() - 1) ? " AND ": " ";
			}				
		} else {
			sql = "STATEMENT FOR UPDATE WAS DENIED";
		}
		pstmt = conn.prepareStatement(sql);
		int cnt = 0;
		for ( int i=0; i < v.size(); i++ ) {
			SQLRenderer.Item item = (SQLRenderer.Item) v.elementAt(i);
			if (!item.column.equals(")") ||  !item.column.equals("(")) {
				if ( item.data instanceof String ) 
				    pstmt.setString(++cnt, (String) item.data);
				else if ( item.data instanceof Integer ) 
				    pstmt.setInt(++cnt, ((Integer) item.data).intValue());
				else if ( item.data instanceof Boolean )
				    pstmt.setBoolean(++cnt, ((Boolean) item.data).booleanValue());
				else if ( item.data instanceof Float ) 
				    pstmt.setFloat(++cnt, ((Float) item.data).floatValue());
			}
		}
		for ( int i=0; i < vwhere.size(); i++ ) {
			SQLRenderer.Item item = (SQLRenderer.Item) vwhere.elementAt(i);
			if (!item.column.equals(")") ||  !item.column.equals("(")) {
				if ( item.data instanceof String ) 
				    pstmt.setString(++cnt, (String) item.data);
				else if ( item.data instanceof Integer ) 
				    pstmt.setInt(++cnt, ((Integer) item.data).intValue());
				else if ( item.data instanceof Boolean )
				    pstmt.setBoolean(++cnt, ((Boolean) item.data).booleanValue());
				else if ( item.data instanceof Float ) 
				    pstmt.setFloat(++cnt, ((Float) item.data).floatValue());
			}
		}			
		return pstmt;
	}
	
	public PreparedStatement getPStmtInsert(Connection conn, String table) throws Exception {
	    PreparedStatement pstmt = null;
		String sql = "INSERT INTO " + table + " (";
		for ( int i=0; i < v.size(); i++ ) {
			SQLRenderer.Item item = (SQLRenderer.Item) v.elementAt(i);
			sql += item.column + ((i < v.size() - 1) ? ", ": ") ");
		}
		sql += " VALUES (";
		for ( int i=0; i < v.size(); i++ ) {
			SQLRenderer.Item item = (SQLRenderer.Item) v.elementAt(i);
			if ( item.data instanceof Unquote ) sql += " " + (Unquote) item.data + " ";
			else sql += " ? ";
			sql += (i < v.size() - 1) ? ", ": ") ";
		}
		pstmt = conn.prepareStatement(sql);
		int cnt = 0;
		for ( int i=0; i < v.size(); i++ ) {
			SQLRenderer.Item item = (SQLRenderer.Item) v.elementAt(i);
			if ( item.data instanceof String ) 
			    pstmt.setString(++cnt, (String) item.data);
			else if ( item.data instanceof Integer ) 
			    pstmt.setInt(++cnt, ((Integer) item.data).intValue());
			else if ( item.data instanceof Boolean )
			    pstmt.setBoolean(++cnt, ((Boolean) item.data).booleanValue());
			else if ( item.data instanceof Float ) 
			    pstmt.setFloat(++cnt, ((Float) item.data).floatValue());
		}
		return pstmt;
	}
	
	public PreparedStatement getPStmtDelete(Connection conn, String table) throws Exception {
	    PreparedStatement pstmt = null;
		String sql = "DELETE FROM " + table;
		if ( v.size() > 0 ) {
			sql += " WHERE ";
			for ( int i=0; i < v.size(); i++ ) {
				SQLRenderer.Item item = (SQLRenderer.Item) v.elementAt(i);
				if ( item.data instanceof Unquote ) sql += item.column + " = " + (Unquote) item.data + " ";
				else sql += item.column + " = ? ";
				sql += (i < v.size() - 1) ? " AND ": " ";
			}	
			pstmt = conn.prepareStatement(sql);
			int cnt = 0;
			for ( int i=0; i < v.size(); i++ ) {
				SQLRenderer.Item item = (SQLRenderer.Item) v.elementAt(i);
				if ( item.data instanceof String ) 
				    pstmt.setString(++cnt, (String) item.data);
				else if ( item.data instanceof Integer ) 
				    pstmt.setInt(++cnt, ((Integer) item.data).intValue());
				else if ( item.data instanceof Boolean )
				    pstmt.setBoolean(++cnt, ((Boolean) item.data).booleanValue());
				else if ( item.data instanceof Float ) 
				    pstmt.setFloat(++cnt, ((Float) item.data).floatValue());
			}			
			return pstmt;			
		} else {
			throw new Exception("Delete table ignored due to empty filters..");	
		} 
	}	
	
}
