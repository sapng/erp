/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ConnectionSource
{ 

    private static ConnectionSource instance;
    private String driver;
    private String url;
    private String userid;
    private String password;
    private String lookupName;

    private ConnectionSource(String s, String s1, String s2, String s3)
    { 
        driver = s;
        url = s1;
        userid = s2;
        password = s3;
        lookupName = "";
    }

    private ConnectionSource(String s, String s1)
    {
        this(s, s1, "", "");
    }
    
	private ConnectionSource(String lookupName) {
		this.lookupName = lookupName; 
	}    

    private Connection newConnection()
        throws DbException
    {
        Connection connection = null;
        try
        {
			if ( lookupName.equals("") ) {
            	Class.forName(driver).newInstance();
            	if ( (userid.equals("")) && (password.equals("")) )
            		connection = DriverManager.getConnection(url);
            	else
            		connection = DriverManager.getConnection(url, userid, password);
			} else {
				
				InitialContext initCtx = new InitialContext();
				Context envCtx = (Context) initCtx.lookup("java:comp/env");
				DataSource datasource = (DataSource) envCtx.lookup(lookupName);
				connection = datasource.getConnection();				
			}
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw new DbException("ConnectionSource - ClassNotFoundException : " + classnotfoundexception.getMessage());
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new DbException("ConnectionSource - IllegalAccessException:  - " + illegalaccessexception.getMessage());
        }
        catch(InstantiationException instantiationexception)
        {
            throw new DbException("ConnectionSource - InstantiationException:  - " + instantiationexception.getMessage());
		} 
		catch(javax.naming.NamingException nex) 
		{
			throw new DbException ("ConnectionSource - NamingException :" + lookupName + " - " + nex.getMessage());
		}
        catch(SQLException sqlexception)
        {
            throw new DbException("ConnectionSource -SQLException :  - " + sqlexception.getMessage());
        }
        return connection;
    }

    public static synchronized ConnectionSource getInstance(String s, String s1, String s2, String s3)
    {
       	if ( instance == null )
	    		instance = new ConnectionSource(s, s1, s2, s3);  
        return instance;
    }
    
    public static synchronized ConnectionSource getNewInstance(String s, String s1, String s2, String s3)
    {
        return new ConnectionSource(s, s1, s2, s3);  
    }    
    
    public static synchronized ConnectionSource getInstance(String lookupName)
    {
       	if ( instance == null )
	    		instance = new ConnectionSource(lookupName);  
        return instance;
    }    

    public synchronized Connection getConnection()
        throws DbException
    {
        return newConnection();
    }

    public synchronized static void close(Connection connection)
    {
        try
        {
            connection.close();
            //Log.print("Connection close :: " + connection.toString());
        }
        catch(SQLException sqlexception)
        {
            Log.print(sqlexception.getMessage());
        }
    }
}