/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.db;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class LoggerWindow extends JFrame implements ActionListener {
	
	public static LoggerWindow instance = null;
	JTextArea areaLog = new JTextArea();
	JButton clearButton = new JButton("Clear");
	long counter = 0;
	
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if ( src == clearButton ) {
			areaLog.setText("");	
		}	
	}
	
	private LoggerWindow() {
		super("Merak Portal Logger");	
		setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
		areaLog = new JTextArea();
		areaLog.setForeground(Color.green);
		areaLog.setBackground(Color.black);
		areaLog.setLineWrap(true);
		areaLog.setWrapStyleWord(true);
		JScrollPane scrollpane = new JScrollPane(areaLog);
		JScrollBar scrollbar = scrollpane.getVerticalScrollBar();
		ScrollAdjustmentListener adjListener = new ScrollAdjustmentListener(scrollbar);
		
		getContentPane().setLayout(new BorderLayout());
	
		clearButton.addActionListener(this);
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		buttonPanel.add(clearButton);
		
		getContentPane().add(scrollpane, BorderLayout.CENTER);	
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		setSize(500, 400);	    
	    setVisible(true);			
	}
	
	public static LoggerWindow getInstance() {
		if ( instance == null ) instance = new LoggerWindow();
		return instance;
	}	
	
	public void Log(String str) {
		if ( instance != null ) {
			areaLog.append("[".concat(Long.toString(++counter)).concat("]  ").concat(str).concat("\n"));
		}
	}
	
	
	class ScrollAdjustmentListener implements AdjustmentListener {
		JScrollBar aScrollBar;
		ScrollAdjustmentListener(JScrollBar s) {
			aScrollBar = s;
			aScrollBar.addAdjustmentListener(this);
		}
		public void adjustmentValueChanged(AdjustmentEvent e) {
			aScrollBar.setValue(aScrollBar.getMaximum());
		}
	}
		
}