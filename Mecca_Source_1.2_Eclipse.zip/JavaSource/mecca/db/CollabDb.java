/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.db;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class CollabDb extends mecca.db.Db {
	public CollabDb() throws DbException {
		super("dbconnection");	
	}	
	
	public String uid() {
		return Long.toString(mecca.db.UniqueID.get());	
	}
	
	//---
	protected String dblch(String txt, char ch){
		StringBuffer txtout = new StringBuffer("");
		if (txt != null) {
			char c;
			for (int i=0; i < txt.length(); i++) {
				c = txt.charAt(i);
				if ( c == ch) {
					txtout.append(ch).append(ch);
				}
				else {
					txtout.append(String.valueOf(c));
				}
			}
		} else {
			txtout.append("");
		}
		return txtout.toString();
	}

	protected String rep(String txt) {
		return dblch(txt, '\'');
	}
	
	public static String putLineBreak(String str) {
		StringBuffer txt = new StringBuffer(str);
		char c = '\n';
		while (txt.toString().indexOf(c) > -1) {
			int pos = txt.toString().indexOf(c);
			txt.replace(pos, pos + 1, "<br>");
		}
		return txt.toString();
	}	
}