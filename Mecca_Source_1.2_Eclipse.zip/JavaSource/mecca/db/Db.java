/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class Db
{

    protected Connection conn;
    protected Statement stmt;
    protected String sql;
    private String resource;
    
    /**
     * 
     * @throws DbException
     */
    
    public Db() throws DbException 
    {
		this("");   
    }    
    
    /**
     * A constructor to create a singleton ConnectonSource object.  This will
     * result a connection object with same value.
     * @param resource
     * @throws DbException
     */

    public Db(String resource) throws DbException
    {
        try
        {
            ConnectionProperties connectionproperties = ConnectionProperties.getInstance(resource);
            if(connectionproperties != null)
            {
                connectionproperties.read();
				if ( connectionproperties.isUseLookup() ) {
					String lookupName = connectionproperties.getLookup();
					conn = ConnectionSource.getInstance(lookupName).getConnection();
				}
				else
				{                
	                String s = connectionproperties.getDriver();
	                String s1 = connectionproperties.getUrl();
	                String s2 = connectionproperties.getUser();
	                String s3 = connectionproperties.getPassword();
	                
	                conn = ConnectionSource.getInstance(s, s1, s2, s3).getConnection();
                }
               
                stmt = conn.createStatement();
            } else
            {
                throw new DbException("Db : dbconnection.properties file error");
            }
        }
        catch(SQLException sqlexception)
        {
            throw new DbException("Db - SQLException : " + sqlexception.getMessage());
        }
    }
    
    /**
     * A constructor to create a new instance of ConnectionSource, thus shall
     * create a different connection values each time this constructor
     * is called.
     * The Hashtable argument consistes of driver, url, user, and password.
     * @param prop
     * @throws DbException
     */
    
    public Db(Hashtable prop) throws DbException
    {
        try
        {
	        if ( prop != null ) 
	        {
	            conn = ConnectionSource.getNewInstance((String) prop.get("driver"), 
					    (String) prop.get("url"), 
					    (String) prop.get("user"), 
					    (String) prop.get("password")).getConnection();
                stmt = conn.createStatement();
            } else
            {
                throw new DbException("Db : properties table is null");
            }
        }
        catch(SQLException sqlexception)
        {
            throw new DbException("Db - SQLException : " + sqlexception.getMessage());
        }
    }    
    


    public Connection getConnection()
    {
        return conn;
    }

    public String getSQL()
    {
        return sql;
    }

    public Statement getStatement()
    {
        return stmt;
    }

    public void close()
    {
        if(conn != null)
        {
            try
            {
                stmt.close();
            }
            catch(SQLException sqlexception) { }
            ConnectionSource.close(conn);
        }
    }

    protected String dblch(String s, char c)
    {
        StringBuffer stringbuffer = new StringBuffer("");
        if(s != null)
        {
            for(int i = 0; i < s.length(); i++)
            {
                char c1 = s.charAt(i);
                if(c1 == c)
                    stringbuffer.append(c).append(c);
                else
                    stringbuffer.append(String.valueOf(c1));
            }

        } else
        {
            stringbuffer.append("");
        }
        return stringbuffer.toString();
    }

    protected String replace(String s)
    {
        return dblch(s, '\'');
    }
    
    public static String getString(ResultSet rs, String name) throws Exception {
		//String data = rs.getString(name);
		//if ( data != null ) return data;
		//else return "";
        try {
        	String data = rs.getString(name);
    		if ( data != null ) return data;
        } catch (SQLException e ) {
            System.out.println("Date column throw Exception: " + e.getMessage());
        }
        return "";		
    }
    
    public static java.util.Date getDate(ResultSet rs, String name) throws Exception {
        try {
            return rs.getDate(name);
        } catch (SQLException e ) {
            //System.out.println("Date column throw Exception: " + e.getMessage());
        }
        return null;
    }    
}