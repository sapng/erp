/*
 * Created on Apr 20, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package mecca.db;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;

/**
 * @author Owner
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class TestPstmt {
	public static void main(String[] args) throws Exception {
		Db db = new Db();
		Connection conn = db.getConnection();
		SQLPStmtRenderer r = new SQLPStmtRenderer();
		r.add("name");
		r.add("id", "Q0001");
		PreparedStatement pstmt = r.getPStmtSelect(conn, "student");
		ResultSet rs = pstmt.executeQuery();
		while ( rs.next() ) {
		    String name = rs.getString("name");
		    System.out.println(name);
		}
	}	
}
