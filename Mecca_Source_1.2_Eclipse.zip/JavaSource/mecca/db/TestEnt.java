/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.db;

import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */

public class TestEnt extends mecca.portal.velocity.VTemplate {

	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		Template template = engine.getTemplate("vtl/testEnt.vm");	
		Vector data = new Vector();
		Hashtable whereData = new Hashtable();
		data.addElement("user_login");
		data.addElement("user_password");
		whereData.put("user_login", "admin");
		DbDelegator delegator = new DbDelegator();
		Vector results = delegator.select("users", data, null);
		context.put("results", results);
		/*
		for ( int i=0; i < results.size(); i++) {
			Hashtable h = (Hashtable) results.elementAt(i);
			String user_login = (String) h.get("user_login");
			String user_password = (String) h.get("user_password");
			System.out.println(user_login + " = " + user_password);
		}
		*/
		return template;		
	}		

}