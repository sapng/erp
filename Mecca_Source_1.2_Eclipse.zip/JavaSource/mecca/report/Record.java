/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.report;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class Record {
	private String id;
	private RecordHeader header;
	private List items;
	private int col;
	private int itemnum;
	private boolean moreItem;
	private List properties;
	public Record(RecordHeader h) {
		header = h;
		items = new ArrayList();
		properties = new ArrayList();
	}
	public void add(String data) {
		if (col < header.getCols()) {
			items.add(data);
			properties.add(new Property());
			col++;
			moreItem = true;
		}
	}
	public String next() {
		String data = "";
		if (itemnum < header.getCols()) {
			data = (String) items.get(itemnum);
			itemnum++;
			if (itemnum == header.getCols()) moreItem = false;
		}
		return data;
	}
	public boolean hasNext() {
		return moreItem;
	}
	public void setProperty(int i, Property prop) {
		properties.set(i, prop);
	}
	public Property getPropertyAt(int i) {
		return (Property) properties.get(i);
	}
	public void setId(String id) { this.id = id; }
	public String getId() { return this.id; }
	public RecordHeader getHeader() { return header; }
}