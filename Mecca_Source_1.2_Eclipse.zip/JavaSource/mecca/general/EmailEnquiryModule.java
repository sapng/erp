/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.general;

import mecca.portal.velocity.VTemplate;
import mecca.service.MailService;

import org.apache.velocity.Template;
/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class EmailEnquiryModule extends VTemplate
{

    public EmailEnquiryModule()
    {
    }

    public Template doTemplate()
        throws Exception
    {
        javax.servlet.http.HttpSession httpsession = super.request.getSession();
        String s = "vtl/email_enquiry.vm";
        String s1 = getParam("command");
        if("send".equals(s1))
        {
            s = "vtl/email_enquiry_send.vm";
            String s2 = getParam("name");
            String s3 = getParam("contactno");
            String s4 = getParam("addresss");
            String s5 = getParam("email");
            String s6 = getParam("subject");
            String s7 = getParam("sendto");
            String s8 = getParam("cc");
            String s9 = getParam("bcc");
            String s10 = getParam("comments");
            String s11 = getParam("host");
            String s12 = s2 + "\n" + s3 + "\n" + s4 + "\n\n\n" + s10 + "\n";
            MailService mailservice = new MailService();
            mailservice.setTo(s7);
            mailservice.setCc(s8);
            mailservice.setBcc(s9);
            mailservice.setFrom(s5);
            mailservice.setSubject(s6);
            mailservice.setBody(s12);
            mailservice.setHost(s11);
            mailservice.send();
        }
        Template template = super.engine.getTemplate(s);
        return template;
    }
}