/*
 * Created on Apr 8, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package mecca.general;

import mecca.portal.action.ActionTemplate;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.velocity.VelocityContext;

/**
 * @author Owner
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class EmailEnquiryInputFormAction implements ActionTemplate {

    public void doAction(HttpServletRequest req, HttpServletResponse res, VelocityContext context) throws Exception {
        
    }
}
