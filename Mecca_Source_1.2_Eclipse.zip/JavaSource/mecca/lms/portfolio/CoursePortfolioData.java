/* ************************************************************************
 * Copyright 2005 University ERP Project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.lms.portfolio;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;
import mecca.db.UniqueID;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.00
 */
public class CoursePortfolioData {

	
	public static CoursePortfolio getPortfolio(String subjectId) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("subject_id", subjectId);
			r.add("portfolio_text");
			sql = r.getSQLSelect("course_portfolio_text", "page_no");
			ResultSet rs = stmt.executeQuery(sql);
			CoursePortfolio p = new CoursePortfolio();
			p.setSubjectId(subjectId);
			int i = 0;
			while ( rs.next() ) {
				String txt = rs.getString(1);
				p.setText(i++, txt);
			}
			return p;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Hashtable getPageContent(String subjectId, int page) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("subject_id", subjectId);
			r.add("page_no", page);
			r.add("portfolio_text");
			r.add("page_id");
			sql = r.getSQLSelect("course_portfolio_text");
			ResultSet rs = stmt.executeQuery(sql);
			Hashtable h = new Hashtable();
			if ( rs.next() ) {
				h.put("text", rs.getString(1));
				h.put("id", rs.getString(2));
			}
			return h;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void addNewPage(String subjectId, String text) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			int pageno = 0;
			{
				r.add("MAX(page_no) no ");
				r.add("subject_id", subjectId);
				sql = r.getSQLSelect("course_portfolio_text");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) pageno = rs.getInt(1);
				pageno++;
			}
			{
				r.clear();
				r.add("subject_id", subjectId);
				r.add("portfolio_text", text);
				r.add("page_no", pageno);
				r.add("page_id", Long.toString(UniqueID.get()));
				sql = r.getSQLInsert("course_portfolio_text");
				stmt.executeUpdate(sql);
			}
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void movePage(String subjectId, int from, int to) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			{
				r.clear();
				r.update("subject_id", subjectId);
				r.update("page_no", from);
				r.add("page_no", -99);
				sql = r.getSQLUpdate("course_portfolio_text");
				//System.out.println(sql);
				stmt.executeUpdate(sql);
			}
			if ( from > to ) {
				{
					sql = "update course_portfolio_text " +
					"set page_no = page_no + 1 " +
					"where subject_id = '" + subjectId + "' " +
					"and page_no > " + Integer.toString(to - 1);
					//System.out.println(sql);
					stmt.executeUpdate(sql);
				}
	
				//reNumber(stmt, subjectId, to-1, to+1);
				{
					r.clear();
					r.update("subject_id", subjectId);
					r.update("page_no", -99);
					r.add("page_no", to);
					sql = r.getSQLUpdate("course_portfolio_text");
					//System.out.println(sql);
					stmt.executeUpdate(sql);
				}	
			}
			else if ( from < to ) {
				{
					sql = "update course_portfolio_text " +
					"set page_no = page_no - 1 " +
					"where subject_id = '" + subjectId + "' " +
					"and page_no > " + Integer.toString(from);
					//System.out.println(sql);
					stmt.executeUpdate(sql);
				}
				{
					r.clear();
					r.update("subject_id", subjectId);
					r.update("page_no", -99);
					r.add("page_no", to);
					sql = r.getSQLUpdate("course_portfolio_text");
					//System.out.println(sql);
					stmt.executeUpdate(sql);
				}
				
				
			}
			
			reNumber(stmt, subjectId, 0, 1);
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void reNumber(Statement stmt, String subjectId, int start, int num) throws Exception {
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		Vector v = new Vector();
		{
			r.clear();
			r.add("page_id");
			r.add("subject_id", subjectId);
			r.add("page_no", start, ">");
			sql = r.getSQLSelect("course_portfolio_text", "page_no");
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next() ) {
				v.addElement(rs.getString(1));
			}
		}
		for ( int i=0; i < v.size(); i++ ) {
			String id = (String) v.elementAt(i);
			sql = "update course_portfolio_text set page_no = " + num +
			" where page_id = '" + id + "'";
			stmt.executeUpdate(sql);
			num++; 
		}
	}
	
	public static void deletePage(String subjectId, int page) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			sql = "delete from course_portfolio_text where page_no = " + page + "" +
			"and subject_id = '" + subjectId + "'";;
			//System.out.println(sql);
			stmt.executeUpdate(sql);
			reNumber(stmt, subjectId, 0, 1);
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void updatePage(String page_id, String text) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.update("page_id", page_id);
			r.add("portfolio_text", text);
			sql = r.getSQLUpdate("course_portfolio_text");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void reNumber(String subjectId, int start, int num) throws Exception {
		Db db = null;
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			reNumber(stmt, subjectId, start, num);
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void main(String[] args) throws Exception {
		//movePage("lms_science_1123318693302",4, 3);
		reNumber("lms_science_1123318693302", 0, 1);
	}
	
}
