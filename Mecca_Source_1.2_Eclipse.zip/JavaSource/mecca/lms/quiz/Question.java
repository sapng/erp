/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lms.quiz;

import java.util.Vector;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */

public class Question {
    private String id;
    private String text;
    private int type;
    private Vector choices;
    private Object[] answers;
    private boolean userCorrect;
    public static final int SINGLE_CHOICE = 0; 
    private static final int MULTIPLE_CHOICE = 1;
    private static final int FILL_BLANK = 2;
    
    public Question() {
        choices = new Vector();
    }
    
    public void setId(String s) {
        id = s;
    }
    
    public void setText(String s) {
        text = s;
    }
    
    public void setType(int i) {
        type = i;
    }
    
    public void setChoices(Vector v) {
        choices = v;
    }
    
    
    public void setAnswers(String[] ans) {
    	answers = ans;
    }
    
    public String getId() {
        return id;
    }
    
    public String getText() {
        return text;
    }
    
    public Vector getChoices() {
        return choices;
    }
    
    
    /*
     * if type = 0 or 1 then return as Integer
     * else return as String
    */
    public Object[] getAnswers() {
        if ( answers == null ) return null;
    	Object[] obj = new Object[answers.length];
    	if ( type == 0 || type == 1 ) {
    		for ( int i=0; i < answers.length; i++ ) {
    			if ( answers[i] != null && !"".equals(answers[i]))
    				obj[i] = new Integer((String) answers[i]);
    			else
    				obj[i] = new Integer(0);
    		}
    	}
    	else {
    		obj = answers;
    	}
    	return obj;
    }
    
    public void addChoice(Choice choice) {
        choices.addElement(choice);
    }  
    
    
    public int getType() {
        return type;
    }
    
    public void setUserCorrect(boolean b) {
    	userCorrect = b;
    }
    
    public boolean getUserCorrect() {
    	return userCorrect;
    }
}
