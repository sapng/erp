/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lms.quiz;

import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.UniqueID;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class QuizModule extends mecca.portal.velocity.VTemplate implements mecca.portal.Attributable {

	protected String[] names = {"Moderators"};
	protected Hashtable values = new Hashtable();
	
	public String[] getNames() {
		return names;
	}
	
	public Hashtable getValues() {
		return values;
	}
	
	public void setValues(java.util.Hashtable hashtable) {
		values = hashtable;
	}	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		String template_name = "vtl/quiz/quiz.vm";
		String lessonId = getId();
		String moderators = values.get(names[0]) != null ? (String) values.get(names[0]) + "," : "";
		String _portal_role = (String) session.getAttribute("_portal_role");
		String inCollabModule = session.getAttribute("inCollabModule") != null ? 
						    	(String) session.getAttribute("inCollabModule") : "false";
		String collab_role = "true".equals(inCollabModule) ? session.getAttribute("_collab_role") != null ? 
								(String) session.getAttribute("_collab_role") : "" : "";
		String roleToAllow = !"".equals(collab_role) ? collab_role : _portal_role;
		if ( moderators.indexOf(roleToAllow + ",") == -1 ) {
			context.put("allowPost", new Boolean(false));		
			context.put("allowUpdate", new Boolean(false));
			context.put("allowDelete", new Boolean(false));
			context.put("isModerator", new Boolean(false));
		} else {
			context.put("allowPost", new Boolean(true));		
			context.put("allowUpdate", new Boolean(true));
			context.put("allowDelete", new Boolean(true));
			context.put("isModerator", new Boolean(true));
		}	
		String submit = getParam("command");
		if ( "createQuiz".equals(submit)) {
		    template_name = "vtl/quiz/create_quiz.vm";
		}
		else if ( "saveTitle".equals(submit)) {
		    saveTitle(session);
		    template_name = "vtl/quiz/questions.vm";
		}		
		else if ( "addNewQuiz".equals(submit)) {
		    createQuiz(session, lessonId);
		    template_name = "vtl/quiz/questions.vm";
		}
		else if ( "getQuiz".equals(submit) ) {
		    prepareQuiz(session);
		    template_name = "vtl/quiz/questions.vm";
		}
		else if ( "deleteQuiz".equals(submit)) {
		    deleteQuiz(session, lessonId);
		    template_name = "vtl/quiz/quiz.vm";
		}		
		else if ( "addQuestion".equals(submit) ) {
		    addQuestion(session);
		    template_name = "vtl/quiz/choices.vm";
		}
		else if ( "editQuestion".equals(submit) ) {
		    editQuestion(session);
		    String addMode = getParam("addMode");
		    if ( "yes".equals(addMode))
		    	template_name = "vtl/quiz/add_question.vm";
		    else
		    	template_name = "vtl/quiz/choices.vm";
		}	
		else if ( "deleteQuestion".equals(submit) ) {
		    deleteQuestion(session);
		    prepareQuiz(session);
		    String addMode = getParam("addMode");
		    if ( "yes".equals(addMode))
		    	template_name = "vtl/quiz/add_question.vm";
		    else	    
		    template_name = "vtl/quiz/questions.vm";
		}		
		else if ( "addChoice".equals(submit) ) {
		    addChoice(session);
		    template_name = "vtl/quiz/choices.vm";
		}
		else if ( "deleteChoice".equals(submit) ) {
		    deleteChoice(session);
		    template_name = "vtl/quiz/choices.vm";
		}		
		else if ( "updateChanges".equals(submit) ) {
		    updateChanges(session);
		    template_name = "vtl/quiz/choices.vm";
		}	
		else if ( "takeQuiz".equals(submit) ) {
		    takeQuiz(session);
		    template_name = "vtl/quiz/questions_take.vm";
		}	
		else if ( "submitAnswers".equals(submit) ) {
		    submitAnswers(session);
		    template_name = "vtl/quiz/submit_answers.vm";		    
		}
		else if ( "openAddQuestion".equals(submit) ) {
			template_name = "vtl/quiz/add_question.vm";
		}
		else {
		    prepareQuizList(session, lessonId);
		    template_name = "vtl/quiz/quiz.vm";
		}
		
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	void prepareQuizList(HttpSession session, String lessonId) throws Exception {
	    Vector quizes = getQuizes(session, lessonId);
	    context.put("quizes", quizes);	    
	}
	
	void prepareQuiz(HttpSession session) throws Exception {
	    String id = getParam("quizId");
	    Quiz quiz = QuizDb.getQuiz(id);
	    Vector questions = QuizDb.getQuestionList(id);
	    context.put("quizId", id);
	    context.put("questions", questions);	    
	    context.put("quiz", quiz);	    
	}
	
	void takeQuiz(HttpSession session) throws Exception {
	    String id = getParam("quizId");
	    Quiz quiz = QuizDb.getQuiz(id);
	    //Vector questions = QuizDb.getQuestionList(id, true);
	    Vector questions = quiz.getQuestions();
	    context.put("quizId", id);
	    context.put("questions", questions);	    
	    context.put("quiz", quiz);	    
	}	
	
	
	void createQuiz(HttpSession session, String lessonId) throws Exception {
	    String uniqueId = Long.toString(UniqueID.get());
	    String quizTitle = getParam("quizTitle");
	    Quiz quiz = new Quiz();
	    quiz.setId(uniqueId);
	    quiz.setTitle(quizTitle);
	    quiz.setLessonId(lessonId);
	    QuizDb.add(quiz);
	    context.put("quizId", id);
	    context.put("questions", new Vector());	    
	    context.put("quiz", quiz);
	}
	
	void deleteQuiz(HttpSession session, String lessonId) throws Exception {
	    String quizId = getParam("quizId");
	    QuizDb.deleteQuiz(quizId);
	    prepareQuizList(session, lessonId);	    
	}	
	
	Vector getQuizes(HttpSession session, String lessonId) throws Exception {
	    return QuizDb.getList(lessonId); 
	}
	
	void addQuestion(HttpSession session) throws Exception {
	    String quizId = getParam("quizId");
	    String questionText = getParam("questionText");
	    String questionType = getParam("questionType");
	    Question question = new Question();
	    question.setId(Long.toString(UniqueID.get()));
	    question.setText(questionText);
	    question.setType(Integer.parseInt(questionType));
	    QuizDb.addQuestion(quizId, question);
	    Vector questions = QuizDb.getQuestionList(quizId);
	    context.put("choices", new Vector());
	    context.put("quizId", quizId);
	    context.put("questions", questions);
	    context.put("question", question);
	    
	}
	
	void editQuestion(HttpSession session) throws Exception {
	    String questionId = getParam("questionId");
	    Question question = QuizDb.getQuestion(questionId);
	    Vector choices = question.getChoices();
	    context.put("question", question);
	    context.put("choices", choices);	    
	}	
	void deleteQuestion(HttpSession session) throws Exception {
	    String questionId = getParam("questionId");
	    QuizDb.deleteQuestion(questionId);
	}		
	void addChoice(HttpSession session) throws Exception {
	    String questionId = getParam("questionId");
	    String choiceText = getParam("choiceText");
	    String isCorrect = getParam("isCorrect");
	    Choice choice = new Choice();
	    choice.setId(Long.toString(UniqueID.get()));
	    choice.setText(choiceText);
	    choice.setCorrect("0".equals(isCorrect) ? false : true );
	    QuizDb.addChoice(questionId, choice);
	    Vector choices = QuizDb.getChoiceList(questionId);
	    context.put("choices", choices);
	    context.put("questionId", questionId);
	}
	
	void deleteChoice(HttpSession session) throws Exception {
	    String questionId = getParam("questionId");
	    String choiceId = getParam("choiceId");
	    QuizDb.deleteChoice(questionId, choiceId);
	    Vector choices = QuizDb.getChoiceList(questionId);
	    context.put("choices", choices);
	    context.put("questionId", questionId);
	}
	
	void updateChanges(HttpSession session) throws Exception {
	    String questionId = getParam("questionId");
	    String questionText = getParam("questionText");
	    int questionType = Integer.parseInt(getParam("questionType"));
	    String[] choiceIdList = request.getParameterValues("choiceIdList");
	    String[] choiceTextList = request.getParameterValues("choiceTextList");
	    
	    String[] isCorrectList = null;
	    if ( questionType < 2 ) {
	        isCorrectList = request.getParameterValues("isCorrectList");
	    }
	    Vector choices = new Vector();
	    for ( int i=0; i < choiceTextList.length; i++ ) {
	        Choice choice = new Choice();
	        choice.setId(choiceIdList[i]);
	        choice.setText(choiceTextList[i]);
	        if ( questionType < 2 ) {
	            choice.setCorrect("true".equals(isCorrectList[i]) ? true : false );
	        } else {
	            choice.setCorrect(true);
	        }
	        choices.addElement(choice);
	    }
	    Question question = new Question();
	    question.setId(questionId);
	    question.setText(questionText);
	    question.setType(questionType);
	    question.setChoices(choices);
	    QuizDb.updateQuestion(question);
	    context.put("question", question);
	    context.put("choices", question.getChoices());
	}
	
	void saveTitle(HttpSession session) throws Exception {
	    String quizId = getParam("quizId");
	    String quizTitle = getParam("quizTitle");
	    QuizDb.saveTitle(quizId, quizTitle);
	    prepareQuiz(session);
	}
	
	void submitAnswers(HttpSession session) throws Exception {
	    
	    String quizId = getParam("quizId");
	    Quiz quiz = QuizDb.getQuiz(quizId);
	    context.put("quiz", quiz);
	    //Vector questions = QuizDb.getQuestionList(quizId, true);
	    Vector questions = quiz.getQuestions();
	    context.put("questions", questions);
	    int numOfQuestion = questions.size();
	    int numOfCorrect = 0;
	    for ( int i = 0; i < questions.size(); i++ ) {
	        Question question = (Question) questions.elementAt(i);
	        Vector choices = question.getChoices();
	        Vector userAnswers = new Vector();
	        boolean answerIsCorrect = false;
	        if ( question.getType() == 1 ) { //MULTIPLE CHOICES
	            String[] answers = request.getParameterValues("choice_" + question.getId());
	            question.setAnswers(answers);
	            Vector ans = new Vector();
	            if ( answers != null ) {
		            for ( int k = 0; k < answers.length; k++ ) {
		                ans.addElement(new Integer(answers[k]));
		            }
	            }
	            Vector ans2 = new Vector();
	            int correctNum = 0;
	            for ( int num = 0; num < choices.size(); num++ ) {
	                Choice choice = (Choice) choices.elementAt(num);
	                if ( choice.getCorrect()) {
	                	correctNum = num + 1;
	                	ans2.addElement(new Integer(correctNum));
	                }
	            }
	            if ( ans.size() == ans2.size() ) {
	            	answerIsCorrect = true;
	            	for (int k = 0; k < ans.size(); k++ ) {
	            		int i1 = ((Integer) ans.elementAt(k)).intValue();
	            		int i2 = ((Integer) ans2.elementAt(k)).intValue();
	            		if ( i1 != i2 ) {
	            			answerIsCorrect = false;
	            			break;
	            		}
	            	}
	            } else {
	            	answerIsCorrect = false;
	            }
	        } else if ( question.getType() == 0 ) { //SINGLE CHOICE
	            String answer = getParam("choice_" + question.getId());
	            question.setAnswers(new String[] {answer});
	            int correctNum = 0;
	            for ( int num = 0; num < choices.size(); num++ ) {
	                Choice choice = (Choice) choices.elementAt(num);
	                if ( choice.getCorrect()) correctNum = num;
	            }
	            correctNum += 1;
	            if ( !"".equals(answer) && correctNum == Integer.parseInt(answer) ) {
	                answerIsCorrect = true;
	            }
	            else {
	                answerIsCorrect = false;
	            }
	        } else if ( question.getType() == 2 ) { //FILL IN THE BLANK
	            String[] answers = request.getParameterValues("choice_" + question.getId());
	            question.setAnswers(answers);
	            if ( answers != null ) {
		            for ( int k = 0; k < answers.length; k++ ) {
		                Choice choice = (Choice) choices.elementAt(k);
		                if ( answers[k].trim().equals(choice.getText().trim())) {
		                    answerIsCorrect = true;
		                } else {
		                	answerIsCorrect = false;
		                }
		            }
	            }	            
	        }
	        if ( answerIsCorrect ) numOfCorrect++;
	        question.setUserCorrect(answerIsCorrect);
	        //System.out.print("question = " + Integer.toString(i+1));	        
	        //System.out.println(" answer is " + answerIsCorrect);

	    }
	    quiz.setNumberOfCorrect(numOfCorrect);
	    //float userMarks =  ((float) numOfCorrect/(float) numOfQuestion);
	    //System.out.println(numOfCorrect + "/" + numOfQuestion + "= " + userMarks);
	    
	}
	
}