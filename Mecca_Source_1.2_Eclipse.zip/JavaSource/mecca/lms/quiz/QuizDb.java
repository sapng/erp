/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.lms.quiz;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;
import mecca.util.DateTool;



/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class QuizDb {
    
    public static void add(Quiz quiz) throws Exception {
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            String subjectId = getSubjectId(stmt, quiz.getLessonId());
            quiz.setSubjectId(subjectId);
            SQLRenderer r = new SQLRenderer();
            r.add("quiz_id", quiz.getId());
            r.add("quiz_title", quiz.getTitle());
            r.add("lesson_id", quiz.getLessonId());
            r.add("subject_id", quiz.getSubjectId());
            r.add("date_create", DateTool.getCurrentDate());
            sql = r.getSQLInsert("quiz_main");
            stmt.executeUpdate(sql);
        } finally {
            if ( db != null ) db.close();
        }
    }
    
    public static String getSubjectId(Statement stmt, String lessonId) throws Exception {
    	String sql = "select subject_id from lesson where lesson_id = '" + lessonId + "'";
    	ResultSet rs = stmt.executeQuery(sql);
    	if ( rs.next() ) return rs.getString(1);
    	else return "";
    }
    
    public static void deleteQuiz(String id) throws Exception {
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            boolean found = false;
            {
            	sql = "select question_id from quiz_question where quiz_id = '" + id + "'";
            	ResultSet rs = stmt.executeQuery(sql);
            	if ( rs.next() ) found = true;
            }
            if ( !found ) {
	            sql = "delete from quiz_main where quiz_id = '" + id + "'";
	            stmt.executeUpdate(sql);
            }
        } finally {
            if ( db != null ) db.close();
        }        
    }
    
    public static Quiz getQuiz(String id) throws Exception {
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            Quiz quiz = null;
            {
                r.add("quiz_id", id);
                r.add("quiz_title");
                sql = r.getSQLSelect("quiz_main");
                ResultSet rs = stmt.executeQuery(sql);
                if ( rs.next() ) {
                    quiz = new Quiz();
                    quiz.setId(id);
                    quiz.setTitle(rs.getString("quiz_title"));
                }
            }
            if ( quiz != null ) {
                {
                    r.clear();
                    r.add("quiz_id", id);
                    r.add("question_id");
                    r.add("question_text");
                    r.add("question_type");
                    sql = r.getSQLSelect("quiz_question");
                    ResultSet rs = stmt.executeQuery(sql);
                    while ( rs.next() ) {
                        Question question = new Question();
                        question.setId(rs.getString("question_id"));
                        question.setText(rs.getString("question_text"));
                        question.setType(rs.getInt("question_type"));
                        quiz.addQuestion(question);
                    }
                }
                for (int i=0; i < quiz.getQuestionCount(); i++){
                    r.clear();
                    Question question = quiz.getQuestion(i);
                    r.add("question_id", question.getId());
                    r.add("choice_id");
                    r.add("choice_text");
                    r.add("is_correct");
                    sql = r.getSQLSelect("quiz_choice");
                    ResultSet rs = stmt.executeQuery(sql);
                    while ( rs.next() ) {
                        Choice choice = new Choice();
                        choice.setId(rs.getString("choice_id"));
                        choice.setText(rs.getString("choice_text"));
                        choice.setCorrect(rs.getInt("is_correct") == 0 ? false : true);
                        question.addChoice(choice);
                    }
                }

            }
            return quiz;
        } finally {
            if ( db != null ) db.close();
        }
    }    
    
    public static Vector getList(String lessonId) throws Exception {
        
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            r.add("quiz_id");
            r.add("quiz_title");
            r.add("lesson_id", lessonId);
            sql = r.getSQLSelect("quiz_main");
            ResultSet rs = stmt.executeQuery(sql);
            Vector list = new Vector();
            while ( rs.next() ) {
                Quiz q = new Quiz();
                q.setId(rs.getString("quiz_id"));
                q.setTitle(rs.getString("quiz_title"));
                list.addElement(q);
            }
            //for each quiz - how many questions
            for ( int i = 0; i < list.size(); i++ ) {
            	Quiz q = (Quiz) list.elementAt(i);
            	q.setNumberOfQuestions(getNumberOfQuestions(stmt, q.getId()));
            }
            return list;
        } finally {
            if ( db != null ) db.close();
        }        
    }
    
    public static Vector getListBySubject(String subjectId) throws Exception {
        
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            r.add("quiz_id");
            r.add("quiz_title");
            r.add("subject_id", subjectId);
            sql = r.getSQLSelect("quiz_main");
            ResultSet rs = stmt.executeQuery(sql);
            Vector list = new Vector();
            while ( rs.next() ) {
                Quiz q = new Quiz();
                q.setId(rs.getString("quiz_id"));
                q.setTitle(rs.getString("quiz_title"));
                list.addElement(q);
            }
            //for each quiz - how many questions
            for ( int i = 0; i < list.size(); i++ ) {
            	Quiz q = (Quiz) list.elementAt(i);
            	q.setNumberOfQuestions(getNumberOfQuestions(stmt, q.getId()));
            }
            return list;
        } finally {
            if ( db != null ) db.close();
        }        
    }    
    
    static int getNumberOfQuestions(Statement stmt, String quiz_id) throws Exception {
    	String sql = "select count(*) cnt from quiz_question where quiz_id = '" + quiz_id + "'";
    	ResultSet rs = stmt.executeQuery(sql);
    	if ( rs.next() ) return rs.getInt(1);
    	else return 0;
    }
    
    public static void addQuestion(String quizId, Question question) throws Exception {
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            int no = 0;
            {
            	sql = "select MAX(question_no) from quiz_question where quiz_id = '" + quizId + "'";
            	ResultSet rs = stmt.executeQuery(sql);
            	if ( rs.next() ) no = rs.getInt(1);
            	no++;
            }
            {
            	r.clear();
            	r.add("quiz_id", quizId);
            	r.add("question_id", question.getId());
            	r.add("question_text", question.getText());
            	r.add("question_type", question.getType());
            	r.add("question_no", no);
                sql = r.getSQLInsert("quiz_question");
                stmt.executeUpdate(sql);            	
            }

        } finally {
            if ( db != null ) db.close();
        }        
    }
    
    public static void addChoice(String questionId, Choice choice) throws Exception {
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            int no = 0;
            {
            	sql = "select max(choice_no) from quiz_choice where question_id = '" + questionId + "'";
            	ResultSet rs = stmt.executeQuery(sql);
            	if ( rs.next() ) no = rs.getInt(1);
            	no++;
            }
            {
	            r.add("question_id", questionId);
	            r.add("choice_id", choice.getId());
	            r.add("choice_text", choice.getText());
	            r.add("is_correct", choice.getCorrect() ? 1 : 0 );
	            r.add("choice_no", no);
	            sql = r.getSQLInsert("quiz_choice");
	            stmt.executeUpdate(sql);
            }
        } finally {
            if ( db != null ) db.close();
        }        
    }
    
    public static Vector getQuestionList(String quizId) throws Exception {
    	return getQuestionList(quizId, false);
    }
    
    public static Vector getQuestionList(String quizId, boolean take) throws Exception {
        
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            r.add("quiz_id", quizId);
            r.add("question_id");
            r.add("question_text");
            r.add("question_type");
            sql = r.getSQLSelect("quiz_question", "question_no");
            ResultSet rs = stmt.executeQuery(sql);
            Vector list = new Vector();
            while ( rs.next() ) {
                Question question = new Question();
                question.setId(rs.getString("question_id"));
                question.setText(rs.getString("question_text"));
                question.setType(rs.getInt("question_type"));
                list.addElement(question);
            }
            //for each question set the choices
            if ( take ) {
	            for ( int i=0; i < list.size(); i++ ) {
	            	Question question = (Question) list.elementAt(i);
	            	Vector choices = getChoiceList(stmt, question.getId());
	            	question.setChoices(choices);
	            }
            }
            return list;
        } finally {
            if ( db != null ) db.close();
        }        
    }     

    public static Vector getChoiceList(String questionId) throws Exception {
        
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            return getChoiceList(stmt, questionId);
        } finally {
            if ( db != null ) db.close();
        }        
    }
    
    public static Vector getChoiceList(Statement stmt, String questionId) throws Exception {

        String sql = "";

        SQLRenderer r = new SQLRenderer();
        r.add("question_id", questionId);
        r.add("choice_id");
        r.add("choice_text");
        r.add("is_correct");
        sql = r.getSQLSelect("quiz_choice", "choice_no");
        ResultSet rs = stmt.executeQuery(sql);
        Vector list = new Vector();
        while ( rs.next() ) {
            Choice c = new Choice();
            c.setId(rs.getString("choice_id"));
            c.setText(rs.getString("choice_text"));
            c.setCorrect(rs.getInt("is_correct") == 0 ? false : true );
            list.addElement(c);
        }
        return list;
       
    }    
    
    public static Question getQuestion(String questionId) throws Exception {
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            r.add("question_id", questionId);
            r.add("question_text");
            r.add("question_type");
            sql = r.getSQLSelect("quiz_question");
            ResultSet rs = stmt.executeQuery(sql);
            Question question = new Question();
            if ( rs.next() ) {
                question.setId(questionId);
                question.setText(rs.getString("question_text"));
                question.setType(rs.getInt("question_type"));
            }
            question.setChoices(getChoiceList(questionId));
            return question;
        } finally {
            if ( db != null ) db.close();
        }        
    } 
    
    public static void updateQuestion(Question question) throws Exception {
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            
            {
                r.update("question_id", question.getId());
                r.add("question_text", question.getText());
                r.add("question_type", question.getType());
                sql = r.getSQLUpdate("quiz_question");
                stmt.executeUpdate(sql);
            }
            
            Vector choices = question.getChoices();
            for ( int i=0; i < choices.size(); i++ ) {
                Choice choice = (Choice) choices.elementAt(i);
                r.clear();
                r.update("question_id", question.getId());
                r.update("choice_id", choice.getId());
                r.add("choice_text", choice.getText());
                r.add("is_correct", choice.getCorrect() ? 1 : 0 );
                r.add("choice_no", i+1);
                sql = r.getSQLUpdate("quiz_choice");
                stmt.executeUpdate(sql);
            }

        } finally {
            if ( db != null ) db.close();
        }               
    }
    
    public static void deleteQuestion(String id) throws Exception {
    	Db db = null;
    	String sql = "";
    	try {
    		db = new Db();
    		Statement stmt = db.getStatement();
    		sql = "delete from quiz_choice where question_id = '" + id + "'";
    		stmt.executeUpdate(sql);
    		sql = "delete from quiz_question where question_id = '" + id + "'";
    		stmt.executeUpdate(sql);
    	} finally {
    		if ( db != null ) db.close();
    	}
    }
    
    public static void deleteChoice(String questionId, String choiceId) throws Exception {
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            sql = "delete from quiz_choice where question_id = '" + questionId + "' and choice_id = '" + choiceId + "'";
            stmt.executeUpdate(sql);
        } finally {
            if ( db != null ) db.close();
        }
    }
    
    public static void saveTitle(String quizId, String quizTitle) throws Exception {
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            r.update("quiz_id", quizId);
            r.add("quiz_title", quizTitle);
            sql = r.getSQLUpdate("quiz_main");
            stmt.executeUpdate(sql);
        } finally {
            if ( db != null ) db.close();
        }
    }
    
    public static Vector getQuestionIdList(Statement stmt, String quizId) throws Exception {
    	SQLRenderer r = new SQLRenderer();
    	r.add("quiz_id", quizId);
    	r.add("question_id");
    	String sql = r.getSQLSelect("quiz_question");
    	ResultSet rs = stmt.executeQuery(sql);
    	Vector v = new Vector();
    	while ( rs.next() ) {
    		v.addElement(rs.getString(1));
    	}
    	return v;
    }

}