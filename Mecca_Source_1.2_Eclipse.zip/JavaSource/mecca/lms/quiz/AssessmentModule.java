/* ************************************************************************
 * Copyright 2005 University ERP Project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.lms.quiz;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Random;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.util.DateTool;

import org.apache.velocity.Template;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.00
 */
public class AssessmentModule  extends mecca.portal.velocity.VTemplate implements mecca.portal.Attributable {


	protected String[] names = {"Moderators"};
	protected Hashtable values = new Hashtable();
	
	private static String[] month_name = {"January", "February", "March", "April", "May", "Jun", "July", "August", "September", "October", "November", "December"};
	private static String[] day_name = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
	private static String[] hour_name = {"12 AM", "1 AM", "2 AM", "3 AM", "4 AM", "5 AM", "6 AM", "7 AM", "8 AM", "9 AM", "10 AM", "11 AM",
														"12 PM", "1 PM", "2 PM", "3 PM", "4 PM", "5 PM", "6 PM", "7 PM", "8 PM", "9 PM", "10 PM", "11 PM"};

	
	
	public String[] getNames() {
		return names;
	}
	
	public Hashtable getValues() {
		return values;
	}
	
	public void setValues(java.util.Hashtable hashtable) {
		values = hashtable;
	}	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		String template_name = "vtl/quiz/assessment.vm";
		String subjectId = getId();
		
		String moderators = values.get(names[0]) != null ? (String) values.get(names[0]) + "," : "";
		String _portal_role = (String) session.getAttribute("_portal_role");
		String inCollabModule = session.getAttribute("inCollabModule") != null ? 
						    	(String) session.getAttribute("inCollabModule") : "false";
		String collab_role = "true".equals(inCollabModule) ? session.getAttribute("_collab_role") != null ? 
								(String) session.getAttribute("_collab_role") : "" : "";
		String roleToAllow = !"".equals(collab_role) ? collab_role : _portal_role;
		if ( moderators.indexOf(roleToAllow + ",") == -1 ) {
			context.put("allowPost", new Boolean(false));		
			context.put("allowUpdate", new Boolean(false));
			context.put("allowDelete", new Boolean(false));
			context.put("isModerator", new Boolean(false));
		} else {
			context.put("allowPost", new Boolean(true));		
			context.put("allowUpdate", new Boolean(true));
			context.put("allowDelete", new Boolean(true));
			context.put("isModerator", new Boolean(true));
		}		
		
		context.put("month_name", month_name);
		Calendar now = new GregorianCalendar();
	    now.setTime(new java.util.Date());
	    String now_day = "" + now.get(Calendar.DAY_OF_MONTH);
	    int now_month = now.get(Calendar.MONTH);
	    int year = now.get(Calendar.YEAR);
	    //String now_hour = "" + now.get(Calendar.HOUR_OF_DAY);
	    //String now_minute = "" + now.get(Calendar.MINUTE);
		context.put("year", new Integer(year));
		//context.put("month", new Integer(month1));
		//context.put("day", new Integer(day1));		
		
		String submit = getParam("command");
		
		if ( "doCreate".equals(submit) ) {
			doCreate(session, subjectId);
			template_name = "vtl/quiz/assessment_create.vm";
		}
		if ( "createAssessment".equals(submit) ) {
			createAssessment(session, subjectId);
			template_name = "vtl/quiz/assessment.vm";
		}
		else if ( "doPublish".equals(submit) ) {
			
		}
		else if ( "doQuestionBank".equals(submit) ) {
			
		}
		else if ( "runAssessment".equals(submit) ) {
			runAssessment(session, subjectId);
			template_name = "vtl/quiz/questions_take.vm";
		}
		else if ( "editAssessment".equals(submit) ) {
			editAssessment(session, subjectId);
			template_name = "vtl/quiz/assessment_create.vm";
		}
		else if ( "updateAssessment".equals(submit) ) {
			updateAssessment(session, subjectId);
			template_name = "vtl/quiz/assessment.vm";
		}		
		else if ( "deleteAssessment".equals(submit) ) {
			deleteAssessment(session);
			template_name = "vtl/quiz/assessment.vm";
		}		
		else if ( "submitAnswers".equals(submit) ) {
			submitAnswers(session);
			template_name = "vtl/quiz/submit_answers.vm";	
		}
		else if ( "cancelTake".equals(submit) ) {
			cancelTakeAssessment(session);
			template_name = "vtl/quiz/assessment.vm";	
		}		
		else if ( "myProgress".equals(submit) ) {
			myProgress(session);
			template_name = "vtl/quiz/quiz_progress.vm";	
		}		
		
		getList(session, subjectId);
		
		
		Template template = engine.getTemplate(template_name);	
		return template;	
		
	}
	
	void myProgress(HttpSession session) throws Exception {
	    String user = (String) session.getAttribute("_portal_login");
	    String assessmentId = getParam("assessment_id");
	    Hashtable assessmentInfo = AssessmentData.getAssessment(assessmentId);
	    context.put("assessmentInfo", assessmentInfo);	    
	    Vector v = AssessmentData.getUserProgress(user, assessmentId);
	    context.put("assessmentProgress", v);
	}
	

	
	
	void editAssessment(HttpSession session, String subjectId) throws Exception {
	    String assessmentId = getParam("assessment_id");
	    Hashtable assessmentInfo = AssessmentData.getAssessment(assessmentId);
	    context.put("assessmentInfo", assessmentInfo);
	    
		Vector categoryList = AssessmentData.getCategoryList(subjectId);
		context.put("categoryList", categoryList);
		
		Hashtable questionCount = AssessmentData.getAssessmentQuestionCount(assessmentId);
		context.put("questionCount", questionCount);
		
		context.put("isCreate", new Boolean(false));
		
	}
	
	
	void updateAssessment(HttpSession session, String subjectId) throws Exception {
	    String assessmentId = getParam("assessment_id");
		String title = getParam("assessment_title");
		Vector cats = AssessmentData.getCategoryList(subjectId);
		int[] numbers = new int[cats.size()];
		for (int i=0; i < cats.size(); i++ ) {
			Hashtable h = (Hashtable) cats.elementAt(i);
			numbers[i] = Integer.parseInt(getParam("question_" + (String) h.get("quiz_id")));
		}
		String year1 = getParam("year1");
		String month1 = getParam("month1");
		String day1 = getParam("day1");
		String year2 = getParam("year2");
		String month2 = getParam("month2");
		String day2 = getParam("day2");		
		String start_date = year1 + "-" + DateTool.fmt(month1) + "-" + DateTool.fmt(day1);		
		String end_date = year2 + "-" + DateTool.fmt(month2) + "-" + DateTool.fmt(day2);	
		int time_limit_hr = Integer.parseInt(getParam("time_limit_hr"));
		int time_limit_min = Integer.parseInt(getParam("time_limit_min"));
		int max_attempt = Integer.parseInt(getParam("max_attempt"));
		int passing_marks = Integer.parseInt(getParam("passing_marks"));
		
		AssessmentData.updateAssessment(assessmentId, title, cats, numbers, start_date, end_date, time_limit_hr, time_limit_min, max_attempt, passing_marks);	    
	}
	
	void deleteAssessment(HttpSession session) throws Exception {
	    String id = request.getParameter("assessment_id");
	    AssessmentData.deleteAssessment(id);
	}
	
	void getList(HttpSession session, String subjectId) throws Exception {
	    String user = (String) session.getAttribute("_portal_login");
	    Hashtable userAttemptInfo = AssessmentData.getUserAttemptCount(user);
	    context.put("userAttemptInfo", userAttemptInfo);
		Vector assessmentList = AssessmentData.getList(subjectId);
		context.put("assessmentList", assessmentList);
	}
	
	void doCreate(HttpSession session, String subjectId) throws Exception {
		Vector categoryList = AssessmentData.getCategoryList(subjectId);
		context.put("categoryList", categoryList);
		
	    Hashtable info = new Hashtable();
	    info.put("assessment_id", "");
	    info.put("assessment_title", "");
	    info.put("start_date", "");
	    info.put("end_date", "");
	    info.put("time_limit_hr", new Integer(0));
	    info.put("time_limit_min", new Integer(0));
	    info.put("max_attempt", new Integer(0));
	    info.put("passing_marks", new Integer(0));
		context.put("assessmentInfo", info);
		
		context.put("isCreate", new Boolean(true));
	}
	
	void createAssessment(HttpSession session, String subjectId) throws Exception {
		
	    String user = (String) session.getAttribute("_portal_login");
		String title = getParam("assessment_title");
		Vector cats = AssessmentData.getCategoryList(subjectId);
		int[] numbers = new int[cats.size()];
		for (int i=0; i < cats.size(); i++ ) {
			Hashtable h = (Hashtable) cats.elementAt(i);
			numbers[i] = Integer.parseInt(getParam("question_" + (String) h.get("quiz_id")));
			//int total = ((Integer) h.get("numberOfQuestion")).intValue();
			//int[] numbers = AssessmentData.createRandom(total, num);
		}
		String year1 = getParam("year1");
		String month1 = getParam("month1");
		String day1 = getParam("day1");
		String year2 = getParam("year2");
		String month2 = getParam("month2");
		String day2 = getParam("day2");		
		String start_date = year1 + "-" + DateTool.fmt(month1) + "-" + DateTool.fmt(day1);		
		String end_date = year2 + "-" + DateTool.fmt(month2) + "-" + DateTool.fmt(day2);	
		int time_limit_hr = Integer.parseInt(getParam("time_limit_hr"));
		int time_limit_min = Integer.parseInt(getParam("time_limit_min"));
		int max_attempt = Integer.parseInt(getParam("max_attempt"));
		int passing_marks = Integer.parseInt(getParam("passing_marks"));
		AssessmentData.addAssessment(user, subjectId, title, cats, numbers, start_date, end_date, time_limit_hr, time_limit_min, max_attempt, passing_marks);
	}
	
	void runAssessment(HttpSession session, String subjectId) throws Exception {
		String assessmentId = getParam("assessment_id");
		String user = (String) session.getAttribute("_portal_login");
		int attempt_no = AssessmentData.generateAssessment(user, assessmentId);

	    Quiz quiz = AssessmentData.getQuiz(user, assessmentId, attempt_no);
	    Vector questions = quiz.getQuestions();
	    context.put("quizId", assessmentId);
	    context.put("questions", questions);	    
	    context.put("quiz", quiz);			
		
	}
	
	void cancelTakeAssessment(HttpSession session) throws Exception {
		String user = (String) session.getAttribute("_portal_login");
	    String assessmentId = getParam("quizId"); //assessment_id	
	    AssessmentData.deleteResult(user, assessmentId, -1);
	}	
	
	void submitAnswers(HttpSession session) throws Exception {
		String user = (String) session.getAttribute("_portal_login");
	    String assessmentId = getParam("quizId"); //assessment_id
	    Quiz quiz = AssessmentData.getQuiz(user, assessmentId);
        
	    //CURRENT DATE TIME - tak perlu sebab dah ambik dari atas
        //java.util.Date date = ((java.util.Calendar) DateTool.getCurrentDateTime().get("calendar")).getTime();
        //quiz.setAttemptDate(date);
        
	    context.put("quiz", quiz);
	    Vector questions = quiz.getQuestions();
	    context.put("questions", questions);
	    int numOfQuestion = questions.size();
	    int numOfCorrect = 0;
	    for ( int i = 0; i < questions.size(); i++ ) {
	        Question question = (Question) questions.elementAt(i);
	        Vector choices = question.getChoices();
	        Vector userAnswers = new Vector();
	        boolean answerIsCorrect = false;
	        if ( question.getType() == 1 ) { //MULTIPLE CHOICES
	            String[] answers = request.getParameterValues("choice_" + question.getId());

	            //--
	            question.setAnswers(answers);
	            
	            Vector ans = new Vector();
	            if ( answers != null ) {
		            for ( int k = 0; k < answers.length; k++ ) {
		                ans.addElement(new Integer(answers[k]));
		            }
	            }
	            
	            Vector ans2 = new Vector();
	            int correctNum = 0;
	            for ( int num = 0; num < choices.size(); num++ ) {
	                Choice choice = (Choice) choices.elementAt(num);
	                if ( choice.getCorrect()) {
	                	correctNum = num + 1;
	                	ans2.addElement(new Integer(correctNum));
	                }
	            }
	            if ( ans.size() == ans2.size() ) {
	            	answerIsCorrect = true;
	            	for (int k = 0; k < ans.size(); k++ ) {
	            		int i1 = ((Integer) ans.elementAt(k)).intValue();
	            		int i2 = ((Integer) ans2.elementAt(k)).intValue();
	            		if ( i1 != i2 ) {
	            			answerIsCorrect = false;
	            			break;
	            		}
	            	}
	            } else {
	            	answerIsCorrect = false;
	            }
	        } else if ( question.getType() == 0 ) { //SINGLE CHOICE
	            String answer = getParam("choice_" + question.getId());
	            
	            //--
	            question.setAnswers(new String[] {answer});
	            
	            int correctNum = 0;
	            for ( int num = 0; num < choices.size(); num++ ) {
	                Choice choice = (Choice) choices.elementAt(num);
	                if ( choice.getCorrect()) correctNum = num;
	            }
	            correctNum += 1;
	            if ( !"".equals(answer) && correctNum == Integer.parseInt(answer) ) {
	                answerIsCorrect = true;
	            }
	            else {
	                answerIsCorrect = false;
	            }
	        } else if ( question.getType() == 2 ) { //FILL IN THE BLANK
	            String[] answers = request.getParameterValues("choice_" + question.getId());
	            
	            //--
	            question.setAnswers(answers);
	            
	            if ( answers != null ) {
		            for ( int k = 0; k < answers.length; k++ ) {
		                Choice choice = (Choice) choices.elementAt(k);
		                if ( answers[k].trim().equals(choice.getText().trim())) {
		                    answerIsCorrect = true;
		                } else {
		                	answerIsCorrect = false;
		                }
		            }
	            }	            
	        }
	        if ( answerIsCorrect ) numOfCorrect++;
	        question.setUserCorrect(answerIsCorrect);
	    }
	    quiz.setNumberOfCorrect(numOfCorrect);
	    
	    int time_hr = Integer.parseInt(getParam("time_taken_hr"));
	    int time_min = Integer.parseInt(getParam("time_taken_min"));
	    int time_sec = Integer.parseInt(getParam("time_taken_sec"));
	    
	    int time_limit_hr = quiz.getTimeHours();
	    int time_limit_min = quiz.getTimeMinutes();
	    
	    Hashtable h = Util.getTimeDifference(time_limit_hr, time_limit_min, 0, time_hr, time_min, time_sec);
	    int time_taken_hr = ((Integer) h.get("hours")).intValue();
	    int time_taken_min = ((Integer) h.get("minutes")).intValue();
	    int time_taken_sec = ((Integer) h.get("seconds")).intValue();
	    
	    quiz.setTimeTakenHours(time_taken_hr);
	    quiz.setTimeTakenMinutes(time_taken_min);
	    quiz.setTimeTakenSeconds(time_taken_sec);
	    AssessmentData.saveUserAnswers(assessmentId, user, quiz);
	}	
	
	
	

}
