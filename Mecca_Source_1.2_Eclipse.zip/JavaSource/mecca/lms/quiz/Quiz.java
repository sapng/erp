/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.lms.quiz;

import java.util.Vector;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class Quiz {
    
    private String id;
    private String title;
    private Vector questions;
    private String lessonId;
    private String subjectId;
    private int numberOfQuestion;
    private int numberOfCorrect;
    private float userMarksAsPercent;
    private float passingMarks;
    private int timeHours;
    private int timeMinutes;
    private int attemptNo;
    private java.util.Date attemptDate;
    private int timeTakenHours;
    private int timeTakenMinutes;
    private int timeTakenSeconds;
    
    public Quiz() {
        questions = new Vector();
    }
    
    public void setId(String s) {
        id = s;
    }
    
    public void setTitle(String s) {
        title = s;
    }
    
    public void setQuestions(Vector v) {
        questions = v;
    }
    
    public void setLessonId(String s) {
        lessonId = s;
    }
    
    public void setSubjectId(String s ) {
    	subjectId = s;
    }
    
    public void addQuestion(Question q) {
        questions.addElement(q);
        numberOfQuestion++;
    }
    
    public String getId() {
        return id;
    }
    
    public String getTitle() {
        return title;
    }

    public Vector getQuestions() {
        return questions;
    }
 
    public int getQuestionCount() {
        return questions.size();
    }
    
    public Question getQuestion(int i) {
        return (Question) questions.elementAt(i);
    }
    
    public String getLessonId() {
        return lessonId;
    }
    
    public String getSubjectId() {
    	return subjectId;
    }

    public void setNumberOfQuestions(int n) {
    	numberOfQuestion = n;
    }
    
    public int getNumberOfQuestions() {
    	return numberOfQuestion;
    }
    
    public void setNumberOfCorrect(int num) {
    	numberOfCorrect = num;
    }
    
    public int getNumberOfCorrect() {
    	return numberOfCorrect;
    }
    
    public String getUserMarksAsPercent() {
    	float marks = ((float) numberOfCorrect/(float) numberOfQuestion) * 100;
    	return getDecimalFormatted(marks) + "%";
    }
    
    public float getUserMarks() {
    	float marks = ((float) numberOfCorrect/(float) numberOfQuestion) * 100;
    	return marks;
    }    
    
	static String getDecimalFormatted(float number) {
		return new java.text.DecimalFormat("#,###,###").format(number);
	}
	
	public void setPassingMarks(float marks) {
	    passingMarks = marks;
	}
	
	public float getPassingMarks() {
	    return passingMarks;
	}
	
	public boolean getUserPassed() {
	    return getUserMarks() > getPassingMarks() || getUserMarks() == getPassingMarks(); 
	}
	
	public void setTimeHours(int i) {
	    timeHours = i;
	}
	
	public void setTimeMinutes(int i) {
	    timeMinutes = i;
	}
	
	public int getTimeHours() {
	    return timeHours;
	}
	
	public int getTimeMinutes() {
	    return timeMinutes;
	}
	
	public void setAttemptNo(int no) {
	    attemptNo = no;
	}
	
	public int getAttemptNo() {
	    return attemptNo;
	}
	
	public void setAttemptDate(java.util.Date date) {
	    attemptDate = date;
	}
	
	public java.util.Date getAttemptDate() {
	    return attemptDate;
	}	
	
	public void setTimeTakenHours(int i) {
	    timeTakenHours = i;
	}
	
	public void setTimeTakenMinutes(int i) {
	    timeTakenMinutes = i;
	}
	
	public int getTimeTakenHours() {
	    return timeTakenHours;
	}
	
	public int getTimeTakenMinutes() {
	    return timeTakenMinutes;
	}
	
	public void setTimeTakenSeconds(int i) {
	    timeTakenSeconds = i;
	}
	
	public int getTimeTakenSeconds() {
	    return timeTakenSeconds;
	}
	
}
