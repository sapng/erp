/* ************************************************************************
 * Copyright 2005 University ERP Project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.lms.quiz;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Random;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;
import mecca.db.UniqueID;
import mecca.util.DateTool;
import mecca.util.DateUtil;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.00
 */
public class AssessmentData {
	
	/*
	 *  Category is Quizzes under a Subject
	 */

	public static Vector getCategoryList(String subjectId) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("quiz_id");
			r.add("quiz_title");
			r.add("date_create");
			r.add("l.subject_id", subjectId);
			r.add("q.lesson_id", r.unquote("l.lesson_id"));
			sql = r.getSQLSelect("quiz_main q, lesson l");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("quiz_id", rs.getString(1));
				h.put("quiz_title", rs.getString(2));
				v.addElement(h);
			}
			
			for ( int i = 0; i < v.size(); i++ ) {
				Hashtable h = (Hashtable) v.elementAt(i);
				String quizId = (String) h.get("quiz_id");
				int count = getNumberOfQuestion(stmt, quizId);
				h.put("numberOfQuestion", new Integer(count));
			}
			return v;

			
		} finally {
			if ( db != null ) db.close();
		}
		
	}
	
	
	public static int getNumberOfQuestion(Statement stmt, String quizId) throws Exception {
		String sql = "select count(*) cnt from quiz_question where quiz_id = '" + quizId + "'";
		ResultSet rs = stmt.executeQuery(sql);
		if ( rs.next() ) return rs.getInt(1);
		else return 0;
	}
	
	public static void addAssessment(String user, String subjectId, String title, 
			Vector quizList, int[] numbers, String start_date, String end_date, 
			int hr, int min, int max_attempt, int passing_marks) throws Exception {
		Db db = null;
		String sql = "";
		try {
			String uid = Long.toString(UniqueID.get());
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			{
				r.add("assessment_id", uid);
				r.add("subject_id", subjectId);
				r.add("assessment_title", title);
				r.add("created_by", user);
				r.add("start_date", start_date);
				r.add("end_date", end_date);
				r.add("created_date", r.unquote("now()"));
				r.add("time_limit_hr", hr);
				r.add("time_limit_min", min);
				r.add("max_attempt", max_attempt);
				r.add("passing_marks", passing_marks);
				sql = r.getSQLInsert("quiz_assessment");
				
				stmt.executeUpdate(sql);
			}
			for (int i=0; i < quizList.size(); i++ ){
				Hashtable h = (Hashtable) quizList.elementAt(i);
				String quizId = (String) h.get("quiz_id");
				r.clear();
				r.add("assessment_id", uid);
				r.add("quiz_id", quizId);
				r.add("number_of_questions", numbers[i]);
				sql = r.getSQLInsert("quiz_assessment_questions");
				
				stmt.executeUpdate(sql);
			}
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static void updateAssessment(String assessmentId, String title, 
			Vector quizList, int[] numbers, String start_date, String end_date, 
			int hr, int min, int max_attempt, int passing_marks) throws Exception {
		Db db = null;
		String sql = "";
		try {
			String uid = Long.toString(UniqueID.get());
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			{
				r.update("assessment_id", assessmentId);
				r.add("assessment_title", title);
				r.add("start_date", start_date);
				r.add("end_date", end_date);
				r.add("time_limit_hr", hr);
				r.add("time_limit_min", min);
				r.add("max_attempt", max_attempt);				
				r.add("passing_marks", passing_marks);
				sql = r.getSQLUpdate("quiz_assessment");
				
				stmt.executeUpdate(sql);
			}
			{
				sql = "delete from quiz_assessment_questions where assessment_id = '" + assessmentId + "'";
				stmt.executeUpdate(sql);
			}
			for (int i=0; i < quizList.size(); i++ ){
				Hashtable h = (Hashtable) quizList.elementAt(i);
				String quizId = (String) h.get("quiz_id");
				r.clear();
				r.add("assessment_id", assessmentId);
				r.add("quiz_id", quizId);
				r.add("number_of_questions", numbers[i]);
				sql = r.getSQLInsert("quiz_assessment_questions");
				
				stmt.executeUpdate(sql);
			}
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	
	public static void deleteAssessment(String id) throws Exception {
	    Db db = null;
	    String sql = "";
	    try {
	        db = new Db();
	        Statement stmt = db.getStatement(); 
	        sql = "delete from quiz_assessment_questions where assessment_id = '" + id + "'";
	        stmt.executeUpdate(sql);
	        sql = "delete from quiz_assessment_run where assessment_id = '" + id + "'";
	        stmt.executeUpdate(sql);
	        sql = "delete from quiz_assessment_attempt where assessment_id = '" + id + "'";
	        stmt.executeUpdate(sql);	        
	        sql = "delete from quiz_assessment where assessment_id = '" + id + "'";
	        stmt.executeUpdate(sql);	        
	    } finally {
	        if ( db != null ) db.close();
	    }
	}
	
	public static Vector getList(String subjectId) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("subject_id", subjectId);
			r.add("assessment_id");
			r.add("assessment_title");
			r.add("created_date");
			r.add("start_date");
			r.add("end_date");
			r.add("time_limit_hr");
			r.add("time_limit_min");
			r.add("max_attempt");
			sql = r.getSQLSelect("quiz_assessment", "created_date DESC");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("assessment_id", Db.getString(rs, "assessment_id"));
				h.put("assessment_title", Db.getString(rs, "assessment_title"));
				String start_date = DateTool.getDateFormatted(Db.getDate(rs, "start_date"));
				String end_date = DateTool.getDateFormatted(Db.getDate(rs, "end_date"));
				h.put("start_date", start_date);
				h.put("end_date", end_date);
				int time_limit_hr = rs.getInt("time_limit_hr");
				int time_limit_min = rs.getInt("time_limit_min");
				int max_attempt = rs.getInt("max_attempt");
				h.put("time_limit_hr", new Integer(time_limit_hr));
				h.put("time_limit_min", new Integer(time_limit_min));
				String time_limit = AssessmentData.constructTime(time_limit_hr, time_limit_min, 0 );
				h.put("time_limit", time_limit);
				h.put("max_attempt", new Integer(max_attempt));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static Hashtable getUserAttemptCount(String user) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			return getUserAttemptCount(stmt, user);
		} finally {
			if ( db != null ) db.close();
		}
	    
	}
	
	public static Hashtable getUserAttemptCount(Statement stmt, String user) throws Exception {
	    String sql = "";
	    SQLRenderer r = new SQLRenderer();
	    r.add("user_id", user);
	    r.add("assessment_id");
	    r.add("attempt_count");
	    sql = r.getSQLSelect("quiz_assessment_attempt");
	    ResultSet rs = stmt.executeQuery(sql);
	    Hashtable h = new Hashtable();
	    while ( rs.next() ) {
	        h.put(rs.getString(1), new Integer(rs.getInt(2)));
	    }
	    return h;
	}
	
	public static Hashtable getAssessmentQuestionCount(String assessmentId) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			return getAssessmentQuestionCount(stmt, assessmentId);
		} finally {
			if ( db != null ) db.close();
		}	    
	}
	
	public static Hashtable getAssessmentQuestionCount(Statement stmt, String assessmentId) throws Exception {
	    String sql = "";
	    SQLRenderer r = new SQLRenderer();
	    r.add("assessment_id", assessmentId);
	    r.add("quiz_id");
	    r.add("number_of_questions");
	    sql = r.getSQLSelect("quiz_assessment_questions");
	    ResultSet rs = stmt.executeQuery(sql);
	    Hashtable h = new Hashtable();
	    while ( rs.next() ) {
	        h.put(rs.getString(1), new Integer(rs.getInt(2)));
	    }
	    return h;
	}
	
	public static Hashtable getAssessment(String assessmentId) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			return getAssessment(stmt, assessmentId);
		} finally {
			if ( db != null ) db.close();
		}
	}		
	
	public static Hashtable getAssessment(Statement stmt, String assessmentId) throws Exception {

		String sql = "";
		SQLRenderer r = new SQLRenderer();
		r.add("assessment_id", assessmentId);
		r.add("assessment_title");
		r.add("created_date");
		r.add("start_date");
		r.add("end_date");
		r.add("time_limit_hr");
		r.add("time_limit_min");
		r.add("max_attempt");
		r.add("passing_marks");
		sql = r.getSQLSelect("quiz_assessment");
		ResultSet rs = stmt.executeQuery(sql);
		Hashtable h = new Hashtable();
		while ( rs.next() ) {
			
			h.put("assessment_id", assessmentId);
			h.put("assessment_title", rs.getString("assessment_title"));
			
			java.util.Date date1 = Db.getDate(rs, "start_date");
			java.util.Date date2 = Db.getDate(rs, "end_date");
			
			String start_date = DateTool.getDateFormatted(date1);
			String end_date = DateTool.getDateFormatted(date2);
			h.put("start_date", start_date);
			h.put("end_date", end_date);
			
			Hashtable hdate1 = DateTool.getYMD(date1);
			Hashtable hdate2 = DateTool.getYMD(date2);
			
			h.put("year1", hdate1.get("year"));
			h.put("month1", hdate1.get("month"));
			h.put("day1", hdate1.get("day"));
			
			h.put("year2", hdate2.get("year"));
			h.put("month2", hdate2.get("month"));
			h.put("day2", hdate2.get("day"));			
			
			int time_limit_hr = rs.getInt("time_limit_hr");
			int time_limit_min = rs.getInt("time_limit_min");
			int max_attempt = rs.getInt("max_attempt");
			h.put("time_limit_hr", new Integer(time_limit_hr));
			h.put("time_limit_min", new Integer(time_limit_min));
			h.put("max_attempt", new Integer(max_attempt));		
			
			int passing_marks = rs.getInt("passing_marks");
			h.put("passing_marks", new Integer(passing_marks));

		}
		return h;

	}	
	
	public static Vector getAssessmentDetail(String assessmentId) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("assessment_id", assessmentId);
			r.add("quiz_id");
			r.add("number_of_questions");
			sql = r.getSQLSelect("quiz_assessment_questions");
			ResultSet rs = stmt.executeQuery(sql);	
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("quiz_id", rs.getString("quiz_id"));
				h.put("number_of_questions", new Integer(rs.getInt("number_of_questions")));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	public static int generateAssessment(String user, String assessmentId) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			Vector detail = getAssessmentDetail(assessmentId);
			SQLRenderer r = new SQLRenderer();
			//get number of attempt for this assignment
			int max_attempt = 0;
			int attempt_no = 1;
			{
			    r.clear();
			    r.add("assessment_id", assessmentId);
			    r.add("max_attempt");
			    sql = r.getSQLSelect("quiz_assessment");
			    ResultSet rs = stmt.executeQuery(sql);
			    if ( rs.next() ) max_attempt = rs.getInt(1);
			}
			//get attempted numbers for this user
			if ( max_attempt > 0 ) {
			    r.clear();
				r.add("user_id", user);
				r.add("assessment_id", assessmentId);
				r.add("MAX(attempt_no) cnt");
				sql = r.getSQLSelect("quiz_assessment_run");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) attempt_no = rs.getInt(1);
				else attempt_no = 0;
				attempt_no++;
			    
			}
			else { //MAX ATTEMPT
				r.clear();
				r.add("user_id", user);
				r.add("assessment_id", assessmentId);
				r.add("attempt_no", attempt_no);
				sql = r.getSQLDelete("quiz_assessment_run");
				stmt.executeUpdate(sql);
			}
			int cnt = 0;
			for ( int i = 0; i < detail.size(); i++ ) {
				Hashtable h = (Hashtable) detail.elementAt(i);
				String quizId = (String) h.get("quiz_id");
				int count = ((Integer) h.get("number_of_questions")).intValue();
				//int high = QuizDb.getNumberOfQuestions(stmt, quizId);
				
				//get questions ids Vector
				Vector questionIds = QuizDb.getQuestionIdList(stmt, quizId);
				int high = questionIds.size();
				
				//generate random numbers
				//System.out.println("high=" + high + ", count= " + count);
				int[] nos = Util.createRandom(high, count);
				for ( int k=0; k < nos.length;k++ ) {
					cnt++;
					
					//System.out.print((String) questionIds.elementAt(nos[k]-1) + ", ");
					
					r.clear();
					r.add("user_id", user);
					r.add("assessment_id", assessmentId);
					r.add("question_no", cnt);
					r.add("question_id", (String) questionIds.elementAt(nos[k]-1));
					r.add("attempt_no", attempt_no);
					sql = r.getSQLInsert("quiz_assessment_run");
					stmt.executeUpdate(sql);
				}
				

			}
			//create result table
			{
			    r.clear();
			    r.add("user_id", user);
			    r.add("assessment_id", assessmentId);
			    r.add("attempt_no", attempt_no);
			    r.add("attempt_date", DateTool.getCurrentDate());
			    sql = r.getSQLInsert("quiz_assessment_result");

			    stmt.executeUpdate(sql);
			    
			}			
			return attempt_no;
		} finally {
			if ( db != null ) db.close();
		}

	}
	
	public static Quiz getQuiz(String user, String assessmentId) throws Exception {
	    return getQuiz(user, assessmentId, -1);
	}
	
    public static Quiz getQuiz(String user, String assessmentId, int attempt_no) throws Exception {
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            return getQuiz(stmt, user, assessmentId, attempt_no);
        } finally {
            if ( db != null ) db.close();
        }
    }             
            
	
	
    public static Quiz getQuiz(Statement stmt, String user, String assessmentId, int attempt_no) throws Exception {
        String sql = "";
        Hashtable ass = getAssessment(assessmentId);
        
        SQLRenderer r = new SQLRenderer();
        Quiz quiz = null;
        quiz = new Quiz();
        quiz.setId(assessmentId);
        quiz.setTitle((String) ass.get("assessment_title"));
        int passing_marks = ((Integer) ass.get("passing_marks")).intValue();
        int time_hours = ((Integer) ass.get("time_limit_hr")).intValue();
        int time_minutes = ((Integer) ass.get("time_limit_min")).intValue();
        
        quiz.setPassingMarks(passing_marks);
        quiz.setTimeHours(time_hours);
        quiz.setTimeMinutes(time_minutes);
        
        //CURRENT DATE TIME
        //java.util.Date date = ((java.util.Calendar) DateTool.getCurrentDateTime().get("calendar")).getTime();
        //quiz.setAttemptDate(date);
        

        if ( quiz != null ) {
            //if attempt_no = -1 is to get the last attempt no
			if ( attempt_no == -1 ) {
			    r.clear();
				r.add("user_id", user);
				r.add("assessment_id", assessmentId);
				r.add("MAX(attempt_no) cnt");
				sql = r.getSQLSelect("quiz_assessment_run");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) attempt_no = rs.getInt(1);
				else attempt_no = 0;
			}
			
			//save attempt no
			quiz.setAttemptNo(attempt_no);
			{
			    boolean exist = false;
			    sql = "select attempt_count from quiz_assessment_attempt where user_id = '" + user + "' and assessment_id = '" + assessmentId + "'";
			    ResultSet rs = stmt.executeQuery(sql);
			    if ( rs.next() ) exist = true;
			    if ( !exist ) {
			        r.clear();
			        r.add("user_id", user);
			        r.add("assessment_id", assessmentId);
			        r.add("attempt_count", attempt_no);
			        sql = r.getSQLInsert("quiz_assessment_attempt");
			    } else {
			        r.clear();
			        r.update("user_id", user);
			        r.update("assessment_id", assessmentId);
			        r.add("attempt_count", attempt_no);
			        sql = r.getSQLUpdate("quiz_assessment_attempt");
			    }
			    stmt.executeUpdate(sql);
			}
            
            {
                r.clear();
                r.add("r.assessment_id", assessmentId);
                r.add("r.user_id", user);
                r.add("r.attempt_no", attempt_no);
                r.add("q.question_id");
                r.add("q.question_text");
                r.add("q.question_type");
                r.add("r.question_id", r.unquote("q.question_id"));
                sql = r.getSQLSelect("quiz_assessment_run r, quiz_question q", "r.question_no");
                
                //System.out.println(sql);
                
                ResultSet rs = stmt.executeQuery(sql);
                int cnt = 0;
                while ( rs.next() ) {
                	cnt++;
                    Question question = new Question();
                    question.setId(rs.getString("question_id"));
                    question.setText(rs.getString("question_text"));
                    question.setType(rs.getInt("question_type"));
                    quiz.addQuestion(question);
                }
                //System.out.println("Question count = " + cnt);
            }
            for (int i=0; i < quiz.getQuestionCount(); i++){
                r.clear();
                Question question = quiz.getQuestion(i);
                r.add("question_id", question.getId());
                r.add("choice_id");
                r.add("choice_text");
                r.add("is_correct");
                sql = r.getSQLSelect("quiz_choice");
                ResultSet rs = stmt.executeQuery(sql);
                while ( rs.next() ) {
                    Choice choice = new Choice();
                    choice.setId(rs.getString("choice_id"));
                    choice.setText(rs.getString("choice_text"));
                    choice.setCorrect(rs.getInt("is_correct") == 0 ? false : true);
                    question.addChoice(choice);
                }
            }
            
            //get attempt_date from quiz_assessment_result
            {
                r.clear();
                r.add("assessment_id", assessmentId);
                r.add("user_id", user);
                r.add("attempt_no", attempt_no);
                r.add("attempt_date");
                sql = r.getSQLSelect("quiz_assessment_result");
                ResultSet rs = stmt.executeQuery(sql);
                if ( rs.next() ) {
                    java.util.Date date = Db.getDate(rs, "attempt_date");
                    quiz.setAttemptDate(date);
                }
            }

        }
        return quiz;

    } 	
    
    public static void saveUserAnswers(String assessmentId, String userId, Quiz quiz) throws Exception {
        
        Db db = null;
        String sql = "";
        try {
            
            db = new Db();
            Statement stmt = db.getStatement();
        
	        Vector questions = quiz.getQuestions();
	
	        int attemptNo = quiz.getAttemptNo();
	        float passingMarks = quiz.getPassingMarks();
	        float userMarks = quiz.getUserMarks();
	        boolean isPassed = userMarks > passingMarks || userMarks == passingMarks;
	        int limit_hr = quiz.getTimeHours();
	        int limit_min = quiz.getTimeMinutes();
	        int time_hr = quiz.getTimeTakenHours();
	        int time_min = quiz.getTimeTakenMinutes();
	        int time_sec = quiz.getTimeTakenSeconds();
	        
	        java.util.Date attemptDate = quiz.getAttemptDate();
	        
	        
	        SQLRenderer r = new SQLRenderer();
	        {
	            r.update("assessment_id", assessmentId);
	            r.update("user_id", userId);
	            r.update("attempt_no", attemptNo);
	            r.add("passing_marks", passingMarks);
	            r.add("user_marks", userMarks);
	            r.add("time_taken_hr", time_hr);
	            r.add("time_taken_min", time_min);
	            r.add("time_taken_sec", time_sec);
	            r.add("time_limit_hr", limit_hr);
	            r.add("time_limit_min", limit_min);
	            r.add("is_passed", isPassed);
	            sql = r.getSQLUpdate("quiz_assessment_result");
	            stmt.executeUpdate(sql);
	        }

	        /*
	        
	        for ( int i=0; i < questions.size(); i++ ) {
	            Question question = (Question) questions.elementAt(i);
	            String questionId = question.getId();
	            Object[] answers = question.getAnswers();
	           
	            for ( int k = 0; k < answers.length; k++ ) {
	                Object ans = answers[k];
	                if ( ans instanceof Integer ) {
	                    
	                } 
	                else if ( ans instanceof String ) {
	                    
	                }
	            }
	           
	            
	        }
	        */
	        
        } finally {
            if ( db != null ) db.close();
        }
    }
    
    
    public static Vector getUserProgress(String user, String assessmentId) throws Exception {
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            r.add("user_id", user);
            r.add("assessment_id", assessmentId);
            r.add("attempt_no");
            r.add("attempt_date");
            r.add("user_marks");
            r.add("passing_marks");
            r.add("time_taken_hr");
            r.add("time_taken_min");
            r.add("time_taken_sec");
            r.add("time_limit_hr");
            r.add("time_limit_min");
            r.add("is_passed");
            sql = r.getSQLSelect("quiz_assessment_result", "attempt_no");
            ResultSet rs = stmt.executeQuery(sql);
            Vector v = new Vector();
            while ( rs.next() ) {
                Hashtable h = new Hashtable();
                h.put("attempt_no", rs.getString("attempt_no"));
                java.sql.Date date = rs.getDate("attempt_date");
                h.put("attempt_date", DateTool.getDateFormatted(date));
                float passing_marks = rs.getFloat("passing_marks");
                h.put("passing_marks", Util.getPercentFormat(passing_marks));
                float user_marks = rs.getFloat("user_marks");
                h.put("user_marks", Util.getPercentFormat(user_marks));
                int hr = rs.getInt("time_taken_hr");
                int min = rs.getInt("time_taken_min");
                int sec = rs.getInt("time_taken_sec");
                h.put("time_taken", constructTime(hr, min, sec));
                hr = rs.getInt("time_limit_hr");
                min = rs.getInt("time_limit_min");
                h.put("time_limit", constructTime(hr, min, 0));
                h.put("is_passed", user_marks > passing_marks || user_marks == passing_marks ? new Boolean(true) : new Boolean(false));
                v.addElement(h);
            }
            return v;
        } finally {
            if ( db != null ) db.close();
        }
    }
    
    static String constructTime(int hr, int min, int sec) {
        String hrs = hr < 10 ? "0" + hr : "" + hr;
        String mins = min < 10 ? "0" + min : "" + min;
        String secs = sec > 0 ? sec < 10 ? "0" + sec : "" + sec : "";
        return sec > 0 ? hrs + " h: " + mins + " m: " + secs + " s": hrs + " h: " + mins + " m";
    }
    
    public static void deleteResult(String user, String assessment, int attempt) throws Exception {
    	Db db = null;
    	String sql = "";
    	try {
    		db = new Db();
    		Statement stmt = db.getStatement();
    		SQLRenderer r = new SQLRenderer();
    		
			if ( attempt == -1 ) {
			    r.clear();
				r.add("user_id", user);
				r.add("assessment_id", assessment);
				r.add("MAX(attempt_no) cnt");
				sql = r.getSQLSelect("quiz_assessment_run");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) attempt = rs.getInt(1);
				else attempt = 0;
			}    		
    		
    		r.clear();
    		r.add("assessment_id", assessment);
    		r.add("user_id", user);
    		r.add("attempt_no", attempt);
    		sql = r.getSQLDelete("quiz_assessment_result");
    		stmt.executeUpdate(sql);
    		r.clear();
    		r.add("assessment_id", assessment);
    		r.add("user_id", user);
    		r.add("attempt_no", attempt);
    		sql = r.getSQLDelete("quiz_assessment_run");
    		stmt.executeUpdate(sql);    		
    	} finally {
    		if ( db != null ) db.close();
    	}
    	
    }
    
	


}
