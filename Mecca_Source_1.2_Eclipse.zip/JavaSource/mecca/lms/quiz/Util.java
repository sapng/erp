/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.lms.quiz;

import java.util.Hashtable;
import java.util.Random;

/**
 * @author Shamsul Bahrin bin Abd Mutalib
 *
 * @version 0.1
 */
public class Util {
    
    public static Hashtable getTimeDifference(int h1, int m1, int s1, int h2, int m2, int s2) {
        Hashtable time1 = new Hashtable();
        Hashtable time2 = new Hashtable();
        time1.put("hours", new Integer(h1));
        time1.put("minutes", new Integer(m1));
        time1.put("seconds", new Integer(s1));
        time2.put("hours", new Integer(h2));
        time2.put("minutes", new Integer(m2));
        time2.put("seconds", new Integer(s2));
        return getTimeDifference(time1, time2);
    }
    
    public static Hashtable getTimeDifference(Hashtable time1, Hashtable time2) {
        int time_limit_hr = ((Integer) time1.get("hours")).intValue();
        int time_limit_min = ((Integer) time1.get("minutes")).intValue();
        int time_limit_sec = ((Integer) time1.get("seconds")).intValue();
        
        int left_hr = ((Integer) time2.get("hours")).intValue();
        int left_min = ((Integer) time2.get("minutes")).intValue();
        int left_sec = ((Integer) time2.get("seconds")).intValue();
        
        //convert all in seconds
        int limit_secs = (time_limit_hr * 60 * 60) + (time_limit_min * 60) + time_limit_sec;
        int secs = (left_hr * 60 * 60 ) + (left_min * 60) + left_sec;
        
        int x = limit_secs - secs;
        
        //convert to hr, min, sec
        int hours = x / (60 * 60) ;
        int timeleft = x % (60 * 60) ;
        int minutes = timeleft /60;
        int seconds = x % 60 ;
        
        Hashtable h = new Hashtable();
        h.put("hours", new Integer(hours));
        h.put("minutes", new Integer(minutes));
        h.put("seconds", new Integer(seconds));

        //System.out.println(hours + ":" + minutes + ":" + seconds);
        
        return h;
        
    }
    
	public static int[] createRandom(int high, int count) {
		//make sure count NEVER exceeds high
		if ( count > high ) count = high;
		int[] numbers = new int[count];
		Random random = new Random();
		for ( int k=0; k < count; k++ ) {
			boolean looping = true;
			int questionNo = 0;
			while ( isDuplicate(questionNo, numbers, k) ) questionNo = random.nextInt(high) + 1;
			numbers[k] = questionNo;
		}
		return numbers;
	}	
	
	static boolean isDuplicate(int num, int[] numbers, int position) {
		boolean b = false;
		for (int i=position; i > -1; i-- ) {
			if ( num == numbers[i]) {
				b = true;
				break;
			}
		}
		return b;
	}
	
	public static String getPercentFormat(float number) {
		return new java.text.DecimalFormat("#,###,###.0").format(number) + " %";
	} 	
	    
    public static void main(String[] args) throws Exception {

        int[] num = createRandom(100, 50);
        for (int i=0; i < num.length; i++ ) {
            System.out.print(num[i] + ", ");
        }
        System.out.println();
        
    }    
    

}
