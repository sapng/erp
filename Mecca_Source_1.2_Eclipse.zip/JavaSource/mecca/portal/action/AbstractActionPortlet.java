/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.portal.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Hashtable;

import javax.portlet.GenericPortlet;
import javax.portlet.PortletConfig;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.portal.Attributable;
import mecca.portal.ErrorMsg;
import mecca.portal.Loader;
import mecca.portal.MerakConfig;
import mecca.portal.MerakRequest;
import mecca.portal.MerakResponse;
import mecca.portal.velocity.VTemplate;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

/**
 * @author Shamsul Bahrin bin Abd Mutalib
 *
 * @version 0.1
 */
public class AbstractActionPortlet extends GenericPortlet {
	
	VelocityEngine engine = new VelocityEngine();
	VelocityContext context = new VelocityContext();
	
	public void doView(RenderRequest req, RenderResponse res) throws PortletException, IOException {
		try {		
			
			PrintWriter out = res.getWriter();
			HttpServletRequest request = ((MerakRequest) req).getHttpServletRequest();
			HttpServletResponse response = ((MerakResponse) res).getHttpServletResponse();
			HttpSession session = request.getSession();
			
			ServletContext servletContext = session.getServletContext();
			//-- GET VELOCITY FROM SESSION (INITIALIZED IN THE PORTAL'S CONTROLLER SERVLET
			context = (VelocityContext) session.getAttribute("_VELOCITY_CONTEXT");
			engine = (VelocityEngine) session.getAttribute("_VELOCITY_ENGINE");
			//--				

			PortletConfig pc = getPortletConfig();
			String pId = "";
			if ( pc instanceof MerakConfig ) pId = ((MerakConfig) pc).getId();		
			//? what if pc not instance of MerakConfig ??	
			
			String appname = (String) session.getAttribute("_portal_appname");
			context.put("appname", appname);
			context.put("session", session);
			
			render(request, response, "mecca.portal.action.VActionTemplate", "test_id");
		
		} catch (Exception ex ) {
			System.out.println( ex.getMessage() );
			//throw new PortletException(ex.getMessage());	
		}
	}
	
	public void render(HttpServletRequest req, HttpServletResponse res, String module, String id) throws ServletException, IOException  {
		PrintWriter out = res.getWriter();
		HttpSession session = req.getSession();
		res.setContentType("text/html");
		try {
			
			VTemplate content = null;
			try {
				Class klazz = Loader.load(module);
				content = ((VTemplate) klazz.newInstance());
				content.setEnvironment(engine, context, req, res);		
				content.setId(id);
				if ( content instanceof mecca.portal.action.VActionTemplate ) {
					Hashtable h = new Hashtable();
					h.put("ActionList", "sis/PreRegistration.xml");
					((Attributable) content).setValues(h);
				}	
			} catch ( ClassNotFoundException cnfex ) {
				content = new ErrorMsg(engine, context, req, res);
				((ErrorMsg) content).setError("ClassNotFoundException : " + cnfex.getMessage());				
			} catch ( InstantiationException iex ) {
				content = new ErrorMsg(engine, context, req, res);
				((ErrorMsg) content).setError("InstantiationException : " + iex.getMessage());			
			} catch ( IllegalAccessException illex ) {
				content = new ErrorMsg(engine, context, req, res);
				((ErrorMsg) content).setError("IllegalAccessException : " + illex.getMessage());			
			} catch ( Exception ex ) {
				content = new ErrorMsg(engine, context, req, res);
				((ErrorMsg) content).setError("Other Exception during class initiation : " + ex.getMessage());	
				ex.printStackTrace();					
			}	
			
			try {
				if ( content != null ) content.print();
			} catch ( Exception ex ) {
				out.println( ex.getMessage() );
			}				
			
		} catch ( Exception ex ) {
			System.out.println( ex.getMessage() );	
		}
	}

	

}
