/* ************************************************************************
 * Copyright 2005 University ERP Project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.portal.action;

import java.util.Hashtable;
import java.util.Set;

import javax.servlet.http.HttpSession;

import mecca.portal.ClassLoadManager;

import org.apache.velocity.Template;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.00
 */
public class AbstractActionModule2 extends mecca.portal.velocity.VTemplate {
	
	protected String templateName = "vtl/action/main.vm";
	protected String actionFilename;
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		String appPath = (String) session.getAttribute("_portal_app_path");
		String actionf = appPath.replace('\\', '/') + "WEB-INF" + "/" + "actions" + actionFilename;
		
		Hashtable commands = ActionParser2.parse(actionf);
		
		Set submits = commands.keySet();
		context.put("submits", submits);
		
		String command = getParam("command");
		Hashtable actions = (Hashtable) commands.get(command);

		if ( actions != null ) {
			Hashtable action = (Hashtable) actions.get("action");
			String actionName = (String) action.get("name");
			Hashtable views = (Hashtable) actions.get("views");
			
			String viewNormal = (String) views.get("normal");
			String viewError = (String) views.get("error");

			//context.put("viewNormal", viewNormal);
			//context.put("viewError", viewError);
			
			ActionTemplate2 actionClass = (ActionTemplate2) ClassLoadManager.load(actionName, request.getRequestedSessionId());
			if ( actionClass.doAction(request, response, context) )
				context.put("view", viewNormal);
			else
				context.put("view", viewError);
			
		}
		else {
			//templateName = "vtl";
		}
		Template template = engine.getTemplate(templateName);	
		return template;	
	}




}
