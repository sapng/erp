/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.portal.action;

import java.io.FileReader;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import nanoxml.XMLElement;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class ActionParser {
	
	public static Hashtable parse(String filename) throws Exception {
		Hashtable commandList = new Hashtable();
		FileReader reader = null;
		try {
			XMLElement actions = new XMLElement();
			reader = new FileReader(filename);
			actions.parseFromReader(reader);
			XMLElement commands = null;
			Vector action_child = actions.getChildren();
			for ( int i = 0; i < action_child.size(); i++ ) {
				XMLElement command = (XMLElement) action_child.elementAt(i);	
				String commandName = (String) command.getAttribute("name");
				Vector command_child = command.getChildren();
				Hashtable h = new Hashtable();
				for ( int k = 0; k < command_child.size(); k++ ) {
					XMLElement e = (XMLElement)	command_child.elementAt(k);
					String name = (String) e.getAttribute("name");
					h.put( e.getName(), name );
				}
				commandList.put(commandName, h);
			}
			return commandList;
		} catch (Exception e) {
			//e.printStackTrace();
			throw e;
		} finally {
			if ( reader != null ) reader.close();
		}
	}
	
	public static void main(String[] args) throws Exception {
		String filename = "x.xml";		
		Hashtable commands = parse(filename);
		for ( Enumeration e = commands.keys(); e.hasMoreElements(); ) {
			String key = (String) e.nextElement();	
			Hashtable h = (Hashtable) commands.get(key);
			String actionName = (String) h.get("action");
			String viewName = (String) h.get("view");
			System.out.println(key + " = " + actionName + ", " + viewName);			
		}
	}
	
}