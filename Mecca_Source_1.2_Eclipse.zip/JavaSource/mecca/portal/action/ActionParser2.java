/* ************************************************************************
 * Copyright 2005 University ERP Project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal.action;

import java.io.FileReader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import nanoxml.XMLElement;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1
 */

public class ActionParser2 {
	
	public static Hashtable parse(String filename) throws Exception {
		Hashtable commandList = new Hashtable();
		FileReader reader = null;
		try {
			XMLElement actions = new XMLElement();
			reader = new FileReader(filename);
			actions.parseFromReader(reader);
			XMLElement commands = null;
			Vector action_child = actions.getChildren();
			for ( int i = 0; i < action_child.size(); i++ ) {
				XMLElement command = (XMLElement) action_child.elementAt(i);	
				String commandName = (String) command.getAttribute("name");
				Vector command_child = command.getChildren();
				Hashtable elements = new Hashtable();
				for ( int k = 0; k < command_child.size(); k++ ) {
					XMLElement e = (XMLElement)	command_child.elementAt(k);
					String elementName = e.getName();
					//System.out.println(elementName);
					Hashtable h = new Hashtable();
					if ( "action".equals(elementName) ) {
						h.put( "name", (String) e.getAttribute("name") );
					}
					else if ( "views".equals(elementName) ) {
						Vector views = e.getChildren();
						for ( int x = 0; x < views.size(); x++ ) {
							XMLElement ve = (XMLElement) views.elementAt(x);
							String veName = ve.getName();
							if ( "target".equals(veName) ) {
								Hashtable attr2 = new Hashtable();
								h.put((String) ve.getAttribute("name"), (String) ve.getAttribute("view"));
							}
						}
					}
					elements.put(elementName, h);
				}
				commandList.put(commandName, elements);
			}
			return commandList;
		} catch (Exception e) {
			//e.printStackTrace();
			throw e;
		} finally {
			if ( reader != null ) reader.close();
		}
	}
	
	public static void main(String[] args) throws Exception {
		String filename = "C:/eclipse/workspace2/university/WebContent/WEB-INF" + "/" + "actions/sis" + "/payment" + "/paymentAction.xml";		
		Hashtable commands = parse(filename);
		for ( Enumeration e = commands.keys(); e.hasMoreElements(); ) {
			String key = (String) e.nextElement();	
			Hashtable h = (Hashtable) commands.get(key);
			//System.out.println(h);
			Hashtable action = (Hashtable) h.get("action");
			System.out.println((String) action.get("name"));
			Hashtable views = (Hashtable) h.get("views");
			System.out.println(views);
			System.out.println("main = " + (String) views.get("main"));

	
		}
	}
		

}
