/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal.action;

import java.util.Hashtable;
import javax.servlet.http.HttpSession;
import mecca.portal.ClassLoadManager;

import org.apache.velocity.Template;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
/* 
The Action List xml structure:

<actions>
    <command name="">
        <action name="mecca.test.TestAction1" />
        <view name="vtl/test/test1.vm" />
    </command>
    <command name="test1">
        <action name="mecca.test.TestAction1" />
        <view name="vtl/test/test1.vm" />
    </command>    
    <command name="test2">
        <action name="mecca.test.TestAction2" />
        <view name="vtl/test/test2.vm" />
    </command>
    
</actions>

*/ 
public class VActionTemplate extends mecca.portal.velocity.VTemplate  implements mecca.portal.Attributable{

	private String[] names = {"ActionList"};
	private Hashtable values = new Hashtable();
	
	public String[] getNames() {
		return names;
	}
	
	public Hashtable getValues() {
		return values;
	}  
	
	public void setValues(java.util.Hashtable hashtable) {
		values = hashtable;
	}
	
	/*
	for ( Enumeration e = commands.keys(); e.hasMoreElements(); ) {
		String key = (String) e.nextElement();	
		Hashtable h = (Hashtable) commands.get(key);
		String actionName = (String) h.get("action");
		String viewName = (String) h.get("view");
		System.out.println(key + " = " + actionName + ", " + viewName);	
	}
	*/	
			
	public Template doTemplate() throws Exception {
		String templateName = "";
		HttpSession session = request.getSession();
		String appPath = (String) session.getAttribute("_portal_app_path");
		String filename = (String) values.get(names[0]);
		//String fileSep = System.getProperty("file.separator");
		//filename = appPath + "WEB-INF" + fileSep + "actions" + fileSep + filename;
		filename = appPath.replace('\\', '/') + "WEB-INF" + "/" + "actions" + "/" + filename;;
		Hashtable commands = ActionParser.parse(filename);
		
		String command = getParam("command");
		Hashtable actions = (Hashtable) commands.get(command);
		String actionName = (String) actions.get("action");
		String viewName = (String) actions.get("view");
		
		ActionTemplate actionClass = (ActionTemplate) ClassLoadManager.load(actionName, request.getRequestedSessionId());
		actionClass.doAction(request, response, context);
		
		Template template = engine.getTemplate(viewName);	
		return template;		
	}
	
}