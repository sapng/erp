/* ************************************************************************
 * Copyright 2005 University ERP Project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal.action;

import java.io.FileReader;
import java.util.Hashtable;
import java.util.Vector;

import nanoxml.XMLElement;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1
 */

public class SubmitParser {
	public static Vector parse(String filename) throws Exception {
		Vector menuList = new Vector();
		FileReader reader = null;
		try {
			XMLElement menus = new XMLElement();
			reader = new FileReader(filename);
			menus.parseFromReader(reader);		
			
			XMLElement commands = null;
			Vector menu_child = menus.getChildren();
			for ( int i = 0; i < menu_child.size(); i++ ) {
				XMLElement menu = (XMLElement) menu_child.elementAt(i);	
				String name = (String) menu.getAttribute("name");
				Hashtable h = new Hashtable();
				h.put("name", name);
				menuList.addElement(h);
			}
	
			return menuList;
		} catch (Exception e) {
			//e.printStackTrace();
			throw e;
		} finally {
			if ( reader != null ) reader.close();
		}
	}
	
	public static void main(String[] args) throws Exception {
		String filename = "C:/eclipse/workspace2/university/WebContent/WEB-INF" + "/actions/sis/payment/paymentSubmit.xml";
		Vector menus = parse(filename);
		for ( int i=0; i < menus.size(); i++ ) {
			Hashtable h = (Hashtable) menus.elementAt(i);
			String name = (String) h.get("name");
			System.out.println(name);
		}
	}
}
