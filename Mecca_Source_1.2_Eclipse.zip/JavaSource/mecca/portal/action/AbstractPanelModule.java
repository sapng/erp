/* ************************************************************************
 * Copyright 2005 University ERP Project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal.action;

import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.portal.ClassLoadManager;

import org.apache.velocity.Template;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1
 */

public class AbstractPanelModule extends mecca.portal.velocity.VTemplate {
	
	protected String templateName;
	protected String menuFilename;
	protected String submitFilename;
	protected String actionFilename;
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		String appPath = (String) session.getAttribute("_portal_app_path");
		//System.out.println(appPath);
		String menuf = appPath.replace('\\', '/') + "WEB-INF" + "/actions" + menuFilename;
		String submitf = appPath.replace('\\', '/') + "WEB-INF" + "/actions" + submitFilename;
		String actionf = appPath.replace('\\', '/') + "WEB-INF" + "/" + "actions" + actionFilename;
		
		Vector menus = MenuParser.parse(menuf);	
		context.put("menus", menus);
		Vector submits = SubmitParser.parse(submitf);	
		context.put("submits", submits);		
		Hashtable commands = ActionParser2.parse(actionf);
		String command = getParam("command");
		Hashtable actions = (Hashtable) commands.get(command);

		if ( actions != null ) {
			Hashtable action = (Hashtable) actions.get("action");
			String actionName = (String) action.get("name");
			Hashtable views = (Hashtable) actions.get("views");
			String viewLeft = (String) views.get("left");
			String viewRight = (String) views.get("right");
			String viewMain = (String) views.get("main");		
			context.put("viewLeft", viewLeft);
			context.put("viewRight", viewRight);
			context.put("viewMain", viewMain);
			
			ActionTemplate actionClass = (ActionTemplate) ClassLoadManager.load(actionName, request.getRequestedSessionId());
			actionClass.doAction(request, response, context);	
		}
		else {
			//templateName = "vtl";
		}
		Template template = engine.getTemplate(templateName);	
		return template;	
	}


}
