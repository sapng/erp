/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal.element;

import java.io.Serializable;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class Module2 extends Module implements Serializable {
	private boolean isMarked = false;
	private String customTitle = "";
	private int col = 1;
	
	public Module2(String module_id, String module_title, String module_class, boolean b) {
		super(module_id, module_title, module_class);
		isMarked = b;
	}
	
	public Module2(String module_id, String module_title, String module_class, boolean b, String s) {
		super(module_id, module_title, module_class);
		isMarked = b;
		customTitle = s;
	}	
	
	public Module2(String module_id, String module_title, String module_class, String s) {
		super(module_id, module_title, module_class);
		customTitle = s;
	}	
	
	public Module2(String module_id, String module_title, String module_class, String s, int i) {
		super(module_id, module_title, module_class);
		customTitle = s;
		col = i;
	}	
	
	public boolean getMarked() {
		return isMarked;
	}
	
	public void setMarked(boolean b) {
		isMarked = b;
	}
	
	public String getCustomTitle() {
		return customTitle;
	}
	
	public void setCustomTitle(String s) {
		customTitle = s;
	}
	
	public void setColumn(int i) {
		col = i;
	}
	
	public int getColumn() {
		return col;
	}
}