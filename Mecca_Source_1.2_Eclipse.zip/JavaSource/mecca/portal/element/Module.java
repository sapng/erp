/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal.element;

import java.util.Vector;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class Module {
	private String module_id;
	private String module_title;
	private String module_class;
	private String module_group;
	private String module_description;
	private Vector roles = new Vector();
	
	public Module(String module_id, String module_title, String module_class) {
		this.module_id = module_id;
		this.module_title = module_title;
		this.module_class = module_class;
	}
	
	public void setGroupName(String s) {
		module_group = s;
	}
	
	public String getGroupName() {
		return module_group;
	}
	
	public void setDescription(String s) {
		module_description = s;
	}
	
	public String getDescription() {
		return module_description;
	}
	
	public String getId() {
		return module_id;
	}
	
	public String getTitle() {
		return module_title;
	}
	
	public String getClassName() {
		return module_class;
	}
	
	public void setRoles(Vector v) {
		this.roles = v;
	}
	
	public Vector getRoles() {
		return roles;
	}
	
	public void addRole(String role) {
		roles.addElement(role);
	}

}