/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.portal.db.PrepareModule;
import mecca.portal.element.Module2;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class Moduler extends mecca.portal.velocity.VTemplate {

	private Vector v;
	private int counter;
	
	public Moduler(VelocityEngine engine, VelocityContext context, HttpServletRequest req, HttpServletResponse res) {
		super(engine, context, req, res);
		try {
			prepareEnvironment();
		} catch ( Exception ex ) {
			//--MODIFY
			System.out.println(ex.getMessage());
		}
	}
	
	private void prepareEnvironment() throws Exception {
		HttpSession session = request.getSession();
		String usrlogin = (String) session.getAttribute("_portal_login");
		String action = (String) session.getAttribute("_portal_action");
		v = PrepareModule.retrieve(usrlogin, action);
		context.put("modules", v);			
	}
	
	public Template doTemplate() throws Exception {
		Template template = engine.getTemplate("vtl/main/moduler.vm");	
		return template;		
	}
	
	public Module2 getFirstModule() {
		if ( v != null && (v.size() > 0) ) return (Module2) v.elementAt(0);
		else return null;
	}
	
	public Module2 getModuleById(String module_id) {
		Module2 m = null;
		//had to iterate thru the vector
		for ( int i=0; i < v.size(); i++ ) {
			if ( module_id.equals( ((Module2) v.elementAt(i)).getId() ) ) {
				m = (Module2) v.elementAt(i);
				break;	
			}	
		}
		return m;	
	}
	
	public Module2 getModuleAt(int i) {
		return (Module2) v.elementAt(i);	
	}
	
	public int getModuleCount() {
		return v.size();
	}
	
	public Module2 getNext() {
		if ( counter < v.size() )
			return (Module2) v.elementAt(counter++);
		else
			return null;
	}
	
	public boolean hasMoreModules() {
		if ( counter < v.size() )
			return true;
		else
			return false;		
	}
	
	public Vector getModulesInColumn(int num) {
		Vector vm = new Vector();
		for (int i=0; i<v.size(); i++ ) {
			Module2 m = (Module2) v.elementAt(i);
			if ( m.getColumn() == num )	vm.addElement(m);
		}
		return vm;
	}
}