/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.db.DbException;
import mecca.portal.db.AuthenticateUser;
import mecca.portal.db.PrepareUser;
import mecca.portal.db.UserPage;
import mecca.portal.element.Tab;
import mecca.portal.velocity.VTemplate;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ControllerServlet extends mecca.portal.velocity.VServlet {

	private static long icnt = 0;

	public void doGet(HttpServletRequest req, HttpServletResponse res)  throws ServletException, IOException    {
		doPost(req, res);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException  {

		PrintWriter out = res.getWriter();
		HttpSession session = req.getSession();
		res.setContentType("text/html");

		/*
		if ( getx(2005, 2) ) {
			System.out.println("System Expired");
			out.println("<center>Your copy of portal system expired!!</center>");
			return;
		}
		*/

		//STORE VELOCITY ENGINE IN THE SESSION OBJECT
		if ( session.getAttribute("_VELOCITY_INITIALIZED") == null ) {
			session.setAttribute("_VELOCITY_ENGINE", engine);
			session.setAttribute("_VELOCITY_CONTEXT", context);
			session.setAttribute("_VELOCITY_INITIALIZED", "true");
		}

		//to handle browser's refresh that might trigger double submission
		//get previous token
		String prev_token = session.getAttribute("form_token") != null ? (String) session.getAttribute("form_token") : "";
		//get form token
		String form_token = req.getParameter("form_token") != null ? req.getParameter("form_token") : "empty";
		//pre_token equals form_token if not refresh

		if ( prev_token.equals(form_token) ) session.setAttribute("doPost", "true");
		else if ( "empty".equals(form_token) ) session.setAttribute("doPost", "true");
		else session.setAttribute("doPost", "false");
		//create a new form token
		form_token = Long.toString(System.currentTimeMillis());
		session.setAttribute("form_token", form_token);

		//end handle browser's refresh
		
        String app_path = getServletContext().getRealPath("/");
		/* NOTE:
		 * getServletContext().getRealPath("/") will return NULL if this application
		 * is deployed as WAR file.
		 * If you deploy war files without unzipping them in a directory yourself, 
		 * then the server isn't required to return a real path, 
		 * since there isn't really a real path. 
		 */        
        app_path = app_path != null ? app_path.replace('\\', '/') : "";
        
		session.setAttribute("_portal_app_path", app_path);

		String serverName = req.getServerName();
		int serverPort = req.getServerPort();
		session.setAttribute("_portal_server", serverPort != 80 ? serverName + ":" + serverPort : serverName );
		
		String reqUrl = req.getRequestURL().toString();
		String queryString = req.getQueryString();
		String portalReqUrl = reqUrl + "?" + queryString;
		session.setAttribute("_portal_reqUrl", portalReqUrl);
		String uri = req.getRequestURI();
		String s1 = uri.substring(1);
		context.put("appname", s1.substring(0, s1.indexOf("/")));
		session.setAttribute("_portal_appname", s1.substring(0, s1.indexOf("/")));
		//get pathinfo
        String pathInfo = req.getPathInfo();
        pathInfo = pathInfo.substring(1); //get rid of the first '/'
        session.setAttribute("_portal_pathInfo", pathInfo);
        //pathInfo only contains action
		String action = pathInfo != null ? pathInfo : "";

		//Set role to anonymous by default
		if ( session.getAttribute("_portal_role") == null || "".equals((String)session.getAttribute("_portal_role"))) {
			session.setAttribute("_portal_role", "anon");
			session.setAttribute("_portal_username", "Anonymous");
			session.setAttribute("_portal_login", "anon");
			session.setAttribute("_portal_islogin", "false");
			session.setAttribute("_portal_css", null);
			action = "";
		}

		//module
		String module = req.getParameter("_portal_module") != null ?
					    req.getParameter("_portal_module") : "";
		if ( session.getAttribute("_portal_module") != null )
			if ( (module == null) || ("".equals(module)) ) module = (String) session.getAttribute("_portal_module");


		//System.out.println("module=" + module);
		//------
		//To handles different visitors (for example: different languages )
		//------
		if ( session.getAttribute("_portal_visitorList") == null ) {
			Hashtable visitorList = new Hashtable();
			session.setAttribute("_portal_visitorList", visitorList);
			context.put("portalVisitorList", visitorList);
		} else {
			Hashtable visitorList = (Hashtable) session.getAttribute("_portal_visitorList");
			context.put("portalVisitorList", visitorList);
		}


		if ( "anon".equals((String) session.getAttribute("_portal_role"))
		&& "false".equals((String) session.getAttribute("_portal_islogin"))	)
		{
			String visitor = req.getParameter("visitor") != null ?
							 req.getParameter("visitor") :
							 session.getAttribute("_portal_visitor") != null ?
							 (String) session.getAttribute("_portal_visitor") : "anon";
			//this visitor user login must be of role anon
			if ( !"anon".equals(visitor) && "anon".equals(PrepareUser.getRole(visitor)) ) {
				session.setAttribute("_portal_login", visitor);
			}
			else {
				visitor = "anon";
				session.setAttribute("_portal_login", "anon");
			}

			session.setAttribute("_portal_visitor", visitor);

			//System.out.println("action=" + action);

			if ( req.getParameter("visitor") != null && !"login".equals(action) ) {
				action = "";
			}
		}
		//---
		session.setAttribute("_portal_action", action);
		session.setAttribute("_portal_module", module);
		context.put("session", session);

		//CSS
		String css = "default.css";
		try {
			if ( req.getParameter("visitor") != null ) {
				css = UserPage.getCSS((String) session.getAttribute("_portal_login") );
			}
			else {
				css = session.getAttribute("_portal_css") != null ?
				(String) session.getAttribute("_portal_css") :
				UserPage.getCSS((String) session.getAttribute("_portal_login") );
			}
		} catch ( DbException cssex ) {
			//Log.print("Error getting CSS: " + cssex.getMessage());
		}
		session.setAttribute("_portal_css", css);

		//To store content template
		VTemplate content = null;

		out.println("<html>");
		out.println("<title>");

		//TITLE
		Title cTitle = new Title(engine, context, req, res);
		try {
			cTitle.print();
		} catch ( Exception ex ) {
			out.println(ex.getMessage());
		}

		out.println("</title>");
		out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/" + css + "\" />");
		out.println("<body topmargin=\"0\" leftmargin=\"0\">");

		out.println("<div align=\"center\">");

		out.println("<table class=\"container\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">");

		//Handle login request
		if ( action.equalsIgnoreCase("login") ) {
			String usrlogin = req.getParameter("username");
			String password = req.getParameter("password");
			//System.out.println("authenticate = " + usrlogin + ", " + password);
			try {
				AuthenticateUser auth = new AuthenticateUser(req);
				if ( auth.lookup(usrlogin, password) ) {
					session.setAttribute("_portal_role", auth.getRole());
					session.setAttribute("_portal_username", auth.getUserName());
					//session.setAttribute("_portal_login", usrlogin);
					session.setAttribute("_portal_login", auth.getUserLogin());
					session.setAttribute("_portal_islogin", "true");

					//CSS
					try {
						css = UserPage.getCSS((String) session.getAttribute("_portal_login") );
						session.setAttribute("_portal_css", css);
					} catch ( DbException cssex ) {
						//Log.print("Error getting CSS: " + cssex.getMessage());
					}
					//System.out.println("authentication ok");
					res.sendRedirect("");
				} else {
					session.setAttribute("_portal_role", "anon");
					session.setAttribute("_portal_username", "Anonymous");
					session.setAttribute("_portal_login", "anon");
					session.setAttribute("_portal_islogin", "false");
					res.sendRedirect("../accessdenied.jsp");
				}
			} catch ( Exception ex ) {
				content = new ErrorMsg(engine, context, req, res);
				((ErrorMsg) content).setError(ex.getMessage());
			}
		}
		else if ( action.equalsIgnoreCase("logout") ) {
			//this jsp page will invalidate the session object
			res.sendRedirect("../logout1.jsp");
		}

		//TODO
		//what if user has logout but press the browser's back button
		String islogin = (String) session.getAttribute("_portal_islogin");

		//--

		//Initiate VTemplate objects
		Header cHeader = new Header(engine, context, req, res);

		//HEADER
		out.println("<tr><td>");
		try {
			cHeader.print();
		} catch ( Exception ex ) {
			out.println(ex.getMessage());
		}
		out.println("</td></tr>");

		if ( "customize".equalsIgnoreCase(action) && "true".equals(islogin) ) {
			//CUSTOMIZE MODULE

			out.println("<tr><td>");
			out.println("<table width=\"100%\" cellpadding=\"1\" cellspacing=\"1\" border=\"0\">");
			out.println("<tr><td bgcolor=\"silver\">");
			out.println("<b>Personalization</b>");
			out.println("</td></tr></table>");
			out.println("</td></tr>");
			out.println("<tr><td>");

			Customize cCustomize = new Customize(engine, context, req, res);
			try {
				cCustomize.print();
			} catch ( Exception ex ) {
				out.println( ex.getMessage() );
			}

			out.println("</td></tr>");

			//UPDATE THEME
		}
		else if ( "pagetheme".equalsIgnoreCase(action)  && "true".equals(islogin) ) {
			out.println("<tr><td>");
			out.println("<table width=\"100%\" cellpadding=\"1\" cellspacing=\"1\" border=\"0\">");
			out.println("<tr><td bgcolor=\"silver\">");
			out.println("<b>Personalization</b>");
			out.println("</td></tr></table>");
			out.println("</td></tr>");
			out.println("<tr><td>");
			mecca.app.UpdatePageStyleModule pageStyle = new mecca.app.UpdatePageStyleModule(engine, context, req, res);
			try {
				pageStyle.print();
			} catch ( Exception ex ) {
				out.println( ex.getMessage() );
			}


			out.println("</td></tr>");
		}
		else  {
			Tabber cTabber = null;
			cTabber = new Tabber(engine, context, req, res);

			//If no request for action (tab), open the first tab by default
			if ( "".equals(action) ) {
				Tab firstTab = cTabber.getFirstTab();
				if ( firstTab != null )  action = firstTab.getId();
				session.setAttribute("_portal_action", action);
				//System.out.println("first action =" + action);
			}

			//TABBER
			out.println("<tr><td>");
			try {
				if ( cTabber != null ) cTabber.print();
			} catch ( Exception ex ) {
				out.println(ex.getMessage());
			}
			out.println("</td></tr>");

			//determine how to display the page
			//TODO: need to add more display types
			try {
				//get display type, and display the page
				String usrlogin = (String) session.getAttribute("_portal_login");
				String display_type = UserPage.getDisplayType(usrlogin, action);
				if ( "left_navigation".equals(display_type) )
					DisplayContent.showNavigationType(engine, context, getServletConfig(), req, res, module, out, session);
				else if ( "single_column".equals(display_type) )
					DisplayContent.showModularType(engine, context, getServletConfig(), req, res, module, out, session);
				else if ( "narrow_wide".equals(display_type) )
					DisplayContent.showNarrowWideType(engine, context, getServletConfig(), req, res, module, out, session);
				else if ( "two_columns".equals(display_type) )
					DisplayContent.showTwoColumnsType(engine, context, getServletConfig(), req, res, module, out, session);
				else if ( "three_columns".equals(display_type) )
					DisplayContent.showThreeColumnsType(engine, context, getServletConfig(), req, res, module, out, session);
				else
					DisplayContent.showNavigationType(engine, context, getServletConfig(), req, res, module, out, session);
			} catch ( Exception ex ) {
				out.println( ex.getMessage() );
			} finally {
				//long totalMem = Runtime.getRuntime().totalMemory();
				//long freeMem = Runtime.getRuntime().freeMemory();
				//System.gc();
				//icnt++;
				//System.out.println(icnt + ") free memory = " + freeMem + "/" + totalMem);
			}
		}


		//FOOTER
		//Initiate VTemplate object
		Footer cFooter = new Footer(engine, context, req, res);
		out.println("<tr><td>");
		try {
			cFooter.print();
		} catch ( Exception ex ) {
			out.println( ex.getMessage() );
		}
		out.println("</td></tr>");

		out.println("</table>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	}

	private void showError(String err, HttpServletRequest req, HttpServletResponse res) {
		ErrorMsg emsg = new ErrorMsg(engine, context, req, res);
		emsg.setError(err);
		try {
			emsg.print();
		} catch ( Exception ex ) {
			//error while displaying error!!
			System.out.println("ERROR WHILE SHOW ERROR");
		}
	}

	private static boolean getx(int y, int m) {
		java.util.Calendar calendar = java.util.Calendar.getInstance();
		calendar.set(y, m-1, 1);
		long expireMillis = calendar.getTime().getTime();
		long currentMillis = System.currentTimeMillis();
		return expireMillis < currentMillis;
	}
}
