/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal;

import java.util.Hashtable;

public class ClassLoadManager {
	
	static Hashtable loadedList = new Hashtable();

	public static Object load(String className, String cacheId) throws Exception {
		Object object = null;
		String id = className + cacheId;
		//find if this name exists in the cache
		object = loadedList.get(id);
		//if not load it   
		if ( object == null ) {
			//Class klazz = Class.forName(className);
			Thread t = Thread.currentThread();
			ClassLoader cl = t.getContextClassLoader();
			Class klazz = cl.loadClass(className);			
			object = klazz.newInstance();	
			//put into cache  
			loadedList.put(id, object);
			//System.out.println(className + " was put into cache =" + cacheId);
		}
		else {
			//System.out.println(className + " GET FROM CACHE = " + cacheId);	
		}
		return object; 
	}
}