/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal;

import java.util.Vector;

import mecca.portal.db.CustomClass;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ClassValidator {
	
	private String objectType = "";
	private String errMessage = "";
	private String[] attributes;
	private Object content;
	private Vector types = new Vector();
	
	//check whether the class exist
	//NOTE: the class must be the type of VTemplate
	//type is the special type
	public boolean validateClass(String module) {
		try {
			//load the class
			Class klazz = Class.forName(CustomClass.getName(module));
			//instantiate
			content = klazz.newInstance();			
			
			//content is HtmlContainer and RSSContainer
			if ( content instanceof HtmlContainer ) {
				objectType = "html_container";  //will be deprecated
				types.addElement("html_container");
			} 
			if ( content instanceof XMLContainer ) {
				objectType = "xml_container";	//will be deprecated
				types.addElement("xml_container");
			} 
			if ( content instanceof Attributable ) {
				objectType = "attributable"; // will be deprecated
				types.addElement("attributable");
				attributes = ((Attributable) content).getNames();
			} 
			//db.Log.print("validate class: type = " + objectType);
			return true;
		} catch ( ClassNotFoundException cnfex ) {
			errMessage = "ClassNotFoundException: " + cnfex.getMessage();
		} catch ( InstantiationException iex ) {
			errMessage = "InstantiationException: " + iex.getMessage();
		} catch ( IllegalAccessException illex ) {
			errMessage = "IllegalAccessException: " + illex.getMessage();
		} catch ( Exception ex ) {
			errMessage = "Exception: " + ex.getMessage();
		}	
		return false;		
	}		 
	
	//should be deprecated
	public String getObjectType() {
		return objectType;
	}

	
	public String getErrorMessage() {
		return errMessage;
	}
	
	public String[] getAttributes() {
		return attributes;
	}
	
	public Object getContent() {
		return content;
	}
	
	public Vector getTypes() {
		return types;
	}
}