/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal.velocity;

import java.io.PrintWriter;
import java.io.StringWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public abstract class VTemplate extends javax.servlet.http.HttpServlet {
	
	protected VelocityEngine engine;
	protected VelocityContext context;
	protected HttpServletRequest request;
	protected HttpServletResponse response;
	protected ServletContext servletContext;
	protected ServletConfig servletConfig;	
	protected String id = "";
	
	protected String templateName = "";
	protected boolean showVM = false;
	
	protected VTemplate() {
		
	}
	
	protected VTemplate(VelocityEngine engine, VelocityContext context, HttpServletRequest request, HttpServletResponse response) {
		this.engine = engine;
		this.context = context;
		this.request = request;
		this.response = response;
	}
	
	public void setEnvironment(VelocityEngine engine, VelocityContext context, HttpServletRequest request, HttpServletResponse response) {
		this.engine = engine;
		this.context = context;
		this.request = request;
		this.response = response;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getId() {
		return id;
	}
	
	public void setServletContext(ServletContext ctx ) {
		this.servletContext = ctx;
	}
	
	
	//protected ServletContext getServletContext() {
	//	return servletContext;
	//}
	
	public void setServletConfig(ServletConfig cfg ) {
		this.servletConfig = cfg;
	} 
	
	public ServletConfig getServletConfig() {
		return servletConfig;
	}	
	
	//public abstract Template doTemplate() throws Exception;  //remove abstract
	public Template doTemplate() throws Exception {
		//subclass need to implement body
		return null;	
	}
	
	public StringBuffer getBuffer() throws Exception {
		StringBuffer sb = new StringBuffer("");
		try {
			Template template = doTemplate();
			templateName = template.getName();
			StringWriter writer = new StringWriter();
			template.merge(context, writer);
			writer.close();
			sb = writer.getBuffer();
		} catch ( Exception ex ) {
			//System.out.println("Error = " + ex.getMessage());
		    ex.printStackTrace();
			throw ex;			
		}
		return sb;
	}	
	
	public void setShowVM(boolean b) {
		showVM = b;
	}
	

	//public void print() throws Exception {
	//	print(false);
	//}

	//show not used anymore
	/*
	public void print(boolean show) throws Exception {
		PrintWriter out = response.getWriter();
		out.print(getBuffer());
		show = showVM; //showVM will override show		
		if ( show ) {
			out.print("<br/><table width=\"100%\"><tr><td align=\"right\"><font size=\"1\">");
			out.print(templateName);
			out.print("</font></tr></td></table>");
		}
	}
	*/
	
	public void print() throws Exception {
		PrintWriter out = response.getWriter();
		out.print(getBuffer());	
		if ( showVM ) {
			out.print("<br/><table width=\"100%\"><tr><td align=\"right\"><font size=\"1\">");
			out.print(templateName);
			out.print("</font></tr></td></table>");
		}
	}	

	
	//a handy method for getParameter
	protected String getParam(String param) {
		return request.getParameter(param) != null ? request.getParameter(param) : "";
	}	
	protected int getParamAsInteger(String param) {
		return getParam(param) != "" ? Integer.parseInt(getParam(param)) : 0;	 
	}
	
	protected boolean post(HttpSession session) {
		return session.getAttribute("doPost") != null ?
			"true".equals((String) session.getAttribute("doPost")) ? true : false : true;
	}
	protected String getParam(HttpServletRequest request, String param) {
		return request.getParameter(param) != null ? request.getParameter(param) : "";
	}	
}