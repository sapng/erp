/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal;

import java.io.ByteArrayInputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.PropertyResourceBundle;

import javax.portlet.PortletConfig;
import javax.portlet.PortletContext;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class MerakConfig implements PortletConfig {
	
	protected String portletName;
	protected PortletContext portletContext;
	protected java.util.ResourceBundle resourceBundle;
	protected String initParameter;
	protected Enumeration initParameterNames;
	protected Hashtable parameters;
	protected PortletInfo portletInfo;

  	public String getPortletName () {
		return portletName; 	
  	}

  	public PortletContext getPortletContext () {
	  	return portletContext;
  	}

  	public java.util.ResourceBundle getResourceBundle(java.util.Locale locale) {
	  	//System.out.println("potletinfo title=" + portletInfo.title);
	  	if ( portletInfo == null ) {
		  	System.out.println("WARNING!! portletInfo reference to NULL.");
	  	}
	  	if ( resourceBundle == null ) {
		  	StringBuffer sb = new StringBuffer();
			try {
				sb.append("javax.portlet.title");
				sb.append("=");
				sb.append(portletInfo.title);
				sb.append("\n");
				resourceBundle = new PropertyResourceBundle(new ByteArrayInputStream(sb.toString().getBytes()));
			}
			catch (Exception e) {
				e.printStackTrace();
			}		  	
		  	 
	  	}
	  	return resourceBundle;
  	}

  	public String getInitParameter(java.lang.String name) {
	  	return (String) parameters.get(name);
  	}

  	public java.util.Enumeration getInitParameterNames() {
	  	return initParameterNames;
  	}
  	
  	//not JSR method
  	public String getId() {
		return portletInfo.id;  	
  	}
}

