/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;

import mecca.db.Db;
import mecca.db.DbException;
import mecca.db.SQLRenderer;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class AuthenticateUser {
	private String role;
	private String userLogin;
	private String userName;
	private boolean allowed;
	HttpServletRequest req;	 
	
	public AuthenticateUser(HttpServletRequest req) {
		this.req = req;
	}	
	public boolean lookup(String username, String password) throws  Exception {
		Db db = null;
		Connection conn = null;
		String sql = ""; 
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			//POSSIBLE SQL INJECTION CHECK
			/*
			username = ' or user_login like '%
			password =' or user_password like '%
			*/
			
			//LOG THIS LOGIN ACTIVITY
			UserLogger.save(req, username);
			
			if (  ( username.toUpperCase().indexOf(" OR ") > 0 ) || ( password.toUpperCase().indexOf(" OR ") > 0 ) ) {
				System.out.println("[ALERT]: POSSIBLE SQL INJECTION ");
				System.out.println("username = " + username);
				System.out.println("password = " + password);
				UserLogger.save(req, "ALERT!!" + username + ", " + password);
				return false;
			}			
			
			SQLRenderer r = new SQLRenderer();
			{
				r.add("user_role");
				r.add("user_name");
				r.add("user_login", username);
				//encrypt the given password before add into argument
				r.add("user_password", mecca.util.PasswordService.encrypt(password));
				
				sql = r.getSQLSelect("users");
				ResultSet rs = stmt.executeQuery(sql);
				
				if ( rs.next() ) {
					role = rs.getString("user_role");
					userName = rs.getString("user_name");
					userLogin = username;
					allowed = true;
				}
			}
			
			if ( !allowed ){
			    r.clear();
				r.add("user_role");
				r.add("user_name");
				r.add("user_login");
				r.add("user_login_alt", username);
				//encrypt the given password before add into argument
				r.add("user_password", mecca.util.PasswordService.encrypt(password));
				
				sql = r.getSQLSelect("users");
				ResultSet rs = stmt.executeQuery(sql);
				
				//System.out.println(sql);
				
				if ( rs.next() ) {
					role = rs.getString("user_role");
					userName = rs.getString("user_name");
					userLogin = rs.getString("user_login");
					allowed = true;
				}
			}			
		} catch ( SQLException ex ) {
			//throw new DbException(ex.getMessage() + ": " + sql);
		    System.out.println(ex.getMessage() + ": " + sql);
		    allowed = false;
		} finally {
			if ( db != null ) db.close();
		}
		return allowed;
	}
	
	public String getRole() {
		return role;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public String getUserLogin() {
		return userLogin;
	}	
	
	public boolean getAllowed() {
		return allowed;
	}
}