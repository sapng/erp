/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import mecca.db.Db;
import mecca.db.DbException;
import mecca.db.SQLRenderer;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class CustomClass {
	public static String getName(String module) throws DbException {
		Db db = null;
		Connection conn = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			SQLRenderer r = new SQLRenderer();
			r.add("module_class");
			r.add("module_id", module);
			
			sql = r.getSQLSelect("module");
			ResultSet rs = stmt.executeQuery(sql);
			
			if ( rs.next() ) {
				String name = rs.getString("module_class");
				//System.out.println("getting content = " + name);
				return name;
			}
			else return null;
		} catch ( SQLException ex ) {
			throw new DbException(ex.getMessage() + ": " + sql);
		} finally {
			if ( db != null ) db.close();
		}
	}
	
    public static String getCustomTitle (String moduleId) throws DbException
    {
        Db db = null;
        Connection conn = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            
            SQLRenderer r = new SQLRenderer();
            r.add("module_title");
            r.add("module_id", moduleId);
            
            sql = r.getSQLSelect("module");
            ResultSet rs = stmt.executeQuery(sql);
            
            if ( rs.next() ) {
                String name = rs.getString("module_title");
                //System.out.println("getting content = " + name);
                return name;
            }
            else return null;
        } catch ( SQLException ex ) {
            throw new DbException(ex.getMessage() + ": " + sql);
        } finally {
            if ( db != null ) db.close();
        }
    }
    
	/*
	public static String getFirstModuleClassName(String usrlogin, String tab) throws DbException {
		Db db = null;
		Connection conn = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			sql = "SELECT m.module_id, m.module_title, m.module_class " +
			"FROM module m, user_module u " +
			"WHERE m.module_id = u.module_id " +
			"AND u.user_login = '" + usrlogin + "' " +
			"AND u.tab_id = '" + tab + "'";			
			
				
	}
	*/
	
}