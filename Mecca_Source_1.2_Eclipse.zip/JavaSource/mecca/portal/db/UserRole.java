/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal.db;

import java.util.Hashtable;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class UserRole {
	public static final String ROOT = "root"; //Root user
	public static final String ADMIN = "admin"; //Administrator user
	public static final String USER = "user"; //Registered portal's user
	public static final String TEACHER = "teacher"; //Registered portal's user
	public static final String STUDENT = "student"; //Registered portal's user
	public static final String ANON = "anon"; //Anonymous user as guest
	
	public static String[] roles = {ANON, STUDENT, TEACHER, USER, ADMIN, ROOT};
	public static String[] roleDescription = {	"Anonymous users (not registered or as guest to portal)",
															"Student",
															"Teacher",
															"Registered users",
															"Administrator users",
															"Root users"
														};
														
	public static Hashtable tbRoles = new Hashtable();
	static {
		for ( int i=0; i < roles.length; i++ ) {
			tbRoles.put(roles[i], roleDescription[i]);	
		}	
	}
	
	public static Hashtable getTbRoles() {
		return tbRoles;	
	}
}