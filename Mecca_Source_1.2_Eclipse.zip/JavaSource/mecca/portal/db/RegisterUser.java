/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mecca.db.Db;
import mecca.db.DbException;
import mecca.db.Log;
import mecca.db.SQLRenderer;
import mecca.portal.element.PageTheme;
import mecca.sis.billing.BillingData;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */

public class RegisterUser {
    public static boolean add(String fullname, String username, String password, String role, String style) throws Exception {
        Db db = null;
        Connection conn = null;
        String sql = "";
        try {
            db = new Db();
            conn = db.getConnection();
            Statement stmt = db.getStatement();
            
            conn.setAutoCommit(false);
            SQLRenderer r = new SQLRenderer();
            {
	            r.add("user_login");
	            r.add("user_login", username);
	            sql = r.getSQLSelect("users");
	
	            ResultSet rs = stmt.executeQuery(sql);
	            
	            //Return FALSE if username already exist
	            if ( rs.next() && ( username.equalsIgnoreCase(rs.getString("user_login")) ) ) return false;
            }
            
            {
	            r.add("user_login_alt");
	            r.add("user_login_alt", username);
	            sql = r.getSQLSelect("users");
	
	            ResultSet rs = stmt.executeQuery(sql);
	            
	            //Return FALSE if username already exist
	            if ( rs.next() && ( username.equalsIgnoreCase(rs.getString("user_login_alt")) ) ) return false;
            }            
            
            {
	            r.clear();
	            r.add("user_login", username);
	            r.add("user_password", mecca.util.PasswordService.encrypt(password));
	            r.add("user_name", fullname);
	            r.add("user_role", role);
	            sql = r.getSQLInsert("users");
	            stmt.executeUpdate(sql);
	            
	            setUserModule(username, role);
	            setPageStyle(username, style);
            }
            
            conn.commit();
        } catch ( SQLException ex ) {
            try {
                conn.rollback();
            } catch ( SQLException ex2 ) {}
            Log.print( ex.getMessage() + "\n" + sql);
            return false;
        } finally {
            if ( db != null ) db.close();
        }   
        return true;
    }
    
    public static boolean update2(String fullname, String username, String password, String role) throws Exception {
        Db db = null;
        Connection conn = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            r.add("user_name", fullname);
            r.add("user_password", mecca.util.PasswordService.encrypt(password));
            r.add("user_role", role);
            r.update("user_login", username);   
            sql = r.getSQLUpdate("users");
            int num = stmt.executeUpdate(sql);
            if ( num > 0 ) return true;
            else return false;
        } catch ( SQLException ex ) {
            Log.print( ex.getMessage() + "\n" + sql);
        } finally {
            if ( db != null ) db.close();
        }   
        return false;
    }
    
    public static boolean update(String fullname, String username, String login_alt) throws Exception {
        Db db = null;
        Connection conn = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            boolean isExist = false;
            if ( !login_alt.equals(username)){
                {
                    r.clear();
                    r.add("user_login");
                    r.add("user_login", login_alt);
                    sql = r.getSQLSelect("users");
                    ResultSet rs = stmt.executeQuery(sql);
                    if ( rs.next() ) isExist = true;
                }
                
            }
            if ( !isExist ){
	            r.clear();
                r.add("user_name", fullname);
	            r.add("user_login_alt", login_alt);
	            r.update("user_login", username);   
	            sql = r.getSQLUpdate("users");
	            int num = stmt.executeUpdate(sql);
	            if ( num > 0 ) return true;
	            else return false;
            }
        } catch ( SQLException ex ) {
            Log.print( ex.getMessage() + "\n" + sql);
        } finally {
            if ( db != null ) db.close();
        }   
        return false;
    }     
    
    public static boolean update(String fullname, String username, String password, String login_alt) throws Exception {
        Db db = null;
        Connection conn = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            boolean isExist = false;
            if ( !login_alt.equals(username)){
                {
                    r.clear();
                    r.add("user_login");
                    r.add("user_login", login_alt);
                    sql = r.getSQLSelect("users");
                    ResultSet rs = stmt.executeQuery(sql);
                    if ( rs.next() ) isExist = true;
                }
                
            }
            if ( !isExist ){
	            r.clear();
                r.add("user_name", fullname);
	            r.add("user_password", mecca.util.PasswordService.encrypt(password));
	            r.add("user_login_alt", login_alt);
	            r.update("user_login", username);   
	            sql = r.getSQLUpdate("users");
	            int num = stmt.executeUpdate(sql);
	            if ( num > 0 ) return true;
	            else return false;
            }
        } catch ( SQLException ex ) {
            Log.print( ex.getMessage() + "\n" + sql);
        } finally {
            if ( db != null ) db.close();
        }   
        return false;
    }     
    
    public static boolean update(String fullname, String username, String password, String role, String login_alt) throws Exception {
        Db db = null;
        Connection conn = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            boolean isExist = false;
            if ( !login_alt.equals(username)){
                {
                    r.clear();
                    r.add("user_login");
                    r.add("user_login", login_alt);
                    sql = r.getSQLSelect("users");
                    ResultSet rs = stmt.executeQuery(sql);
                    if ( rs.next() ) isExist = true;
                }
                
            }
            if ( !isExist ){
	            r.clear();
                r.add("user_name", fullname);
	            r.add("user_password", mecca.util.PasswordService.encrypt(password));
	            r.add("user_role", role);
	            r.add("user_login_alt", login_alt);
	            r.update("user_login", username);   
	            sql = r.getSQLUpdate("users");
	            int num = stmt.executeUpdate(sql);
	            if ( num > 0 ) return true;
	            else return false;
            }
        } catch ( SQLException ex ) {
            Log.print( ex.getMessage() + "\n" + sql);
        } finally {
            if ( db != null ) db.close();
        }   
        return false;
    }    
    
    public static boolean update(String fullname, String username, String password, String role, String curRole, String style) throws Exception {
        Db db = null;
        Connection conn = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            SQLRenderer r = new SQLRenderer();
            r.add("user_name", fullname);
            r.add("user_password", mecca.util.PasswordService.encrypt(password));
            r.add("user_role", role);
            r.update("user_login", username);   
            sql = r.getSQLUpdate("users");
            int num = stmt.executeUpdate(sql);
                        
            if ( !"".equals(style) ) setPageStyle(username, style);
            
            if ( num > 0 )
            {
                setUserModule(username, role);
                return true;
            } else {
                return false;
            }
            
        } catch ( SQLException ex ) {
            Log.print( ex.getMessage() + "\n" + sql);
        } finally {
            if ( db != null ) db.close();
        }   
        return false;
    }
    
    
    public static void delete(String usrlogin) throws DbException {
        Db db = null;
        Connection conn = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            conn = db.getConnection();
            
            conn.setAutoCommit(false);
            

            //delete from user_module
            sql = "DELETE FROM users_module WHERE user_login = '" + usrlogin + "'";
            stmt.executeUpdate(sql);
            
            //delete from user
            sql = "DELETE FROM users WHERE user_login = '" + usrlogin + "'";
            stmt.executeUpdate(sql);
            
            conn.commit();
            
        } catch ( SQLException ex ) {
            try {
                conn.rollback();
            } catch ( SQLException exr ) {}
            throw new DbException(ex.getMessage() + ": " + sql);
        } finally {
            if ( db != null ) db.close();
        }
    }
    
    public static void setUserModule(String[] usrlogins, String role) throws Exception
    {
        for (int i = 0; i < usrlogins.length; i++)
        {
            setUserModule(usrlogins[i],role);
        }       
    }
    
    public static void setUserModule(String usrlogin, String role) throws Exception
    {
        //System.out.println("setUserModule("+usrlogin+","+role+")");
        Db db = null;
        Connection conn = null;
        String sql = "";
        //boolean flag = false;
        try
        {
            db = new Db();
            Statement stmt = db.getStatement();
            conn = db.getConnection();            
            conn.setAutoCommit(false);
            
            //delete user tabs from table tab
            sql = "DELETE FROM tab WHERE user_login = '" + usrlogin + "'";
            stmt.executeUpdate(sql);
            
            //delete user modules from table user_module
            sql = "DELETE FROM user_module WHERE user_login = '" + usrlogin + "'";
            stmt.executeUpdate(sql);
            
            //select tab for this role from table tab_template
            //and than insert them into table tab for this usrlogin
            SQLRenderer r = new SQLRenderer();
            {
	            r.add("tab_id");
	            r.add("tab_title");
	            r.add("sequence");
	            r.add("display_type");
	            r.add("user_login", role);
	            sql = r.getSQLSelect("tab_template");
	            
	            ResultSet rs = stmt.executeQuery(sql);
				
	            Vector tabs = new Vector();            
	            while (rs.next())
	            {
		            Hashtable h = new Hashtable();
	                h.put("tab_id", rs.getString("tab_id"));
	                h.put("tab_title", rs.getString("tab_title"));
	                h.put("sequence", new Integer(rs.getInt("sequence")));
	                h.put("display_type", rs.getString("display_type"));
	                h.put("user_login", usrlogin);
	                tabs.addElement(h);
	            }
	            
	
	            for ( int i=0; i < tabs.size(); i++ )
	            {
		            
		            Hashtable h = (Hashtable) tabs.elementAt(i);
		            r.clear();
	                r.add("tab_id", (String) h.get("tab_id"));
	                r.add("tab_title", (String) h.get("tab_title"));
	                r.add("sequence", ((Integer) h.get("sequence")).intValue());
	                r.add("display_type", (String) h.get("display_type"));
	                r.add("user_login", usrlogin);
	                sql = r.getSQLInsert("tab");
	                stmt.executeUpdate(sql);
	            }
            }
                        
        	{

	            //select modules for this role from table user_module_template
	            //and insert them into table user_module for this usrlogin
	            r.clear();
	            r.add("tab_id");
	            r.add("module_id");
	            r.add("sequence");
	            r.add("module_custom_title");
	            r.add("column_number");
	            r.add("user_login", role);
	            sql = r.getSQLSelect("user_module_template");
	      		      
	            ResultSet rs = stmt.executeQuery(sql);
	            Vector modules = new Vector();
	            while (rs.next())
	            {
		            int sequence = 1;
		            String seq = rs.getString("sequence") != null ? rs.getString("sequence") : "1";
		            if ( seq != null && !"".equals(seq) ) sequence = Integer.parseInt(seq);
		            
		            int colnum = 1;
		            String col = rs.getString("column_number") != null ? rs.getString("column_number") : "0";
		            if ( col != null && !"".equals(col) ) colnum = Integer.parseInt(col);
		            
	                Hashtable h = new Hashtable();
	                h.put("tab_id", rs.getString("tab_id"));
	                h.put("module_id", rs.getString("module_id"));
	                h.put("sequence", new Integer(sequence));
	                h.put("module_custom_title", Db.getString(rs, "module_custom_title"));
	                h.put("column_number", new Integer(colnum));
	                h.put("user_login", usrlogin);
	                
	                modules.addElement(h);
	            }
	            
	            for ( int i=0; i < modules.size(); i++ )
	            {
		            Hashtable h = (Hashtable) modules.elementAt(i);
	                r.clear();
	                r.add("tab_id", (String) h.get("tab_id"));
	                r.add("module_id", (String) h.get("module_id"));
	                r.add("sequence", ((Integer) h.get("sequence")).intValue());
	                r.add("module_custom_title", (String) h.get("module_custom_title"));
	                r.add("column_number", ((Integer) h.get("column_number")).intValue());
	                r.add("user_login", usrlogin);
	                sql = r.getSQLInsert("user_module");
	                
	                stmt.executeUpdate(sql);
	            }
        	}
            
            conn.commit();
            //flag = true;
        }
        catch ( SQLException ex )
        {
            //flag = false;
            try
            {
                conn.rollback();
            }
            catch ( SQLException exr ) {}
            throw new DbException(ex.getMessage() + ": " + sql);
        }
        finally
        {
            if ( db != null ) db.close();
            //return flag;
        }
    }
    
    public static Vector getPageStyles() throws DbException
    {
        Db db = null;
        Connection conn = null;
        String sql = "";
        Vector list = new Vector();
        try
        {
            db = new Db();
            Statement stmt = db.getStatement();
            conn = db.getConnection();            
            
            SQLRenderer r = new SQLRenderer();
            r.add("css_title");
            r.add("css_name");
            sql = r.getSQLSelect("page_css");
            
            ResultSet rs = stmt.executeQuery(sql);
            PageTheme css = null;
            while (rs.next())
            {
                css = new PageTheme(rs.getString("css_name"), rs.getString("css_title"));
                list.addElement(css);
            }
        }
        catch ( SQLException ex )
        {
            throw new DbException(ex.getMessage() + ": " + sql);
        }
        finally
        {
            if ( db != null ) db.close();
        }
        return list;        
    }
    
    private static void setPageStyle(String usrlogin, String style) throws DbException
    {
        Db db = null;
        Connection conn = null;
        String sql = "";
        try
        {
            db = new Db();
            Statement stmt = db.getStatement();
            conn = db.getConnection();            
            conn.setAutoCommit(false);
            
            sql = "delete from user_css where user_login = '"+usrlogin+"'";
            stmt.executeUpdate(sql);
            
            SQLRenderer r = new SQLRenderer();
            r.add("user_login", usrlogin);
            r.add("css_name", style);
            sql = r.getSQLInsert("user_css");            
            stmt.executeUpdate(sql);
            
            conn.commit();
        }
        catch ( SQLException ex )
        {
            try
            {
                conn.rollback();
            }
            catch ( SQLException exr ) {}
            throw new DbException(ex.getMessage() + ": " + sql);
        }
        finally
        {
            if ( db != null ) db.close();
        }
    }
    
    public static void saveUserInfo(Hashtable info) throws Exception {
        Db db = null;
        String sql = "";
        try {
            db = new Db();
            Statement stmt = db.getStatement();
            
        } finally {
            if ( db != null ) db.close();
        }
    }
    

}



