/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.portal.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import mecca.db.Db;
import mecca.db.DbException;
import mecca.db.SQLRenderer;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class RegisterModule {
	
	public static boolean add(String module_id, String module_title, String module_class, String module_group, String module_description) throws DbException {
		return add(module_id, module_title, module_class, module_group, module_description, null);	
	}
	
	public static boolean add(String module_id, String module_title, String module_class, String module_group, String module_description, String[] roles) throws DbException {
		Db db = null;
		Connection conn = null;
		String sql = "";
		try { 
			db = new Db();
			conn = db.getConnection();
			Statement stmt = db.getStatement();
			
			conn.setAutoCommit(false);
			SQLRenderer r = new SQLRenderer();
			r.add("module_id");
			r.add("module_id", module_id);
			sql = r.getSQLSelect("module");

			ResultSet rs = stmt.executeQuery(sql);
			
			//Return FALSE if already exist
			if ( rs.next() && ( module_id.equalsIgnoreCase(rs.getString("module_id")) ) ) return false;
			
			r = new SQLRenderer();
			r.add("module_id", module_id);
			r.add("module_title", module_title);
			r.add("module_class", module_class);
			r.add("module_group", module_group.toUpperCase());
			r.add("module_description", module_description);
			
			sql = r.getSQLInsert("module");
			
			stmt.executeUpdate(sql);
			
			if ( roles != null ) {
				//delete first
				sql = "DELETE FROM role_module WHERE module_id = '" + module_id + "'";
				stmt.executeUpdate(sql);
				
				for ( int i=0; i < roles.length; i++ ) {
					sql = "INSERT INTO role_module (module_id, user_role) VALUES ('" + module_id + "', '" + roles[i] + "')";		
					stmt.executeUpdate(sql);
				}	
			}			
			
			conn.commit();
		} catch ( SQLException ex ) {
			try {
				conn.rollback();
			} catch ( SQLException ex2 ) {}
			//System.out.println( ex.getMessage() + "\n" + sql);
			//Log.print( ex.getMessage() + "\n" + sql);
			return false;
		} finally {
			if ( db != null ) db.close();
		}	
		return true;
	}
	
	public static boolean update(String module_id, String module_title, String module_class, String module_group, String module_description) throws DbException {
		return update(module_id, module_title, module_class, module_group, module_description, null);
	}
	
	public static boolean update(String module_id, String module_title, String module_class, String module_group, String module_description, String[] roles) throws DbException {
		Db db = null;
		Connection conn = null;
		String sql = "";
		try {
			db = new Db();
			conn = db.getConnection();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			conn.setAutoCommit(false);

			r.add("module_title", module_title);
			r.add("module_class", module_class);
			r.add("module_group", module_group.toUpperCase());
			r.add("module_description", module_description);
			r.update("module_id", module_id);
			sql = r.getSQLUpdate("module");
			stmt.executeUpdate(sql);
			
			if ( roles != null ) {
				//delete first
				sql = "DELETE FROM role_module WHERE module_id = '" + module_id + "'";
				stmt.executeUpdate(sql);
				
				for ( int i=0; i < roles.length; i++ ) {
					sql = "INSERT INTO role_module (module_id, user_role) VALUES ('" + module_id + "', '" + roles[i] + "')";		
					stmt.executeUpdate(sql);
				}	
			}
			
			conn.commit();
		} catch ( SQLException ex ) {
			try {
				conn.rollback();
			} catch ( SQLException ex2 ) {}
			//Log.print( ex.getMessage() + "\n" + sql);
			return false;
		} finally {
			if ( db != null ) db.close();
		}	
		return true;
	}
	
	public static void delete(String module_id) throws DbException {
		Db db = null;
		Connection conn = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			conn = db.getConnection();
			
			conn.setAutoCommit(false);
			
			//delete from roles
			sql = "DELETE FROM role_module WHERE module_id = '" + module_id + "'";
			stmt.executeUpdate(sql);
			
			//delete from user_module
			sql = "DELETE FROM user_module WHERE module_id = '" + module_id + "'";
			stmt.executeUpdate(sql);
			
			//delete from role_module
			sql = "DELETE FROM role_module WHERE module_id = '" + module_id + "'";
			stmt.executeUpdate(sql);
			
			//delete from module
			sql = "DELETE FROM module WHERE module_id = '" + module_id + "'";
			stmt.executeUpdate(sql);
			
			conn.commit();
			
		} catch ( SQLException ex ) {
			try {
				conn.rollback();
			} catch ( SQLException exr ) {}
			throw new DbException(ex.getMessage() + ": " + sql);
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	public static void assignRoles(String module_id, String[] roles) throws DbException {
		Db db = null;
		Connection conn = null;
		String sql = "";
		try {
			db = new Db();
			conn = db.getConnection();
			Statement stmt = db.getStatement();
			
			conn.setAutoCommit(false);
			//delete first
			sql = "DELETE FROM role_module WHERE module_id = '" + module_id + "'";
			stmt.executeUpdate(sql);
			
			//insert the roles
			for ( int i=0; i < roles.length; i++ ) {
				sql = "INSERT INTO role_module (module_id, user_role) VALUES ('" + module_id + "', '" + roles[i] + "')";
				stmt.executeUpdate(sql);
			}
			
			conn.commit();
			
		} catch ( SQLException ex ) {
			try {
				conn.rollback();
			} catch ( SQLException exr ) {}
			throw new DbException(ex.getMessage() + ": " + sql);
		} finally {
			if ( db != null ) db.close();
		}			
	}
	
	public static void updateHtmlLocation(String module_id, String html_location) throws DbException {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			boolean found = false;
			{
				sql = "SELECT module_id FROM module_htmlcontainer WHERE module_id = '" + module_id + "' ";
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) found = true;
			}
			if ( found )
				sql = "UPDATE module_htmlcontainer SET html_url = '" + html_location + "' WHERE module_id = '" + module_id + "' ";
			else
				sql = "INSERT INTO module_htmlcontainer (module_id, html_url) VALUES ('" + module_id + "', '" + html_location + "')";
			stmt.executeUpdate(sql);
		} catch ( SQLException ex ) {
			throw new DbException(ex.getMessage() + ": " + sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	public static void updateRSSLocation(String module_id, String rss) throws DbException {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			boolean found = false;
			{
				sql = "SELECT module_id FROM rss_module WHERE module_id = '" + module_id + "' ";
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) found = true;
			}
			if ( found )
				sql = "UPDATE rss_module SET rss_source = '" + rss + "' WHERE module_id = '" + module_id + "' ";
			else
				sql = "INSERT INTO rss_module (module_id, rss_source) VALUES ('" + module_id + "', '" + rss + "')";
			stmt.executeUpdate(sql);
		} catch ( SQLException ex ) {
			throw new DbException(ex.getMessage() + ": " + sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}	
	
	
	public static void updateXMLData(String module_id, String xml, String xsl) throws DbException {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			
			boolean found = false;
			{
				sql = "SELECT module_id FROM xml_module WHERE module_id = '" + module_id + "' ";
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) found = true;
			}
			if ( found )
				sql = "UPDATE xml_module SET xml = '" + xml + "', xsl = '" + xsl + "' WHERE module_id = '" + module_id + "' ";
			else
				sql = "INSERT INTO xml_module (module_id, xml, xsl) VALUES ('" + module_id + "', '" + xml + "', '" + xsl + "')";
			stmt.executeUpdate(sql);
		} catch ( SQLException ex ) {
			throw new DbException(ex.getMessage() + ": " + sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}	
	
	public static void updateAttributeData(String module_id, String[] attributes, String[] values) throws DbException {
		
		if ( attributes == null ) {
			System.out.println("Error: attributes is null");
			return;
		}
		if ( values == null ) {
			System.out.println("Error: values is null");
			return;
		}
		Db db = null;
		String sql = "";
		Connection conn = null;
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			conn = db.getConnection();
			conn.setAutoCommit(false);
			SQLRenderer r = new SQLRenderer();

			sql = "DELETE FROM attr_module_data WHERE module_id = '" + module_id + "'";
			//System.out.println(sql);
			stmt.executeUpdate(sql);
			
			sql = "INSERT INTO attr_module_data ";
			for ( int i = 0; i < attributes.length; i++ ) {
				r.clear();
				r.add("module_id", module_id);
				r.add("attribute_name", attributes[i]);
				r.add("attribute_value", values[i]);
				sql = r.getSQLInsert("attr_module_data");
				//System.out.println(sql);
				stmt.executeUpdate(sql);
			}
			
			conn.commit();
		} catch ( SQLException ex ) {
			try {
				conn.rollback();
			} catch ( SQLException rex ) {}
			throw new DbException(ex.getMessage() + ": " + sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}	
	
}