/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.datasource;


import java.sql.ResultSet;
import java.sql.Statement;

import mecca.db.Db;
import mecca.db.SQLRenderer;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class TranscriptDataSource {
	private Db db = null;
	
	public ResultSet getResultSet(String student_id, String program_code) throws Exception {
		db = new Db();
		Statement stmt = db.getStatement();
		SQLRenderer r = new SQLRenderer();
		String sql = "";
		r.add("student_id", student_id);
		r.add("program_code", program_code);
		r.add("student_id");
		r.add("period_name");
		r.add("session_name");
		r.add("subject_code");
		r.add("subject_name");
		r.add("credit_hrs");
		r.add("total");
		r.add("point");
		r.add("grade");
		r.add("grade_point");
		r.add("tot_credit_hrs");
		r.add("tot_grade_point");
		r.add("gpa");
		r.add("cum_credit_hrs");
		r.add("cum_grade_point");
		r.add("cgpa");		
		sql = r.getSQLSelect("transcript_display", "startDate");
		ResultSet rs = stmt.executeQuery(sql);
		return rs;
	}
	
	
	public void close() {
		if ( db != null ) db.close();	
	}
}