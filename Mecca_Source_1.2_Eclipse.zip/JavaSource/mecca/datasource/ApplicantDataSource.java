/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.datasource;


import java.sql.ResultSet;
import java.sql.Statement;

import mecca.db.Db;
import mecca.db.SQLRenderer;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ApplicantDataSource {
	private Db db = null;
	
	public ResultSet getResultSet() throws Exception {
		db = new Db();
		Statement stmt = db.getStatement();
		SQLRenderer r = new SQLRenderer();
		String sql = "";
		r.add("applicant_name");
		r.add("offer_letter_addr");
		r.add("offer_letter_salutation");
		r.add("offer_letter_subject");
		r.add("offer_letter_signature");		
		r.add("offer_letter_text");
		sql = r.getSQLSelect("adm_applicant", "applicant_name");
		ResultSet rs = stmt.executeQuery(sql);
		return rs;
	}
	
	public ResultSet getResultSet(String status, String program) throws Exception {
		db = new Db();
		Statement stmt = db.getStatement();
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		r.add("applicant_name");
		r.add("offer_letter_addr");
		r.add("offer_letter_salutation");
		r.add("offer_letter_subject");
		r.add("offer_letter_signature");		
		r.add("offer_letter_text");
		r.add("status", status);
		r.add("vet_program_id", program);
		sql = r.getSQLSelect("adm_applicant", "applicant_name");
		ResultSet rs = stmt.executeQuery(sql);
		return rs;
	}
	
	public ResultSet getResultSet(String status, String status2, String program) throws Exception {
		db = new Db();
		Statement stmt = db.getStatement();
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		r.add("applicant_name");
		r.add("offer_letter_addr");
		r.add("offer_letter_salutation");
		r.add("offer_letter_subject");
		r.add("offer_letter_signature");
		r.add("offer_letter_text");
		r.add("status", status);
		r.add("status2", status2);
		r.add("vet_program_id", program);
		sql = r.getSQLSelect("adm_applicant", "applicant_name");
		ResultSet rs = stmt.executeQuery(sql);
		return rs;
	}
		
	public ResultSet getResultSet(String applicant_id) throws Exception {
		db = new Db();
		Statement stmt = db.getStatement();
		String sql = "";
		SQLRenderer r = new SQLRenderer();
		r.add("applicant_name");
		r.add("offer_letter_addr");
		r.add("offer_letter_salutation");
		r.add("offer_letter_subject");
		r.add("offer_letter_signature");		
		r.add("offer_letter_text");
		r.add("applicant_id", applicant_id);
		sql = r.getSQLSelect("adm_applicant", "applicant_name");
		ResultSet rs = stmt.executeQuery(sql);
		return rs;
	}	
	
	public void close() {
		if ( db != null ) db.close();	
	}
}