/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.app;
 
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.db.CollabDb;
import mecca.db.SQLRenderer;
import mecca.lcms.LearnerProgress;

import org.apache.velocity.Template;


/**
 * @author Shamsul Bahrin Abd Mutalib  
 * @version 1.01
 */
public class CollabSelectLessonModule extends mecca.portal.velocity.VTemplate {

	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		String template_name = "vtl/collab/lesson.vm";
		String userid = (String) session.getAttribute("_portal_login");
		//String subjectid = getParam("subjectId");
		String subjectid = getId();
		//String submit = getParam("command");
		//to handle refresh problem
		//boolean post = session.getAttribute("doPost") != null ?
		//	"true".equals((String) session.getAttribute("doPost")) ? true : false : true;
		//String submit = post ? getParam("command") : "";
		String submit = post(session) ? getParam("command") : "";
		
		//get role from subject registration
		String role = getRole(userid, subjectid);
		if( !"".equals(role) ) session.setAttribute("_collab_role", role );
		
		String openSection = getParam("openSection");
		if ( "".equals(openSection)) openSection = "false";
		context.put("openSection", "true".equals(openSection) ? new Boolean(true):new Boolean(false));
		
		if ( "Comment".equals(submit) ) {
			addTeacherComment(subjectid, userid);	
			submit = "";
		}
		else if ( "AddLesson".equals(submit) ) {
			Hashtable h = new Hashtable();
			h.put("subject_id", subjectid);
			h.put("lesson_title", getParam("lesson_title"));
			h.put("lesson_description", getParam("lesson_description"));
			addLesson(h);	
			submit = "";
		}
		else if ( "EditLesson".equals(submit) ) {
			template_name = "vtl/collab/edit_lesson.vm";
			String lessonid = getParam("lessonId");
			Hashtable lesson = getLessonInfo(lessonid);
			context.put("lesson", lesson);
		}
		else if ( "UpdateLesson".equals(submit) ) {
			Hashtable h = new Hashtable();
			h.put("lesson_id", getParam("lessonId"));
			h.put("lesson_title", getParam("lesson_title"));
			h.put("lesson_description", getParam("lesson_description"));
			updateLesson(h);
			submit = "";	
		}
		else if ( "RemoveLesson".equals(submit) ) {
			removeLesson(getParam("lessonId"));
			submit = "";	
		}
		else if ( "AddLink".equals(submit) ) {
			Hashtable h = new Hashtable();
			h.put("subject_id", subjectid);
			h.put("link_title", getParam("link_title"));
			h.put("link_url", getParam("link_url"));
			h.put("link_type", getParam("link_type"));
			addLink(h);	
			submit = "";
		}
		else if ( "EditLink".equals(submit) ) {
			template_name = "vtl/collab/edit_link.vm";
			String linkId = getParam("linkId");
			Hashtable link = getLinkInfo(linkId);
			context.put("link", link);
		}
		else if ( "UpdateLink".equals(submit) ) {
			Hashtable h = new Hashtable();
			h.put("link_id", getParam("linkId"));
			h.put("link_title", getParam("link_title"));
			h.put("link_url", getParam("link_url"));
			updateLink(h);
			submit = "";	
		}
		else if ( "RemoveLink".equals(submit) ) {
			removeLink(getParam("linkId"));
			submit = "";	
		}
		
		if ( "".equals(submit) ) {
			Vector linkList = getLinkList(userid, subjectid);
			context.put("links", linkList);
			Vector lessonList = getLessonList(subjectid);
			context.put("lessons", lessonList);
			Hashtable comment = getTeacherComment(subjectid);
			context.put("comment", comment);
		}
		
		Template template = engine.getTemplate(template_name);	
		return template;		
	}	
	
	/*
	boolean post(HttpSession session) {
		return session.getAttribute("doPost") != null ?
			"true".equals((String) session.getAttribute("doPost")) ? true : false : true;
	}
	*/
	
	String getRole(String userid, String subjectid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("role");
			r.add("member_id", userid);
			r.add("subject_id", subjectid);
			sql = r.getSQLSelect("member_subject");
			ResultSet rs = stmt.executeQuery(sql);
			if ( rs.next() )
				return rs.getString("role");
			else
				return "";
		} finally {
			if ( db != null ) db.close();
		}
			
	}	
	
	Vector getLessonList(String subjectid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("s.subject_id", subjectid);
			r.add("l.lesson_id");
			r.add("lesson_title");
			r.add("lesson_description");
			r.add("s.subject_id", r.unquote("l.subject_id"));
			sql = r.getSQLSelect("lesson l, subject s", "lesson_sequence");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("lessonId", rs.getString("lesson_id"));
				h.put("lessonTitle", rs.getString("lesson_title"));
				h.put("lessonDescription", CollabDb.putLineBreak(rs.getString("lesson_description")));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	Hashtable getTeacherComment(String subjectid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("subject_id", subjectid);
			r.add("comment");
			sql = r.getSQLSelect("teacher_comment");
			ResultSet rs = stmt.executeQuery(sql);
			Hashtable h = new Hashtable();
			h.put("text", "");
			h.put("value", "");
			if ( rs.next() ) {
				String comment = rs.getString("comment");
				h.put("text", CollabDb.putLineBreak(comment));
				h.put("value", comment);
			}
			return h;
		} finally {
			if ( db != null ) db.close();
		}		
	}
	
	void addTeacherComment(String subjectid, String userid) throws Exception {
		//String comment = getParam("teacher_comment");
	    String comment = getParam("message");
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			boolean isExist = false;
			{
				r.add("subject_id", subjectid);
				r.add("subject_id");
				sql = r.getSQLSelect("teacher_comment");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) isExist = true;
			}
			if ( isExist) {
				r.clear();
				r.update("subject_id", subjectid);
				r.add("comment", comment);
				r.add("member_id", userid);
				sql = r.getSQLUpdate("teacher_comment");
				stmt.executeUpdate(sql);
			} 
			else {
				r.clear();
				r.add("subject_id", subjectid);
				r.add("comment", comment);
				r.add("member_id", userid);
				sql = r.getSQLInsert("teacher_comment");
				stmt.executeUpdate(sql);			
			}
		} finally {
			if ( db != null ) db.close();
		}
			
	}
	
	void addLesson(Hashtable lesson) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			int seq = 0;
			{
			    r.add("MAX(lesson_sequence) AS seq");
			    r.add("subject_id",  (String) lesson.get("subject_id"));
			    sql = r.getSQLSelect("lesson");
			    ResultSet rs = stmt.executeQuery(sql);
			    if ( rs.next() ) {
			        seq = rs.getInt("seq");
			    }
			}
			{
			    r.clear();
				r.add("subject_id", (String) lesson.get("subject_id"));
				r.add("lesson_id", "uid_" + db.uid());
				r.add("lesson_title", (String) lesson.get("lesson_title"));
				r.add("lesson_description", (String) lesson.get("lesson_description"));
				r.add("lesson_sequence", ++seq);
				sql = r.getSQLInsert("lesson");
				stmt.executeUpdate(sql);
			}
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	void updateLesson(Hashtable lesson) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.update("lesson_id", (String) lesson.get("lesson_id"));
			r.add("lesson_title", (String) lesson.get("lesson_title"));
			r.add("lesson_description", (String) lesson.get("lesson_description"));
			sql = r.getSQLUpdate("lesson");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}	

	Hashtable getLessonInfo(String lessonid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("lesson_id", lessonid);
			r.add("lesson_title");
			r.add("lesson_description");
			r.add("subject_id");
			sql = r.getSQLSelect("lesson");
			ResultSet rs = stmt.executeQuery(sql);
			Hashtable h = new Hashtable();
			if ( rs.next() ) {
				h.put("lessonId", lessonid);
				h.put("lessonTitle", rs.getString("lesson_title"));
				h.put("lessonDescription", rs.getString("lesson_description"));
				h.put("subjectId", rs.getString("subject_id"));
			}
			return h;
		} finally {
			if ( db != null ) db.close();
		}
		
	}
	
	boolean removeLesson(String lessonid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			boolean found = false;
			{
				r.add("lesson_id", lessonid);
				r.add("quiz_id");
				sql = r.getSQLSelect("quiz_main");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next()) found = true;
			}
			if ( !found ) {
				r.clear();
				r.add("lesson_id", lessonid);
				sql = r.getSQLDelete("lesson");
				stmt.executeUpdate(sql);
				return true;
			}
			return false;
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	Vector getLinkList(String userid, String subjectid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("s.subject_id", subjectid);
			r.add("l.link_id");
			r.add("link_title");
			r.add("link_url");
			r.add("link_type");
			r.add("s.subject_id", r.unquote("l.subject_id"));
			sql = r.getSQLSelect("course_url l, subject s");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("linkId", rs.getString("link_id"));
				h.put("linkTitle", rs.getString("link_title"));
				String linkUrl = rs.getString("link_url");
				h.put("linkUrl", linkUrl);
				String link_type = rs.getString("link_type");
				h.put("linkType", link_type != null ? link_type : "url");
				h.put("pctComplete", "");
				if ( "scorm".equals(link_type) || "netg".equals(link_type)) {
				    h.put("pctComplete", getContentAttemptedStatus(userid, linkUrl));
				}
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	String getContentAttemptedStatus(String learnerid, String subjectid) {
	    try {
		    Vector report = LearnerProgress.getReport(learnerid, subjectid);
		    double cntNotAttempted = 0.0d;
		    double cntEntryStatus = 0.0d;
		    double cntTotal = 0.0d;
		    for ( int i=0; i < report.size(); i++ ) {
		        Hashtable item = (Hashtable) report.elementAt(i);
		        String lessonStatus = (String) item.get("lesson_status");
		        if ( "not attempted".equals(lessonStatus.trim())) {
		            cntNotAttempted++;
		        }
		        String entryStatus = (String) item.get("entry_status");
		        if ( !"".equals(entryStatus.trim())) {
		            cntEntryStatus++;
		        }
		        cntTotal = cntNotAttempted + cntEntryStatus;
		    }
		    //return getFormatted(100 - (100* (cntNotAttempted / report.size()))) + "%";
		    return getFormatted(100* (cntEntryStatus / cntTotal)) + "%";
	    } catch ( Exception e ) {
	        
	    }
	    return "Error";
	}
	

	void addLink(Hashtable link) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			
			String link_title = link.get("link_title") != null ? (String) link.get("link_title") : "";
			String link_url = link.get("link_url") != null ? (String) link.get("link_url") : "";
			//link_type = "url" OR  "scorm"
			String link_type = link.get("link_type") != null ? (String) link.get("link_type") : "url";
			
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("subject_id", (String) link.get("subject_id"));
			r.add("link_id", "uid_" + db.uid());
			r.add("link_title", link_title);
			r.add("link_url", link_url);
			r.add("link_type", link_type);
			sql = r.getSQLInsert("course_url");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	void updateLink(Hashtable link) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.update("link_id", (String) link.get("link_id"));
			r.add("link_title", (String) link.get("link_title"));
			r.add("link_url", (String) link.get("link_url"));
			sql = r.getSQLUpdate("course_url");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	void removeLink(String linkid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("link_id", linkid);
			sql = r.getSQLDelete("course_url");
			stmt.executeUpdate(sql);	
		} finally {
			if ( db != null ) db.close();
		}	
	}
	
	Hashtable getLinkInfo(String linkid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("link_id", linkid);
			r.add("link_title");
			r.add("link_url");
			r.add("subject_id");
			sql = r.getSQLSelect("course_url");
			ResultSet rs = stmt.executeQuery(sql);
			Hashtable h = new Hashtable();
			if ( rs.next() ) {
				h.put("linkId", linkid);
				h.put("linkTitle", rs.getString("link_title"));
				h.put("linkUrl", rs.getString("link_url"));
				h.put("subjectId", rs.getString("subject_id"));
			}
			return h;
		} finally {
			if ( db != null ) db.close();
		}
		
	}
	
	public static String getFormatted(double number) {
		return new java.text.DecimalFormat("0.0").format(number);
	} 		
}