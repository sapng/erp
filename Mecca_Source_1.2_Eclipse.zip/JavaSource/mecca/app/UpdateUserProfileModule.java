/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.app;

import javax.servlet.http.HttpSession;

import mecca.db.DbException;
import mecca.portal.db.PrepareUser;
import mecca.portal.db.RegisterUser;
import mecca.portal.element.User;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class UpdateUserProfileModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		doJob(session);
		Template template = engine.getTemplate("vtl/admin/updateuserprofile.vm");	
		return template;		
	}
	
	private void doJob(HttpSession session) throws Exception {
	    context.put("operation", "");
		String submit = getParam("command");
		if ( "update".equals(submit)) {
		    context.put("operation", "update");
			String user_login = (String) session.getAttribute("_portal_login");
			String user_name = getParam("user_name");
			String user_password = getParam("user_password");			
			//String user_role = getParam("user_role");
			String user_login_alt = getParam("user_login_alt");
			
			/*
			context.put("user_login", user_login);
			context.put("user_name", user_name);
			context.put("user_password", user_password);
			context.put("user_role", user_role);
			*/
			
			if ( "".equals(user_password) ) {
				if ( RegisterUser.update(user_name, user_login, user_login_alt) ) {
				    context.put("updateUserSuccess", new Boolean(true));
				} else {
				    context.put("updateUserSuccess", new Boolean(false));
				}			    
			}
			else {
				if ( RegisterUser.update(user_name, user_login, user_password, user_login_alt) ) {
				    context.put("updateUserSuccess", new Boolean(true));
				} else {
				    context.put("updateUserSuccess", new Boolean(false));
				}
			}
			
			//update session
			session.setAttribute("_portal_username", user_name);
			session.setAttribute("_portal_login", user_login);

		}
		
		String user_login = (String) session.getAttribute("_portal_login");
		User user = PrepareUser.getUserById(user_login);
		if ( user == null ) throw new DbException("User Is NULL!");

		String user_name = user.getName();
		String user_password = user.getPassword();
		String user_role = user.getRole();
		String login_alt = user.getAlternateLogin();
		
		context.put("user_login", user_login);
		context.put("user_name", user_name);
		context.put("user_password", user_password);
		context.put("user_role", user_role);	
		context.put("user_login_alt", login_alt);


	}
	
	
	

}