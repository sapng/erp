/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.app;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;
import javax.servlet.http.HttpSession;
import mecca.db.CollabDb;
import mecca.db.SQLRenderer;
import mecca.sis.registration.StudentData;
import mecca.sis.struct.Subject;
import org.apache.velocity.Template;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class CollabSelectSubjectModule extends mecca.portal.velocity.VTemplate {

	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		String template_name = "vtl/collab/subject.vm";
		String userid = (String) session.getAttribute("_portal_login");
		String role = (String) session.getAttribute("_portal_role");
		
		//System.out.println(getId());
		String pId = getId();
		
		String submit = post(session) ? getParam("command") : "";

		if ( "AddSubject".equals(submit) ) {
			String code = getParam("subject_code");
			String title = getParam("subject_title");
			String comment = getParam("subject_comment");
			addSubject(pId, userid, code, title, comment);
			submit = "";
		}
		else if ( "EditSubject".equals(submit) ) {
			template_name = "vtl/collab/edit_subject.vm";
			String subjectid = getParam("subject_id");
			Hashtable subjectInfo = getSubjectInfo(subjectid);
			context.put("subjectInfo", subjectInfo);
		} 
		else if ( "UpdateSubject".equals(submit) ) {
			String subjectid = getParam("subject_id");
			Hashtable h = new Hashtable();
			h.put("subjectId", subjectid);
			h.put("subjectCode", getParam("subject_code"));
			h.put("subjectTitle", getParam("subject_title"));
			h.put("subjectComment", getParam("subject_comment"));
			h.put("subjectText", getParam("message"));
			updateSubject(subjectid, h);
			submit = "";
		} 		
		else if ( "DeleteSubject".equals(submit) ) {
			String subjectid = getParam("subject_id");
			deleteSubject(pId, userid, subjectid);	
			submit = "";
		}
		else if ( "Enrollment".equals(submit) ) {
			String subjectid = getParam("subject_id");
			prepareEnrollView(subjectid);
			template_name = "vtl/collab/enroll.vm";
		}
		else if ( "AddLearner".equals(submit) ) {
			String subjectid = getParam("subject_id");	
			String learnerid = getParam("learner_id");
			addParticipant(pId, subjectid, learnerid, "learner", "active");
			prepareEnrollView(subjectid);			
			template_name = "vtl/collab/enroll.vm";
		}
		else if ( "AddModerator".equals(submit) ) {
			String subjectid = getParam("subject_id");	
			String learnerid = getParam("learner_id");
			addParticipant(pId, subjectid, learnerid, "tutor", "active");
			prepareEnrollView(subjectid);			
			template_name = "vtl/collab/enroll.vm";
		}
		
		else if ( "DeleteLearner".equals(submit) ) {
			String subjectid = getParam("subject_id");	
			String learnerid = getParam("learner_id");
			deleteParticipant(subjectid, learnerid);
			prepareEnrollView(subjectid);
			template_name = "vtl/collab/enroll.vm";			
		}
		else if ( "ActivateLearner".equals(submit) ) {
			String subjectid = getParam("subject_id");	
			String learnerid = getParam("learner_id");
			activateParticipant(subjectid, learnerid);
			prepareEnrollView(subjectid);			
			template_name = "vtl/collab/enroll.vm";			
		}
		else if ( "DeactivateLearner".equals(submit) ) {
			String subjectid = getParam("subject_id");	
			String learnerid = getParam("learner_id");
			deactivateParticipant(subjectid, learnerid);
			prepareEnrollView(subjectid);			
			template_name = "vtl/collab/enroll.vm";			
		}
		else if ( "Apply".equals(submit) ) {
			prepareApplyView(pId, userid);
			template_name = "vtl/collab/apply.vm";
		}
		else if ( "ApplyViewInfo".equals(submit) ) {
			String subjectid = getParam("subject_id");
			Hashtable info = getSubjectInfo(subjectid);
			context.put("subjectInfo", info);
			template_name = "vtl/collab/applySubjectInfo.vm";
		}
		else if ( "ApplySubject".equals(submit) ) {
			String subjectid = getParam("subject_id");
			addParticipant(pId, subjectid, userid, "learner", "inactive");
			prepareApplyView(pId, userid);
			template_name = "vtl/collab/apply.vm";			
		}
		else if ( "UnenrollSubject".equals(submit) ) {
			String subjectid = getParam("subject_id");
			deleteParticipant(subjectid, userid);
			prepareApplyView(pId, userid);
			template_name = "vtl/collab/apply.vm";			
		}		
		else if ( "PendingList".equals(submit) ) {
			String subjectid = getParam("subject_id");
			prepareEnrollView(subjectid, "inactive");			
			template_name = "vtl/collab/enroll_pending.vm";				
		}
		
		
		
		if ( "".equals(submit) ) {
			
		    boolean inLMS = session.getAttribute("inCollabModule") != null ?
		            "true".equals((String) session.getAttribute("inCollabModule")) ? true : false : false;
		    //get student enrollment information
		    
		    if ( "student".equals(role) && inLMS ) {
		        Hashtable programInfo = StudentData.getEnrollmentInfo(userid);
		        if ( programInfo != null ) {
		            context.put("programInfo", programInfo);   
		            Vector subjectList = StudentData.getSubjectList(userid, (String) programInfo.get("period_id"), (String) programInfo.get("code"));
		            prepareSubjectLMS(subjectList, userid);
		        }
		    }
		    
		    context.put("inLMS", new Boolean(inLMS));
		    
		    Vector subjectList = getSubjectList(pId, userid);
			context.put("subjects", subjectList);
			
		}
		
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	void prepareSubjectLMS(Vector subjectList, String studentId) throws Exception {
	    StudentData.deleteSubjectLMS(studentId);
	    for ( int i=0; i < subjectList.size(); i++ ) {
	        Subject s = (Subject) subjectList.elementAt(i);
	        StudentData.addSubjectLMS(s, studentId);
	    }
	}
	
	void prepareEnrollView(String subjectid, String status) throws Exception {
		Hashtable info = getSubjectInfo(subjectid);
		context.put("subjectInfo", info);			
		Vector learners = getParticipantList(subjectid, "learner", status);
		Vector moderators = getParticipantList(subjectid, "tutor", status);
		context.put("subjectId", subjectid);
		context.put("learners", learners);	
		context.put("moderators", moderators);
	}	
	
	void prepareEnrollView(String subjectid) throws Exception {
		Hashtable info = getSubjectInfo(subjectid);
		context.put("subjectInfo", info);			
		Vector learners = getParticipantList(subjectid, "learner", "active");
		Vector pendings = getParticipantList(subjectid, "learner", "inactive");
		Vector moderators = getParticipantList(subjectid, "tutor", "active");
		context.put("subjectId", subjectid);
		context.put("learners", learners);	
		context.put("pendings", pendings);
		context.put("moderators", moderators);
	}
	
	void prepareApplyView(String pId, String userid) throws Exception {
		Vector subjects = getSubjects(pId);
		context.put("subjects", subjects);
		
		Vector userSubjects = getSubjects(pId, userid);
		context.put("userSubjects", userSubjects);
		
		
		for ( int i=0; i < subjects.size(); i++ ) {
			SubjectInfo s = (SubjectInfo) subjects.elementAt(i);
			if ( userSubjects.contains(s) ) {
				SubjectInfo si = (SubjectInfo) userSubjects.elementAt(userSubjects.indexOf(s));
				s.participantRole = si.participantRole;
				s.participantStatus = si.participantStatus;
			}	
		}
		

	}		
	
	
	Vector getSubjectList(String pId, String userid) throws Exception {
		return getSubjectList(pId, userid, "active");
	}	
	
	Vector getSubjectList(String pId, String userid, String status) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			r.add("s.subject_id");
			r.add("s.subject_code");
			r.add("s.subject_title");
			r.add("m.role");
			r.add("m.status");
			
			if ( !"".equals(userid) )
				r.add("m.member_id", userid);
			if ( !"".equals(status) ) 
				r.add("m.status", status);
				
			r.add("m.module_id", pId);				
			r.add("s.subject_id", r.unquote("m.subject_id"));
			r.add("s.module_id", r.unquote("m.module_id"));
			
			sql = r.getSQLSelect("member_subject m, subject s");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("subjectId", rs.getString("subject_id"));
				h.put("subjectCode", rs.getString("subject_code"));
				h.put("subjectTitle", rs.getString("subject_title"));
				h.put("role", rs.getString("role"));
				h.put("status", rs.getString("status"));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}	
	
	Hashtable getSubjectInfo(String subjectid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("subject_id", subjectid);
			r.add("subject_code");
			r.add("subject_title");
			r.add("subject_comment");
			r.add("subject_text");
			sql = r.getSQLSelect("subject");
			ResultSet rs = stmt.executeQuery(sql);
			Hashtable h = new Hashtable();
			if ( rs.next() ) {
				h.put("subjectId", subjectid);
				h.put("subjectCode", rs.getString("subject_code"));
				h.put("subjectTitle", CollabDb.getString(rs, "subject_title"));
				h.put("subjectComment", CollabDb.getString(rs, "subject_comment"));
				h.put("subjectText", CollabDb.getString(rs, "subject_text"));
			}
			return h;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	Vector getSubjects(String pId) throws Exception {
		return getSubjects(pId, "");
	}

	Vector getSubjects(String pId, String userid) throws Exception {
		CollabDb db = null;
		String sql = "";
		Vector subjects = new Vector();
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			if ( !"".equals(userid) ) {
				r.add("s.subject_id");
				r.add("s.subject_code");
				r.add("s.subject_title");
				r.add("m.role");
				r.add("m.status");
				r.add("m.member_id", userid);
				r.add("m.module_id", pId);
				r.add("s.subject_id", r.unquote("m.subject_id"));
				sql = r.getSQLSelect("member_subject m, subject s");
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {

					SubjectInfo info = new SubjectInfo();
					info.subjectId = rs.getString("subject_id");
					info.subjectCode = rs.getString("subject_code");
					info.subjectTitle = rs.getString("subject_title");
					info.participantRole = rs.getString("role");
					info.participantStatus = rs.getString("status");
					subjects.addElement(info);
				}
			}
			else {
				r.add("subject_id");
				r.add("subject_code");
				r.add("subject_title");
				r.add("module_id", pId);
				sql = r.getSQLSelect("subject");
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {

					SubjectInfo info = new SubjectInfo();
					info.subjectId = rs.getString("subject_id");
					info.subjectCode = rs.getString("subject_code");
					info.subjectTitle = rs.getString("subject_title");
					info.participantRole = "";
					info.participantStatus = "";
					subjects.addElement(info);					
				}				
			}

			return subjects;
		} finally {
			if ( db != null ) db.close();
		}
	}		
	
	boolean updateSubject(String subjectid, Hashtable info) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			boolean isExist = false;
			/*
			{
				r.add("subject_id");
				r.add("subject_code", code);
				r.add("module_id", pId);
				sql = r.getSQLSelect("subject");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() )
					isExist = true;
				else
					isExist = false;
			}
			*/
			if ( !isExist ){
				r.clear();
				r.update("subject_id", subjectid);
				r.add("subject_code", (String) info.get("subjectCode"));
				r.add("subject_title", (String) info.get("subjectTitle"));
				r.add("subject_comment", (String) info.get("subjectComment"));
				r.add("subject_text", (String) info.get("subjectText"));
				
				sql = r.getSQLUpdate("subject");
				stmt.executeUpdate(sql);
				return true;
			} else
				return false;
			
		} finally {
			if ( db != null ) db.close();
		}		
	}		
	
	boolean addSubject(String pId, String userid, String code, String title, String comment) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			String uid = pId + "_" + db.uid();
			boolean isExist = false;
			{
				r.add("subject_id");
				r.add("subject_code", code);
				r.add("module_id", pId);
				sql = r.getSQLSelect("subject");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() )
					isExist = true;
				else
					isExist = false;
			}
			if ( !isExist ){
				r.clear();
				r.add("subject_id", uid);
				r.add("subject_code", code);
				r.add("subject_title", title);
				r.add("subject_comment", comment);
				r.add("module_id", pId);
				sql = r.getSQLInsert("subject");
				stmt.executeUpdate(sql);
				addMemberSubject(pId, userid, uid, "tutor", stmt, r);
				return true;
			} else
				return false;
			
		} finally {
			if ( db != null ) db.close();
		}	
	}
	

	
	void addMemberSubject(String pId, String userid, String subjectid, String role, Statement stmt, SQLRenderer r) throws Exception {
		boolean isExist = false;
		String sql = "";
		{
			r.clear();
			r.add("role");
			r.add("member_id", userid);
			r.add("subject_id", subjectid);
			r.add("module_id", pId);
			sql = r.getSQLSelect("member_subject");
			ResultSet rs = stmt.executeQuery(sql);
			if ( rs.next() ) isExist = true;
		}
		if ( !isExist ) {	
			r.clear();
			r.add("member_id", userid);
			r.add("subject_id", subjectid);
			r.add("role", role);
			r.add("module_id", pId);
			r.add("status", "active");
			sql = r.getSQLInsert("member_subject");
			stmt.executeUpdate(sql);
		}
	}
	
	void deleteSubject(String pId, String userid, String subjectid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			sql = "delete from forum where category_id = 'for_" + subjectid + "'";
			stmt.executeUpdate(sql);
			sql = "delete from forum where category_id = 'ass_" + subjectid + "'";
			stmt.executeUpdate(sql);
			sql = "delete from forum where category_id = 'les_" + subjectid + "'";
			stmt.executeUpdate(sql);
			sql = "delete from member_subject where subject_id = '" + subjectid + "'";
			stmt.executeUpdate(sql);
			sql = "delete from subject where subject_id = '" + subjectid + "'";
			stmt.executeUpdate(sql);
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	Vector getParticipantList(String subjectid, String role, String status) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("ms.member_id");
			r.add("u.user_name AS name");
			r.add("ms.role");
			r.add("ms.role", role);
			r.add("ms.status", status);
			r.add("ms.member_id", r.unquote("u.user_login"));
			r.add("ms.subject_id", subjectid);
			sql = r.getSQLSelect("member_subject ms, users u");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("id", rs.getString("member_id"));
				h.put("name", rs.getString("name"));
				h.put("role", rs.getString("role"));
				v.addElement(h);
			}
			return v;
		} finally {
			if ( db != null ) db.close();
		}
	}
	
	void addParticipant(String pId, String subjectid, String userid, String role, String status) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			boolean isExist = false;
			String instatus = "";
			{
				r.add("subject_id", subjectid);
				r.add("member_id", userid);
				r.add("member_id");
				r.add("status");
				sql = r.getSQLSelect("member_subject");
				ResultSet rs = stmt.executeQuery(sql);
				if ( rs.next() ) {
					isExist = true;
					instatus = rs.getString("status");
				}
			}
			if ( !isExist ) {
				r.clear();
				r.add("subject_id", subjectid);
				r.add("member_id", userid);
				r.add("role", role);
				r.add("status", status);
				r.add("module_id", pId);
				r.add("date_apply", r.unquote("now()"));
				r.add("date_enroll", r.unquote("now()"));
				sql = r.getSQLInsert("member_subject");
				stmt.executeUpdate(sql);
			} else if ( "inactive".equals(instatus) && "active".equals(status) ) {
				r.clear();
				r.update("subject_id", subjectid);
				r.update("member_id", userid);
				r.add("role", role);
				r.add("status", "active");
				r.add("date_enroll", r.unquote("now()"));					
				sql = r.getSQLUpdate("member_subject");
				stmt.executeUpdate(sql);						
			}
			
		} finally {
			if ( db != null ) db.close();
		}
	}
	

	
	void deleteParticipant(String subjectid, String userid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			sql = "delete from member_subject where member_id = '" + userid + "' and subject_id = '" + subjectid + "'";
			stmt.executeUpdate(sql);
			
			
		} finally {
			if ( db != null ) db.close();
		}		
	}

	void activateParticipant(String subjectid, String userid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.update("subject_id", subjectid);
			r.update("member_id", userid);
			r.add("status", "active");
			sql = r.getSQLUpdate("member_subject");
			stmt.executeUpdate(sql);
			
		} finally {
			if ( db != null ) db.close();
		}		
	}
	
	void deactivateParticipant(String subjectid, String userid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.update("subject_id", subjectid);
			r.update("member_id", userid);
			r.add("status", "inactive");
			sql = r.getSQLUpdate("member_subject");
			stmt.executeUpdate(sql);			
			
		} finally {
			if ( db != null ) db.close();
		}		
	}


}                                                                                                                                                                                                                                   