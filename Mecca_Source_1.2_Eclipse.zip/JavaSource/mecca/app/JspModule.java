/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.app;

import java.io.IOException;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mecca.portal.MerakPortlet;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class JspModule extends MerakPortlet implements mecca.portal.HtmlContainer {
	
	private String strUrl = "";
	private Vector replaceList = new Vector();
	
	//set the url
	public void setUrl(String strUrl) {
		this.strUrl = strUrl;
	}
	
	public void doView(HttpServletRequest req, HttpServletResponse res) throws javax.servlet.ServletException, IOException {

		if ( req.getParameter("page") != null && !"".equals(req.getParameter("page")) ) {
			strUrl = req.getParameter("page");	
		}
		
		System.out.println("url=" + strUrl);
				
		RequestDispatcher rd = req.getRequestDispatcher(strUrl);
		if ( rd != null )
			rd.include(req, res);
		else
			System.out.println("Request Dispatcher is NULL!");
	}
}

