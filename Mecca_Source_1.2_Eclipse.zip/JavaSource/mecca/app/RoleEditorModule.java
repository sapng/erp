/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.app;

import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.portal.velocity.VTemplate;

import org.apache.velocity.Template;

/**
 * @author Shaiful Nizam Tajul
 * @version 1.01
 */
public class RoleEditorModule extends VTemplate
{
    private String targetPage;
    
    public Template doTemplate() throws Exception
    {
        
        HttpSession session = request.getSession();
        
        RoleProcessor processor = new RoleProcessor();
                                
        String action = request.getParameter("form_action");
        if ((action == null) || (action.equals(""))) action = "none";
        
        if (action.equals("none"))
        {
            // RENDER DEFAULT PAGE
            Vector list = processor.getRoles();
            context.put("roleList",list);
            context.put("isRoleSelected",Boolean.valueOf(false));
            
            targetPage = "vtl/admin/role_editor.vm";

        } else if (action.equals("get_modules"))
        {
            // GET LIST OF MODULES
            String role = request.getParameter("role");
            Vector moduleList = processor.getModules(role);
            context.put("moduleList",moduleList);
            
            Vector roleList = processor.getRoles();
            context.put("roleList",roleList);
            context.put("isRoleSelected",Boolean.valueOf(true));
            context.put("userRole",role);
            
            targetPage = "vtl/admin/role_editor.vm";
            
        } else if (action.equals("update_role"))
        {
            // UPDATE ROLE MODULE
            String role = request.getParameter("role");
            String[] modules = request.getParameterValues("module");
            processor.updateRoleModule(role, modules);
            
            // GET LIST OF MODULES
            Vector moduleList = processor.getModules(role);
            context.put("moduleList",moduleList);
            
            Vector roleList = processor.getRoles();
            context.put("roleList",roleList);
            context.put("isRoleSelected",Boolean.valueOf(true));
            context.put("userRole",role);
            
            targetPage = "vtl/admin/role_editor.vm";
        }
        
        Template template = engine.getTemplate(targetPage); 
        return template;        
    }    
}