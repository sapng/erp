/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.app;

import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.portal.velocity.VTemplate;

import org.apache.velocity.Template;

/**
 * @author Shaiful Nizam Tajul
 * @version 1.01
 */
public class RoleModule extends VTemplate
{
    private String targetPage;
    
    public Template doTemplate() throws Exception
    {
        
        HttpSession session = request.getSession();
        RoleProcessor processor = new RoleProcessor();
                                
        String action = request.getParameter("form_action");
        if ((action == null) || (action.equals(""))) action = "none";
        
        if (action.equals("none"))
        {
            // SHOW ROLE LIST
            Vector list = processor.getRoles();
            context.put("roleList",list);
            targetPage = "vtl/admin/role.vm";

        } else if (action.equals("add_role"))
        {
            // ADD ROLE
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            
            processor.addRole(name, description);
            
            Vector list = processor.getRoles();
            context.put("roleList",list);
            targetPage = "vtl/admin/role.vm";
            
        } else if (action.equals("update_role"))
        {
            // UPDATE ROLE
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            String oldName = request.getParameter("old_name");
            
            processor.updateRole(oldName, name, description);
            
            Vector list = processor.getRoles();
            context.put("roleList",list);
            targetPage = "vtl/admin/role.vm";
            
        } else if (action.equals("delete_role"))
        {
            // DELETE ROLE
            String name = request.getParameter("old_name");
            
            processor.deleteRole(name);
            
            Vector list = processor.getRoles();
            context.put("roleList",list);
            targetPage = "vtl/admin/role.vm";
        }
        Template template = engine.getTemplate(targetPage); 
        return template;        
    }    
}