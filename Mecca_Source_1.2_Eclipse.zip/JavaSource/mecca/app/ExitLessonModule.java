/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.app;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;

import javax.servlet.http.HttpSession;

import mecca.db.CollabDb;
import mecca.db.SQLRenderer;

import org.apache.velocity.Template;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class ExitLessonModule extends mecca.portal.velocity.VTemplate {

	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		String template_name = "vtl/collab/exit_lesson.vm";
		String lessonid = getId();
		context.put("lessonInfo", getLessonInfo(lessonid));
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	Hashtable getLessonInfo(String lessonid) throws Exception {
		CollabDb db = null;
		String sql = "";
		try {
			db = new CollabDb();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("l.lesson_id", lessonid);
			r.add("lesson_title");
			r.add("lesson_description");
			r.add("s.subject_id");
			r.add("s.subject_code");
			r.add("s.subject_title");
			r.add("s.subject_id", r.unquote("l.subject_id"));
			sql = r.getSQLSelect("lesson l, subject s");
			ResultSet rs = stmt.executeQuery(sql);
			Hashtable h = new Hashtable();
			if ( rs.next() ) {
				h.put("lessonTitle", rs.getString("lesson_title"));
				h.put("lessonDescription", rs.getString("lesson_description"));
				h.put("subjectId", rs.getString("subject_id"));
				h.put("subjectCode", rs.getString("subject_code"));
				h.put("subjectTitle", rs.getString("subject_title"));
			}
			return h;
		} finally {
			if ( db != null ) db.close();
		}
	}		
}	