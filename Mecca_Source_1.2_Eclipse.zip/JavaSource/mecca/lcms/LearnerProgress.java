/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms;

import java.io.File;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class LearnerProgress {
	
	public static Vector getReport(String learnerid, String courseid) throws Exception {

		Vector report = new Vector();
		String filename = Resource.getPATH() + courseid + "/imsmanifest.xml";
	
		if ( new File(filename).exists() ) {
			Vector container = ManifestParser.parse(filename);
			Vector v = (Vector) container.elementAt(0);
			for ( int i = 0; i < v.size(); i++ ) {
				StringTokenizer st = new StringTokenizer((String) v.elementAt(i), "|");
				String level = (String) st.nextToken(); //level
				String id = (String) st.nextToken(); // id
				String start_page = (String) st.nextToken(); //this sco start page
				String lesson_title = (String) st.nextToken(); //lesson title
				Hashtable item = new Hashtable();
				item.put("id", id);
				item.put("lesson_title",lesson_title);
				report.add(item);
			}
		}

		ScoData db = ScoDataFactory.get();

		for ( int i = 0; i < report.size(); i++ ) {
			Hashtable item = (Hashtable) report.elementAt(i);
			Hashtable scoData = db.get(learnerid, courseid, (String) item.get("id"));
			if ( scoData != null ) {
				if ( scoData.get("cmi.core.lesson_status") != null )
					item.put("lesson_status", scoData.get("cmi.core.lesson_status"));
				else
					item.put("lesson_status", "not attempted");
					
				if (scoData.get("cmi.core.exit") != null ) 
					item.put("exit_status", scoData.get("cmi.core.exit"));
				else 
					item.put("exit_status","");
					
				if (scoData.get("cmi.core.session_time") != null) 
					item.put("session_time", scoData.get("cmi.core.session_time"));
				else 
					item.put("session_time", "");
					
				if (scoData.get("cmi.core.entry") != null) 
					item.put("entry_status", scoData.get("cmi.core.entry"));
				else 
					item.put("entry_status", "");			
			} else {
				System.out.println("scodata is NULL");
				item.put("lesson_status", "not attempted");
				item.put("exit_status", "");
				item.put("session_time", "");
				item.put("entry_status", "");
			}			

		}
		return report;
	}
}