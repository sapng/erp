/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import nanoxml.XMLElement;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class ManifestOutput {
	
	private PrintWriter output = null;
	
	public static void main(String args[]) throws Exception {
		String filename = "imsmanifest.xml";
		new ManifestOutput().printToFile(filename, "Course 123");
	}	
	
	public void printToFile(String filename, String course_id) throws Exception {
		FileReader reader = null;		
		try {
			XMLElement manifest = new XMLElement();
			reader = new FileReader(filename);
			manifest.parseFromReader(reader);
			printToFile(manifest, course_id);
		} finally {
			if ( reader != null ) reader.close();	
		}
	}
	
	public void printToFile(XMLElement manifest, String course_id) throws Exception {
		try {
			String file_name = Resource.getPATH() + course_id + "/imsmanifest.xml";
			output = new PrintWriter(new BufferedWriter(new FileWriter(file_name)));
			output.println("<?xml version = \"1.0\"?>");
			output.println("<manifest>");
			XMLElement metadata = null;
			XMLElement organizations = null;
			XMLElement resources = null;
			
			Vector manifest_child = manifest.getChildren();
			for ( int i = 0; i < manifest_child.size(); i++ ) {
				XMLElement child = (XMLElement) manifest_child.elementAt(i);	
				if (child.getName().equals("metadata")) metadata = child ;
				else if (child.getName().equals("organizations")) organizations = child ;
				else if (child.getName().equals("resources")) resources = child ;
			}
			//enumerate elements from organizations
			//get default attr from organizations
			String organizations_default = (String) organizations.getAttribute("default");
			XMLElement organization = null;
			Vector organizations_child = organizations.getChildren();
			//for this version, only one organization is considered
			output.println("<organizations default=\"" + organizations_default + "\">");
			for ( int k = 0;k < organizations_child.size(); k++ ) {
				organization = (XMLElement) organizations_child.elementAt(k);	
				String organization_idref = (String) organization.getAttribute("identifier");
				output.println("<organization identifier=\"" + organization_idref + "\">");
				
				Vector organization_child = organization.getChildren();
				for ( int i = 0; i < organization_child.size(); i++ ) {
					
					XMLElement e = (XMLElement) organization_child.elementAt(i);
					
					String element_name = e.getName();

					if ( element_name.equals("item") ) {
						int itemLevel = 0;
						processItem(e, itemLevel);
					}
				}
				output.println("</organization>");
			}
			output.println("</organizations>");
			
			
			
			
			//enumerate elements from resources
			output.println("<resources>");
			XMLElement resource = null;
			if ( resources != null ) {
				Vector resources_child = resources.getChildren();
				for ( int i = 0; i < resources_child.size(); i++ ) {
					XMLElement e = (XMLElement) resources_child.elementAt(i);
					String idref = (String) e.getAttribute("identifier");
					String start_page = (String) e.getAttribute("href");

      				output.println("<resource identifier=\"" + idref + "\" type=\"webcontent\" adlcp:scormtype=\"sco\" href=\"" + start_page + "\">");										
					
					Vector v = e.getChildren();
					//String pages = "";
					for ( int k = 0; k < v.size(); k++ ) {
						XMLElement t = (XMLElement) v.elementAt(k);
						if ( t.getName().equals("file") ) {
							String page = (String) t.getAttribute("href");	
							output.println("<file href=\"" + page + "\"/>");
						}
					}
					
					output.println("</resource>");
				}
			}
			
			output.println("</resources>");
			output.println("</manifest>");
			
		} catch (Exception e) {
			System.out.println( "Error in parser : " + e.getMessage() );	
			//e.printStackTrace();
			throw e;
		} finally {
			if ( output != null ) output.close();
		}
		
	}
	
	void processItem(XMLElement e, int itemLevel) {
		String content = "";
		
		//get title
		XMLElement t = (XMLElement) e.getChildren().elementAt(0);
		if ( t.getName().equals("title") ) content = t.getContent();

		String idref = (String) e.getAttribute("identifierref");
		int idnull = 0;
		if ( idref == null ) {
			idnull++;
			idref = Integer.toString(idnull);
		}

		output.println(putSpace(itemLevel) + "<item identifier=\"" + idref + "\" identifierref=\"" + idref + "\">");
		output.println(putSpace(itemLevel) + "   <title>" + content + "</title>");
		
		//iterate thru next items in iterative manner
		Vector v = e.getChildren();
		itemLevel++;
		for ( int k = 0; k < v.size(); k++ ) {
			XMLElement itm = (XMLElement) v.elementAt(k);
			if ( itm.getName().equals("item") ) {
				processItem(itm, itemLevel);
			}
		}					
		output.println(putSpace(itemLevel - 1) + "</item>");
	}		
	
	static String putSpace(int n) {
		String s = "";
		for ( int i = 0; i < n; i++ ) s += "   ";
		return s;
	}
	
	private static void writeToFile(String file, String data) {
		PrintWriter out = null;
		try {
			out = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			out.print(data);
		} catch ( IOException e ) {
			System.out.println( e.getMessage() );
		} finally {
			if ( out != null ) out.close();
		}
	}	
}