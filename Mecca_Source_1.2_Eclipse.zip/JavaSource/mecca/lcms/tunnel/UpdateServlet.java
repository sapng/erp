/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms.tunnel;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.lcms.ScoData;
import mecca.lcms.ScoDataFactory;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class UpdateServlet extends HttpServlet {
	private String userid, courseid;
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			response.setContentType("application/x-java-serialized-object");
			HttpSession session = request.getSession(true);
			userid = (String) session.getAttribute("_portal_login");
			courseid = (String) session.getAttribute("courseid");			

			InputStream in = request.getInputStream();
			ObjectInputStream inputFromApplet = new ObjectInputStream(in);
			Hashtable data = (Hashtable) inputFromApplet.readObject();

			
			ScoData db = ScoDataFactory.get();
			db.update(userid, courseid, data);

			OutputStream outstr = response.getOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(outstr);
			oos.writeObject("true");
			oos.flush();
			oos.close();
			


		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("ERROR : " + e.getMessage());
		}
	}
	
}