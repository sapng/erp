/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms.tunnel;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class ElementServlet extends HttpServlet { 
	
	private Vector elements;
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			response.setContentType("application/x-java-serialized-object");
			HttpSession session = request.getSession(true);

			InputStream in = request.getInputStream();
			ObjectInputStream obinput = new ObjectInputStream(in);
			String courseid = (String) obinput.readObject();
			OutputStream outstr = response.getOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(outstr);
			
			
			Vector readonlys = new Vector();
			readonlys.addElement("cmi.core._children");
			readonlys.addElement("cmi.core.student_id"); 
			readonlys.addElement("cmi.core.student_name");
			readonlys.addElement("cmi.core.credit");
			readonlys.addElement("cmi.core.entry");
			readonlys.addElement("cmi.core.score._children");
			readonlys.addElement("cmi.core.total_time");
			readonlys.addElement("cmi.core.lesson_mode");
			readonlys.addElement("cmi.launch_data");
			
			
			Vector writeonlys = new Vector();
			writeonlys.addElement("cmi.core.exit");
			writeonlys.addElement("cmi.core.session_time");
			
			oos.writeObject(elements);
			oos.flush();
			oos.close();
			

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	
	
}