/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms.tunnel;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.lcms.Member;
import mecca.lcms.MemberData;
import mecca.lcms.MemberDataFactory;
import mecca.lcms.ScoData;
import mecca.lcms.ScoDataFactory;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class InitDataServlet extends HttpServlet {
	private String userid = "";
	private String username = "";
	private String courseid = "";
	private String scoId = "";
	
	public InitDataServlet() {  }
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			response.setContentType("application/x-java-serialized-object");
			HttpSession session = request.getSession(true);
			
			InputStream in = request.getInputStream();
			ObjectInputStream obinput = new ObjectInputStream(in);
			Object object = obinput.readObject();			
			if ( object != null ) {
				scoId = (String) object;
			}
			
			userid = (String) session.getAttribute("_portal_login");
			courseid = (String) session.getAttribute("courseid");

			OutputStream outstr = response.getOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(outstr);
			
			Hashtable item = prepareData();
			oos.writeObject(item);
			
			oos.flush();
			oos.close();


		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	
	//should be changed to prepareElement()
	private Hashtable prepareData() {
		try {
			String name = "";
			MemberData m = MemberDataFactory.get();
			Member member = m.getMember(userid);
			if ( member != null ) {
				name = member.getName();	
			} else {
				System.out.println("Member is NULL");
			}
		
			//get sco data
			//ScoData should be ScoElement
			//get the data from a database
			ScoData db = ScoDataFactory.get();
			Hashtable data = db.get(userid, courseid, scoId);
			//put extra information into the hashtable
			if ( data != null ) {
				//put global data
				data.put("scoId", scoId);
				data.put("cmi.core._children", putSupportedElements());
				data.put("cmi.core.student_id", userid);
				data.put("cmi.core.student_name", name);
				
				/*
				some data should be extracted from the imsmanifest file -
				these includes - adlcp:masteryscore,  adlcp:datafromlms, adlcp:prerequisites,
				adlcp:maxtimeallowed, adlcp:timelimitaction
				The APIAdapter is responsible in doing this
				*/
				data.put("cmi.launch_data", "");
				data.put("cmi.student_data.mastery_score", "");
				data.put("cmi.student_data.max_time_allowed", "");
				data.put("cmi.student_data.time_limit_action", "");				
			} else {
				System.out.println("DATA IS NULLLL");	
			}
			return data;
		} catch ( Exception e ) {
			e.printStackTrace();
		}
		return null;
	}
	
	//return student name in format Last Name, First Name -- mat saleh punye style
	/*
	private static String putStudentName(String name) {

	}
	*/
	
	//mandatory supported elements by the LMS
	// :) this is hardcoded -
	private static String putSupportedElements() {
		StringBuffer sb = new StringBuffer("");
		sb.append("student_id,");
		sb.append("student_name,");
		sb.append("lesson_location,");
		sb.append("credit,");
		sb.append("lesson_status,");
		sb.append("entry,");
		sb.append("score,");
		sb.append("total_time,");
		sb.append("exit,");
		sb.append("session_time");
		return sb.toString();
	}
}