/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms.tunnel;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.lcms.ManifestParser;
import mecca.lcms.Resource;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class ScoItemServlet extends HttpServlet {
	
	private Vector scoItems;
	 
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			response.setContentType("application/x-java-serialized-object");
			HttpSession session = request.getSession(true);

			InputStream in = request.getInputStream();
			ObjectInputStream inputFromApplet = new ObjectInputStream(in);
			String courseid = (String) inputFromApplet.readObject();
			OutputStream outstr = response.getOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(outstr);
			String filename = Resource.getPATH() + courseid + "/imsmanifest.xml";
			//System.out.println("Getting Resources from " + filename);
			if ( new File(filename).exists() ) {
				scoItems = ManifestParser.parse(filename);
				//testScoItems(scoItems);
			} else {
				scoItems = null;
			}

			//put the resources in the session object for later use
			//for example: to check the prerequisites			
			session.setAttribute("scoItems", scoItems);

			oos.writeObject(scoItems);
			oos.flush();
			oos.close();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}	
	
	void testScoItems(Vector v) {
		Vector scoList = (Vector) v.elementAt(0);
		Vector cmiElementList = (Vector) v.elementAt(1);
		Hashtable idenHash = (Hashtable) v.elementAt(2);
		for( int i=0; i < scoList.size(); i++ ) {
			System.out.println( (String) scoList.elementAt(i));
				
		}
		for( int i=0; i < cmiElementList.size(); i++ ) {
			System.out.println( (String) cmiElementList.elementAt(i));
				
		}	
		for (Enumeration e = idenHash.keys(); e.hasMoreElements();) {
			String key = (String) e.nextElement();
			System.out.println(key + " = " + (String) idenHash.get(key) );
		}
		
	}
	

	
}