/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public abstract class FileData {
	
	protected static String readField(String name) {
		String data = "";
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(name));
			data = reader.readLine();
			String txt = "";
			while ( ( txt = reader.readLine() ) != null ) {
				data += "\n" + txt;
			}
		} catch ( IOException e ) {
			System.out.println( e.getMessage() );
		} finally {
			try {
				if ( reader != null ) reader.close();
			} catch ( IOException e ) {}
		}
		return data;
	}
	
	protected static void addField(String name, String data) {
		PrintWriter out = null;
		try {
			out = new PrintWriter(new BufferedWriter(new FileWriter(name)));
			out.print(data);
		} catch ( IOException e ) {
			System.out.println( e.getMessage() );
		} finally {
			if ( out != null ) out.close();
		}
	}		
	
	//recursively delete files and directory
	public static boolean deleteDir(File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i=0; i<children.length; i++) {
				boolean success = deleteDir(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}
		return dir.delete();
	}	
	
}