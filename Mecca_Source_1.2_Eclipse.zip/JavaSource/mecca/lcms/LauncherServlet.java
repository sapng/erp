/**
  @Author: Shamsul Bahrin
  @Date: Jan, 2004
  Version 1.0
*/
package mecca.lcms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.portal.ClassLoadManager;
import mecca.portal.ErrorMsg;
import mecca.portal.velocity.VServlet;
import mecca.portal.velocity.VTemplate;

 

public class LauncherServlet extends VServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res)  throws ServletException, IOException    {
		doPost(req, res);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException  {
		PrintWriter out = res.getWriter();
		HttpSession session = req.getSession();
		res.setContentType("text/html");
		String uri = req.getRequestURI();
		String s1 = uri.substring(1);
		context.put("appname", s1.substring(0, s1.indexOf("/")));		
        String pathInfo = req.getPathInfo();
        pathInfo = pathInfo.substring(1); //get rid of the first '/'
		String module = pathInfo != null ? pathInfo : "none";	
		session.setAttribute("_app_action", module);
		session.setAttribute("_app_module", module);
		context.put("session", session);	

		ServletContext servletContext = getServletConfig().getServletContext();
		try {
			
			VTemplate content = null;
			try {
				//Class klazz = Class.forName(module);
				//content = ((VTemplate) klazz.newInstance());
				content = (VTemplate) ClassLoadManager.load(module, req.getRequestedSessionId());
				content.setEnvironment(engine, context, req, res);		
				content.setServletConfig(getServletConfig());	
			} catch ( ClassNotFoundException cnfex ) {
				content = new ErrorMsg(engine, context, req, res);
				((ErrorMsg) content).setError("ClassNotFoundException : " + cnfex.getMessage());				
			} catch ( InstantiationException iex ) {
				content = new ErrorMsg(engine, context, req, res);
				((ErrorMsg) content).setError("InstantiationException : " + iex.getMessage());			
			} catch ( IllegalAccessException illex ) {
				content = new ErrorMsg(engine, context, req, res);
				((ErrorMsg) content).setError("IllegalAccessException : " + illex.getMessage());			
			} catch ( Exception ex ) {
				content = new ErrorMsg(engine, context, req, res);
				((ErrorMsg) content).setError("Other Exception during class initiation : " + ex.getMessage());	
				ex.printStackTrace();					
			}	
			
			try {
				if ( content != null ) content.print();
			} catch ( Exception ex ) {
				out.println( ex.getMessage() );
			}				
			
		} catch ( Exception ex ) {
			System.out.println( ex.getMessage() );	
		}
	}
}
