/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */



package mecca.lcms;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */



public class Member {
	private String id;
	private String login;
	private String password;
	private String name;
	private String icno;
	private String address;
	private String phone;
	public Member(String id) {
		this.id = id;
	}
	public Member() {
		this.id = null;
	}	
	
	public void setId(String id) { this.id = id; }
	public void setLogin(String login) { this.login = login; }
	public void setPassword(String password) { this.password = password; }
	public void setIcno(String icno) { this.icno = icno; }
	public void setName(String name) { this.name = name; }
	public void setAddress(String address) { this.address = address; }
	public void setPhone(String phone) { this.phone = phone; }
	
	public String getId() { return id; }
	public String getIcno() { return icno; }
	public String getLogin() { return login; }
	public String getPassword() { return password; }
	public String getName() { return name; }
	public String getAddress() { return address; }
	public String getPhone() { return phone; }
	
	public static class NameComparator implements java.util.Comparator {
		public int compare(Object o1, Object o2) {
			Member member1 = (Member) o1;
			Member member2 = (Member) o2;
			return member1.compareByName(member2);
		}	
	}

	public int compareByName(Member member2) {
		String name2 = member2.getName();
		return name.compareTo(name2);
	}	
	
}