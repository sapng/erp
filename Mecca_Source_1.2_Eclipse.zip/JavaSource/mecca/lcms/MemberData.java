/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */



package mecca.lcms;

import java.util.Collection;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public interface MemberData {
	
	public static final byte BEGIN = 1;
	public static final byte CONTAIN = 2;	
	
	public Collection getMembers() throws Exception;
	
	//public Collection getMembers(String name, byte type) throws Exception;
	
	public Member getMember(String id) throws Exception;
	
	//public Member getMember(String id, String password) throws Exception;
	
	public boolean add(Member member); 

	public boolean update(Member member);
	
	public boolean delete(Member member);
	
	
	public boolean isLoginExists(String login);
	
	public boolean isIdExists(String id);
	
	public String getMemberId(String login);

	public Member findByLogin(String login);
	
}