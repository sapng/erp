/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms;

import java.io.File;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Collection;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.SQLRenderer;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class CourseDb implements CourseData {
	

	public boolean add(Course course) throws Exception {
		if ( createFolder(course) ) {
		
			Db db = null;
			String sql = "";
			try {
				db = new Db();
				Statement stmt = db.getStatement();
				SQLRenderer r = new SQLRenderer();
				r.add("course_id", course.getId());
				r.add("title", course.getTitle());
				sql = r.getSQLInsert("course");
				stmt.executeUpdate(sql);
				
			} finally {
				if ( db != null ) db.close();
			}
			
			return true;
		}
		else 
			return false;
	}
	
	private boolean createFolder(Course course) {
		boolean result = false;
		//create new folder, but first check if folder by this name already exists.
		System.out.println("creting folder=" + Resource.getPATH() + course.getId());
		File dir = new File(Resource.getPATH() + course.getId());
		if ( !dir.exists() ) {
			dir.mkdir();
			result = true;
		} else {
			System.out.println("Course id already exists");	
		}
		return result;
	}
	

	
	public boolean delete(String course_id) throws Exception {
		deleteDir(new java.io.File(Resource.getPATH() + course_id));
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("course_id", course_id);
			sql = r.getSQLDelete("course");
			stmt.executeUpdate(sql);
		} finally {
			if ( db != null ) db.close();
		}
		return true;
	}
	
	//recursively delete files and directory
	private boolean deleteDir(java.io.File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i=0; i<children.length; i++) {
				boolean success = deleteDir(new java.io.File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}
		return dir.delete();
	}	
	
	public boolean update(Course course) {
		
		return false;
	}
	
	public Collection getCourses() throws Exception {
		Vector list = new Vector();
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("course_id");
			r.add("title");
			sql = r.getSQLSelect("course");
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next() ) {
				Course course = new Course();
				prepareData(course, rs);
				list.addElement(course);
			}
		} finally {
			if ( db != null) db.close();
		}
		return list;
	}
	
	public Course getCourse(String course_id) throws Exception {
		Course course = null;
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("course_id");
			r.add("title");
			r.add("course_id", course_id);
			sql = r.getSQLSelect("course");
			ResultSet rs = stmt.executeQuery(sql);
			if ( rs.next() ) {
				course = new Course();
				prepareData(course, rs);
			}
		} finally {
			if ( db != null) db.close();
		}		
		
		return course;	
	}
	
	private void prepareData(Course course, ResultSet rs) throws Exception {
		course.setId(rs.getString("course_id"));
		course.setTitle(rs.getString("title"));	
	}

}