/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.Hashtable;

import mecca.db.Db;
import mecca.db.SQLRenderer;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class ScoDb implements ScoData {
	
	public boolean update(String userid, String courseid, Hashtable data) throws Exception {
		boolean result = true;
		if ( userid == null || "".equals(userid) ) return false;
		String scoId = (String) data.get("scoId");
		if ( scoId != null || !scoId.equals("null") ) {
			
			Db db = null;
			String sql = "";
			try {
				db = new Db();
				Statement stmt = db.getStatement();
				SQLRenderer r = new SQLRenderer();
				Enumeration keys = data.keys();
				while ( keys.hasMoreElements() ) {
					String key = (String) keys.nextElement();
					if ( key.indexOf("cmi.") == 0 && course_items.indexOf(key) < 0 ) {
						String value = (String) data.get(key);
						r.clear();
						
						r.add("member_id");
						r.add("member_id", userid);
						r.add("course_id", courseid);
						r.add("sco_id", scoId);
						r.add("cmi_name", key);
						
						boolean isExist = false;
						{
							sql = r.getSQLSelect("learner_sco");
							ResultSet rs = stmt.executeQuery(sql);
							if ( rs.next() ) isExist = true;
						}
						if ( isExist ) {
							r.clear();
							r.update("member_id", userid);
							r.update("course_id", courseid);
							r.update("sco_id", scoId);
							r.update("cmi_name", key);
							r.add(( "cmi.core._children".equals(key) || "cmi.comments".equals(key) ) ? 
							        "cmi_value_text" : "cmi_value", value); 
							sql = r.getSQLUpdate("learner_sco");
							stmt.executeUpdate(sql);
						} 
						else {
							r.clear();
							r.add("member_id", userid);
							r.add("course_id", courseid);
							r.add("sco_id", scoId);
							r.add("cmi_name", key);
							r.add(( "cmi.core._children".equals(key) || "cmi.comments".equals(key) ) ? 
							        "cmi_value_text" : "cmi_value", value); 
							sql = r.getSQLInsert("learner_sco");
							
							//System.out.println(sql);
							
							stmt.executeUpdate(sql);
						}
					}
				}
			} finally {
				if ( db != null ) db.close();
			}
		}
		return result;
	}	
	
	public boolean add(String userid, String courseid, Hashtable data) throws Exception {
		return update(userid, courseid, data);
	}
	
	public boolean delete(String userid, String courseid) throws Exception {
		boolean result = true;
		
		return result;	
	}
	
	/**
	Retrieve learner scos tracking
	*/
	public Hashtable get(String userid, String courseid, String scoId) throws Exception {
		Hashtable data = new Hashtable();
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("cmi_name");
			r.add("cmi_value");
			r.add("cmi_value_text");
			r.add("member_id", userid);
			r.add("course_id", courseid);
			r.add("sco_id", scoId);
			sql = r.getSQLSelect("learner_sco");
			//System.out.println(sql);
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next() ) {
				String key = rs.getString("cmi_name");
				String value = ( "cmi.core._children".equals(key) || "cmi.comments".equals(key) ) ? 
				        rs.getString("cmi_value_text") : rs.getString("cmi_value") ;
				data.put(key, value);	
			}
		} finally {
			if ( db != null ) db.close();
		}
		return data;
	}
	
	public Hashtable get(String userid, String courseid) throws Exception {
		Hashtable data = new Hashtable();
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			r.add("sco_id");
			r.add("cmi_name");
			r.add("cmi_value");
			r.add("cmi_value_text");
			r.add("member_id", userid);
			r.add("course_id", courseid);
			sql = r.getSQLSelect("learner_sco", "sco_id");
			//System.out.println(sql);
			ResultSet rs = stmt.executeQuery(sql);
			String sco_id = "";
			Hashtable h = null;
			while ( rs.next() ) {
				String sco = rs.getString("sco_id");
				if ( !sco_id.equals(sco) ) {
					if ( h != null ) data.put(sco, h);
					sco_id = sco;
					h = new Hashtable();
					h.put("id", sco);
				}
				String key = rs.getString("cmi_name");
				String value = ( "cmi.core._children".equals(key) || "cmi.comments".equals(key) ) ? 
				        rs.getString("cmi_value_text") : rs.getString("cmi_value") ;
				h.put(key, value);	
			}
		} finally {
			if ( db != null ) db.close();
		}
		return data;
	}	
	

}