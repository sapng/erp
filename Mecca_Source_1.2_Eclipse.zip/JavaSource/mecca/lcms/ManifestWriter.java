/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.crimson.jaxp.DocumentBuilderFactoryImpl;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class ManifestWriter { 
	
	private String manifest_file = "";
	private String manifest_id = "";
	private String course_id = "";
	
	private Vector levels;
	private Vector scos;
	private Vector sco_pages;
	private Vector sco_titles;
	private Hashtable web_pages;
	
	public static void main(String args[]) {
		try {
			ManifestWriter w = new ManifestWriter();
			w.setCourseId(args[0]);
			w.readTempManifest();
			w.create();
		} catch ( Exception e ) {
			System.out.println( e.getMessage() );
		}
	}
	

	
	public void setCourseId(String s) { course_id = s; }
	
	private void readTempManifest() {
		levels = new Vector();
		scos = new Vector();
		sco_pages = new Vector();
		sco_titles = new Vector();
		web_pages = new Hashtable();
		File manifest = new File(Resource.getPATH() + course_id + "/imsmanifest._dat");

		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(manifest));
			String txt = "";
			while ( ( txt = reader.readLine() ) != null ) {
				System.out.println(txt);
				if ( txt.indexOf("|") > 0 ) {
					StringTokenizer st = new StringTokenizer(txt, "|");
					String level = st.nextToken();
					levels.add(level);
					String sco_id = st.nextToken();
					scos.add(sco_id);
					sco_pages.add(st.nextToken());
					sco_titles.add(st.nextToken());
					Vector p = new Vector();
					while ( st.hasMoreTokens() ) {
						p.addElement(st.nextToken());
					}
					web_pages.put(sco_id, p);
				}
			}
		} catch ( IOException e ) {
			System.out.println( e.getMessage() );
		} finally {
			try {
				if ( reader != null ) reader.close();
			} catch ( IOException e ) {}
		}		
	}
	
	public static void create(String course_id) throws Exception {
		ManifestWriter w = new ManifestWriter();
		w.setCourseId(course_id);
		w.readTempManifest();
		w.create();
	}
	
	private void create() throws Exception {
		
		Document xmlDoc = null;
		DocumentBuilderFactory dbFactory = DocumentBuilderFactoryImpl.newInstance();
		DocumentBuilder docBuilder = dbFactory.newDocumentBuilder();
		xmlDoc = docBuilder.newDocument();  
				
		if (manifest_id.equals("")) manifest_id = "Generated_Manifest";
		if (course_id.equals("")) course_id = "Test_Course";
		
		Element manifest = xmlDoc.createElement("manifest");
		
		manifest.setAttribute("identifier", manifest_id);
		manifest.setAttribute("version", "1.1");
		manifest.setAttribute("xmlns", "http://www.imsproject.org/xsd/imscp_rootv1p1p2");
		manifest.setAttribute("xmlns:adlcp", "http://www.adlnet.org/xsd/adlcp_rootv1p2");
		manifest.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
		manifest.setAttribute("xsi:schemaLocation", "http://www.imsproject.org/xsd/imscp_rootv1p1p2 imscp_rootv1p1p2.xsd  http://www.imsglobal.org/xsd/imsmd_rootv1p2p1 imsmd_rootv1p2p1.xsd  http://www.adlnet.org/xsd/adlcp_rootv1p2 adlcp_rootv1p2.xsd");

		Element metadata = xmlDoc.createElement("metadata");
		manifest.appendChild(metadata);
		
		Element organizations = xmlDoc.createElement("organizations");
		organizations.setAttribute("default", course_id);
		
		Element organization = xmlDoc.createElement("organization");
		organization.setAttribute("identifier", course_id);
				
		
		
		
		//LET'S SUPPORT UP TO TEN LEVELS OF HIERARCHY - THIS IS MORE THAN ENOUGH I THINK!!
		Object[] parent = new Object[10];
      	Element parent_item = null;
      	int level = 0;
      	int nextlevel = 0;
		for ( int i = 0; i < scos.size(); i++ ) {
      		String id = (String) scos.elementAt(i);

      		Element item = xmlDoc.createElement("item");
      		item.setAttribute("identifier", id);
      		item.setAttribute("identifierref", id);

      		Element title = xmlDoc.createElement("title");
      		title.appendChild(xmlDoc.createTextNode((String) sco_titles.elementAt(i)));	
      		item.appendChild(title);
      		
   			level = Integer.parseInt((String) levels.elementAt(i));
   			parent[level] = item;      		

      		if ( level == 0 ) {
	      		organization.appendChild(item);
      		} 	else {
	      		((Element) parent[level - 1]).appendChild(item);
      		}
      	}		
      	
      	organizations.appendChild(organization);
      	manifest.appendChild(organizations);
      	
		Element resources = xmlDoc.createElement("resources");
   		for ( int i = 0; i < scos.size(); i++ ) {
      		Element resource = xmlDoc.createElement("resource");
      		resource.setAttribute("identifier", (String) scos.elementAt(i));
      		resource.setAttribute("type", "webcontent");
      		resource.setAttribute("adlcp:scormtype", "sco");
      		resource.setAttribute("href", (String) sco_pages.elementAt(i));
      		
      		Vector p = (Vector) web_pages.get((String) scos.elementAt(i) );
      		for ( int k = 0; k < p.size(); k++ ) {
	      		Element file = xmlDoc.createElement("file");
	      		file.setAttribute("href", (String) p.elementAt(k));
	      		resource.appendChild(file);
      		}
      		
      		resources.appendChild(resource);
      	}		
		
      	manifest.appendChild(resources);
      	xmlDoc.appendChild(manifest);
		
		
   		String file_name = Resource.getPATH() + course_id + "/imsmanifest.xml";
   		writeToFile(file_name, generateXMLString(xmlDoc));		
	}
	
    private String generateXMLString(Document xmlDoc) throws IOException {
	    String str = "";
	    StringWriter strWriter = null;
	    XMLSerializer xmlSer = null;
	    OutputFormat outFormat = null;
	    
	    xmlSer = new XMLSerializer();
	    strWriter = new StringWriter();
	    outFormat = new OutputFormat();
	    
    	//Setup format settings
    	outFormat.setEncoding("UTF-8");
    	outFormat.setVersion("1.0");
    	outFormat.setIndenting(true);
    	outFormat.setIndent(4);
	    
    	//Define a Writer
    	xmlSer.setOutputCharStream(strWriter);
	    	
    	//Apply the format settings
    	xmlSer.setOutputFormat(outFormat);
	    	
    	//Serialize XML Document
    	xmlSer.serialize(xmlDoc);
    	str = strWriter.toString();
    	strWriter.close();
    	
    	//Xystem.out.println(str);
    	
    	return str;
	    
    }		
	
	private static void writeToFile(String file, String xmlString) {
		PrintWriter out = null;
		try {
			out = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			out.print(xmlString);
		} catch ( IOException e ) {
			System.out.println( e.getMessage() );
		} finally {
			if ( out != null ) out.close();
		}
	}	
	
}