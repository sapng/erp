/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */



package mecca.lcms;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class Unzip {
	
	public static void main(String args[]) {
		String zipFilename = args[0];
		if ( args.length == 2 ) unzipFiles(zipFilename, args[1]);
		else  unzipFiles(zipFilename, "");
	 }
	 
	public static void unzipFiles(String zipFilename) {
		unzipFiles(zipFilename, "");	
	}
	 
	public static void unzipFiles(String zipFilename, String folder) {
		ZipFile zip = null;
	    try {
		    System.out.println(zipFilename + ", " + folder);
		    zipFilename = zipFilename.replace('/', java.io.File.separatorChar);
	        // Open the ZIP file
	        zip = new ZipFile(zipFilename);
	        // Prepare a buffer
	    	byte[] buffer = new byte[16384];
	        // Enumerate each entry in the zip file
	        for (Enumeration entries = zip.entries(); entries.hasMoreElements();) {
				ZipEntry entry = (ZipEntry) entries.nextElement();
				//If the entry is not a directory - unzip it
				if ( !entry.isDirectory()) {
					//Get the filename
					String filename = entry.getName();
					//Make the filename proper
					filename = filename.replace('/', java.io.File.separatorChar);
					//Where to unzip the file
					filename = !"".equals(folder) ? folder + java.io.File.separatorChar + filename : filename;
					//System.out.println(filename);
					//Create a destination file object
					java.io.File destFile = new java.io.File(filename);
					//create folders
					String parent = destFile.getParent();
         			if ( parent != null )  {
            			java.io.File parentFile = new java.io.File(parent);
            			if ( !parentFile.exists() )  {
               				parentFile.mkdirs();
            			}
         			}
         			
         			//Get inputstream for this entry
         			InputStream in = zip.getInputStream(entry);
         			//Open the output stream where the inputstream from this entry will go
         			OutputStream outs = new FileOutputStream(filename);
         			//Write to outputstream
         			int count;
         			while ( (count=in.read(buffer)) != -1 ) outs.write(buffer, 0, count);         			
         			//close all stream
         			in.close();
         			outs.close();
         								
				}
	        }
	    } catch (IOException e) {
		    System.out.println(e.getMessage());
	    } finally {
		    try {
		    	if ( zip != null ) zip.close();
	    	} catch ( IOException e2) {}
	    }
	}			 	
}
