/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms;

import java.io.FileReader;
import java.util.Hashtable;
import java.util.Vector;

import nanoxml.XMLElement;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class ManifestParser {
	
	
	
	public static Vector parse(String filename) throws Exception {
		Vector result = new Vector();
		Vector runtimes = new Vector();
		FileReader reader = null;
		//Map for identfier and identifieref
		Hashtable idenHash = new Hashtable();		
		try {
			XMLElement manifest = new XMLElement();
			reader = new FileReader(filename);
			manifest.parseFromReader(reader);
			XMLElement metadata = null;
			XMLElement organizations = null;
			XMLElement resources = null;
			
			Vector idseq = new Vector();
			Vector manifest_child = manifest.getChildren();
			for ( int i = 0; i < manifest_child.size(); i++ ) {
				XMLElement child = (XMLElement) manifest_child.elementAt(i);	
				if (child.getName().equals("metadata")) metadata = child ;
				else if (child.getName().equals("organizations")) organizations = child ;
				else if (child.getName().equals("resources")) resources = child ;
			}
			//enumerate elements from organizations
			Hashtable itemHash = new Hashtable();

			//this to store runtimes metadata set in imsmanifest
			Hashtable runtimeHash = new Hashtable();
			XMLElement organization = null;
			Vector organizations_child = organizations.getChildren();
			for ( int i = 0; i < organizations_child.size(); i++ ) {
				organization = (XMLElement) organizations_child.elementAt(i);	
			}
			Vector organization_child = organization.getChildren();
			for ( int i = 0; i < organization_child.size(); i++ ) {
				XMLElement e = (XMLElement) organization_child.elementAt(i);
				String element_name = e.getName();
				if ( element_name.equals("item") ) {
					int itemLevel = 0;
					processItem(e, idseq, itemHash, runtimes, itemLevel, idenHash);
				}
			}
			//enumerate elements from resources
			XMLElement resource = null;
			if ( resources != null ) {
				Vector resources_child = resources.getChildren();
				for ( int i = 0; i < resources_child.size(); i++ ) {
					XMLElement e = (XMLElement) resources_child.elementAt(i);
					String idref = (String) e.getAttribute("identifier");
					String start_page = (String) e.getAttribute("href");
					Vector v = e.getChildren();
					String pages = "";
					for ( int k = 0; k < v.size(); k++ ) {
						XMLElement t = (XMLElement) v.elementAt(k);
						if ( t.getName().equals("file") ) {
							pages += "|" + (String) t.getAttribute("href");	
						}
					}
					Item item = (Item) itemHash.get(idref);
					if ( item != null ) {
				
						item.start_page = start_page;
						item.pages = pages;
					}
				}
			}
	
			if ( idseq.size() > 0 ) {
				for ( int i = 0; i < idseq.size(); i++ ) {
					Item item = (Item) idseq.elementAt(i);
					if ( item.start_page == null ) item.start_page = "undefined";
					if ( item.pages == null ) item.pages = "|undefined";
					result.add(item.level + "|" + item.idref + "|" + item.start_page + "|" + item.title + item.pages);
				}
			} else {
				throw new Exception("Can't require items in manifest file!!");	
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if ( reader != null ) reader.close();
		}
		
		Vector container = new Vector();
		container.add(result);
		container.add(runtimes);
		container.add(idenHash);
		
		return container;
	}
	
	static void processItem(XMLElement e, Vector idseq, Hashtable itemHash, Vector runtimes, int itemLevel, Hashtable idenHash) {
		String content = "";
		String idref = e.getAttribute("identifierref") != null ? (String) e.getAttribute("identifierref") : "null";
		String iden = e.getAttribute("identifier") != null ? (String) e.getAttribute("identifier") : "null";
		idenHash.put(iden, idref);	
		Vector childs = e.getChildren();
		for ( int i = 0; i < childs.size(); i++ ) {
			XMLElement elm = (XMLElement) childs.elementAt(i);
			String s = elm.getName();
			if ( s.equals("title") ) content = elm.getContent();
			else if ( s.indexOf("adlcp:") == 0 ) {
				int ind = s.indexOf(":");
				String runt = idref + "|" + s.substring(ind+1) + "=" + elm.getContent();
				runtimes.add(runt);
			}
		}

		Item item = new Item();
		item.level = Integer.toString(itemLevel);
		item.idref = idref;
		item.title = content;
		itemHash.put(idref, item);
		idseq.add(item);  //to store the correct sequence			
		
		//iterate thru next items in iterative manner
		Vector v = e.getChildren();
		itemLevel++;
		for ( int k = 0; k < v.size(); k++ ) {
			XMLElement itm = (XMLElement) v.elementAt(k);
			if ( itm.getName().equals("item") ) {
				processItem(itm, idseq, itemHash, runtimes, itemLevel, idenHash);
			}
		}					
	}		
	
	static class Item {
		String level;
		String idref;
		String iden;
		String title;
		String start_page;
		String pages;	
	}
	
	public static void main(String args[]) throws Exception {
		String dir = args[0];
		String filename = dir + "\\imsmanifest.xml";
		System.out.println(filename);
		Vector container = parse(filename);
		Vector v = (Vector) container.elementAt(0);
		Vector r = (Vector) container.elementAt(1);
		for ( int i = 0; i < v.size(); i++ ) {
			System.out.println((String) v.elementAt(i));
		}
		System.out.println("=====");
		for ( int i = 0; i < r.size(); i++ ) {
			System.out.println((String) r.elementAt(i));
		}
	}	
}