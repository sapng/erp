/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms.modules;

import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class PreRequisitesModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		String template_name = "vtl/lcms/pre_requisites.vm";
		
		String userid = (String) session.getAttribute("_portal_login");
		String courseid = (String) session.getAttribute("courseid");
		String sco = (String) session.getAttribute("sco_id");
		Vector preqScos = (Vector) session.getAttribute("preq_scos");
		String preqStatus = (String) session.getAttribute("preq_scos_status");
		String preqRelation = (String) session.getAttribute("preq_scos_relation");
		//System.out.println("status=" + preqStatus);
		String scoTitle = "";
		Vector preScoTitles = new Vector();
		Vector scoItems = (Vector) session.getAttribute("scoItems"); //from ScoItemServlet
		Vector scoList = (Vector) scoItems.elementAt(0);
		Hashtable scoTbl = new Hashtable();
		for( int i=0; i < scoList.size(); i++ ) {
			int cnt = 0;
			String id = "";
			for (
				StringTokenizer tokens = new StringTokenizer((String) scoList.elementAt(i), "|");
				tokens.hasMoreTokens();cnt++) {
				String token = tokens.nextToken();
				if ( cnt == 1 ) {
					id = token;
				}
				else if ( cnt == 3 ) {
					scoTbl.put(id, token);
				}

			}
		}
		//the sco titles		
		scoTitle = (String) scoTbl.get(sco);
		for ( int i=0; i<preqScos.size(); i++) {
			Hashtable h = new Hashtable();
			h.put("title", (String) scoTbl.get( (String) preqScos.elementAt(i) ));
			h.put("status", preqStatus.substring(i,i+1));
			if ( i < preqScos.size() - 1 )
				h.put("relation", preqRelation.substring(i,i+1));
			else
				h.put("relation", "");
			preScoTitles.addElement(h);
		}
		
		context.put("scoTitle", scoTitle);
		context.put("preScoTitles", preScoTitles);
		
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	
}