/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms.modules;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.lcms.Course;
import mecca.lcms.CourseData;
import mecca.lcms.CourseDataFactory;
import mecca.lcms.Resource;
import mecca.lcms.Unzip;

import org.apache.velocity.Template;

import com.jspsmart.upload.Files;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */



public class ListFilesModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		String template_name = "vtl/lcms/list_files.vm";
		String errorMsg = "";
		String submit = getParam("command");
		if ( "createfolder".equals(submit) ) {
			createFolder(session);	
		} 
		else if ( "uploadfile".equals(submit) ) {
			uploadFile(session);
		}
		else if ( "uploadpif".equals(submit) ) {
			uploadPIF(session);
		}
		else if ( "delete".equals(submit) ) {
			String current_dir = (String) session.getAttribute("current_dir");	
			String name = getParam("file");
			deleteDir(new File(current_dir + "/" + name));
			String dir = getParam("dir");
			listFiles(session, dir);
		} 
		else if ( "deletefiles".equals(submit) ) {
			
			String current_dir = (String) session.getAttribute("current_dir");
			
			String[] files = request.getParameterValues("files");
			String[] folders = request.getParameterValues("folders");
			
			if ( files != null ) {
				for ( int i=0; i < files.length; i++ ) {
					deleteDir(new File(current_dir + "/" + files[i]));
				}
				
			}
			
			if ( folders != null ) {
				for ( int i=0; i < folders.length; i++ ) {
					deleteDir(new File(current_dir + "/" + folders[i]));
				}				
				
				
			}

			String dir = getParam("dir");
			listFiles(session, dir);
		}		
		else {
			String dir = request.getParameter("dir") != null ? request.getParameter("dir") : "";
			listFiles(session, dir);
		}
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	void listFiles(HttpSession session, String dir) throws Exception {
		context.put("dir", dir);		
		String course_id = "";
		String course_title = "";
		if ( request.getParameter("course_id") != null ) {
			course_id = request.getParameter("course_id");
			CourseData data = CourseDataFactory.get();
			Course course = data.getCourse(course_id);
			course_title = course.getTitle();
			session.setAttribute("course", course);
		} else {
			Course course = (Course) session.getAttribute("course");
			course_id = course.getId();
			course_title = course.getTitle();
		}
		context.put("course_id", course_id);
		context.put("course_title", course_title);
		
		//to determine up dir
		String upDir = "";
		int last = dir.lastIndexOf('/');
		if ( last > -1 ) upDir = dir.substring(0, last);
		context.put("upDir", upDir);
		
		String current_dir = Resource.getPATH() + course_id + dir;
		session.setAttribute("current_dir", current_dir);
		Vector dirs = new Vector();
		for ( StringTokenizer st = new StringTokenizer(dir, "/"); st.hasMoreTokens();) {
			dirs.addElement(st.nextToken());
		}
		context.put("dirs", dirs);
		Hashtable goDirTbl = new Hashtable(); 
		for ( int i=0; i < dirs.size(); i++ ) {
			String goDir = "";
			for ( int k = 0; k < i; k++ ) {
				goDir += "/" + (String) dirs.elementAt(k);
			}
			goDir += "/" + (String) dirs.elementAt(i);
			goDirTbl.put(dirs.elementAt(i), goDir);
		}
		context.put("goDirTbl", goDirTbl);
		
		List names = new ArrayList();
		List folders = new ArrayList();
		//System.out.println(current_dir);
		File files[] = new File(current_dir).listFiles();
		
		for ( int i = 0; i < files.length; i++ ) {
			if ( files[i].isDirectory() ) folders.add(files[i].getName());
			else {
				if ( files[i].getName().indexOf("._dat") < 0 ) names.add(files[i].getName());
			}
		}	
		
		Iterator ifolders = folders.iterator();
		context.put("ifolders", ifolders);
		
		Iterator inames = names.iterator();
		context.put("inames", inames);	
	}	
	
	void createFolder(HttpSession session) throws Exception {
		String current_dir = (String) session.getAttribute("current_dir");	
		String dir = request.getParameter("dir");
		String foldername = request.getParameter("foldername");
		if ( !foldername.equals("") ) {
			new File(current_dir + "/" + foldername).mkdir();
		}
		listFiles(session, dir);
	}
	
	void uploadFile(HttpSession session) throws Exception {
		String current_dir = (String) session.getAttribute("current_dir");	
		//com.jspsmart.upload.SmartUpload myUpload = new com.jspsmart.upload.SmartUpload();
		//myUpload.initialize(getServletConfig(), request, response);
		mecca.upload.SmartUpload2 myUpload = new mecca.upload.SmartUpload2();
		myUpload.initialize2(session.getServletContext(), request, response);			
		myUpload.upload();
		int count2 = myUpload.save( current_dir, myUpload.SAVE_PHYSICAL);
		String dir = getParam("dir");
		listFiles(session, dir);		
	}
	
	void uploadPIF(HttpSession session) throws Exception {
		String current_dir = (String) session.getAttribute("current_dir");	
		//com.jspsmart.upload.SmartUpload myUpload = new com.jspsmart.upload.SmartUpload();
		//myUpload.initialize(getServletConfig(), request, response);
		mecca.upload.SmartUpload2 myUpload = new mecca.upload.SmartUpload2();
		myUpload.initialize2(session.getServletContext(), request, response);		
		myUpload.upload();
		int count2 = myUpload.save( current_dir, myUpload.SAVE_PHYSICAL);
		String dir = getParam("dir");
		Files files =myUpload.getFiles();
		if ( files.getCount() > 0 ) {
			com.jspsmart.upload.File file = files.getFile(0);
			Unzip.unzipFiles(current_dir + "/" + file.getFileName(), current_dir);
			deleteDir(new java.io.File(current_dir + "/" + file.getFileName()));
		}
		listFiles(session, dir);
	}
	
		
	
	//recursively delete files and directory
	boolean deleteDir(java.io.File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i=0; i<children.length; i++) {
				boolean success = deleteDir(new java.io.File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}
		return dir.delete();
	}	
			
}
