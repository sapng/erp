/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms.modules;

import java.io.File;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.lcms.Course;
import mecca.lcms.CourseData;
import mecca.lcms.CourseDataFactory;
import mecca.lcms.ManifestParser;
import mecca.lcms.Resource;
import mecca.lcms.ScoData;
import mecca.lcms.ScoDataFactory;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */


public class LearnerProgressModule extends mecca.portal.velocity.VTemplate {
	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		
		String template_name = "vtl/lcms/learner_progress.vm";
		String errorMsg = "";
		String learnerid = request.getParameter("learnerid");
		String courseid = request.getParameter("courseid");
		
		String submit = getParam("command");
		
		if ( "reset".equals(submit) ) {
			resetAllValues();
		}
		
		Vector scoIds = new Vector();
		Vector report = new Vector();
		
		context.put("report", report);
		
		CourseData dbCourse = CourseDataFactory.get();
		Course course = dbCourse.getCourse(courseid);
		
		context.put("course", course);
		context.put("learnerid", learnerid);
		
		//read data from manifest file - to get the lesson order
		String course_title = course.getTitle();
		String filename = Resource.getPATH() + courseid + "/imsmanifest.xml";
	
		if ( new File(filename).exists() ) {
			Vector container = ManifestParser.parse(filename);
			Vector v = (Vector) container.elementAt(0);
			for ( int i = 0; i < v.size(); i++ ) {
				StringTokenizer st = new StringTokenizer((String) v.elementAt(i), "|");
				String level = (String) st.nextToken(); //level
				String id = (String) st.nextToken(); // id
				String start_page = (String) st.nextToken(); //this sco start page
				String lesson_title = (String) st.nextToken(); //lesson title
				Hashtable item = new Hashtable();
				item.put("id", id);
				item.put("lesson_title",lesson_title);
				report.add(item);
			}
		}
		
		//get student sco data from database
		ScoData db = ScoDataFactory.get();
		//NOW PREPARE THE REPORT

		for ( int i = 0; i < report.size(); i++ ) {
			Hashtable item = (Hashtable) report.elementAt(i);
			Hashtable scoData = db.get(learnerid, courseid, (String) item.get("id"));
			if ( scoData != null ) {
				if ( scoData.get("cmi.core.lesson_status") != null )
					item.put("lesson_status", scoData.get("cmi.core.lesson_status"));
				else
					item.put("lesson_status", "not attempted");
					
				if (scoData.get("cmi.core.exit") != null ) 
					item.put("exit_status", scoData.get("cmi.core.exit"));
				else 
					item.put("exit_status","");
					
				if (scoData.get("cmi.core.session_time") != null) 
					item.put("session_time", scoData.get("cmi.core.session_time"));
				else 
					item.put("session_time", "");
					
				if (scoData.get("cmi.core.entry") != null) 
					item.put("entry_status", scoData.get("cmi.core.entry"));
				else 
					item.put("entry_status", "");			
			} else {
				System.out.println("scodata is NULL");
				item.put("lesson_status", "not attempted");
				item.put("exit_status", "");
				item.put("session_time", "");
				item.put("entry_status", "");
			}			

		}
	
		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
/*
	String readField(String name) {
		String data = "";
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(name));
			data = reader.readLine();
			if ( data == null ) data = "";
		} catch ( IOException e ) {
			System.out.println( e.getMessage() );
		} finally {
			try {
				if ( reader != null ) reader.close();
			} catch ( IOException e ) {}
		}
		return data;
	}
*/	

	private void resetAllValues() throws Exception {
	    /*
		String learnerid = request.getParameter("learnerid");
		String courseid = request.getParameter("courseid");		
		String dir = Resource.getDATA() + "/learner/" + learnerid + "/" + courseid;
		
		System.out.println("delete.. " + dir);
		
		File file = new File(dir);
		deleteDir(file);
		 */		
	}

	
	//recursively delete files and directory
	private static boolean deleteDir(File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i=0; i<children.length; i++) {
				boolean success = deleteDir(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}
		return dir.delete();
	}		
}