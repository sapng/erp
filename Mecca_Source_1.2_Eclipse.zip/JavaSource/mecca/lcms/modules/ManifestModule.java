/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */


package mecca.lcms.modules;

import java.io.File;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.lcms.Course;
import mecca.lcms.ManifestParser;
import mecca.lcms.Resource;
import mecca.lcms.Sco;

import org.apache.velocity.Template;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */



public class ManifestModule extends mecca.portal.velocity.VTemplate {
	

	
	public Template doTemplate() throws Exception {
		HttpSession session = request.getSession();
		String template_name = "vtl/lcms/manifest.vm";
		String errorMsg = "";
		String submit = getParam("command");
		
		if ( "prepare".equals(submit) ) {
			prepareManifest(session);
			getManifest(session);	
		}
	

		Template template = engine.getTemplate(template_name);	
		return template;		
	}
	
	void prepareManifest(HttpSession session) throws Exception {
		
		try {
			Course course = (Course) session.getAttribute("course");
			String course_id = course.getId();
			String course_title = course.getTitle();
			String filename = Resource.getPATH() + course_id + "/imsmanifest.xml";
			System.out.println(">" + filename);
		
			if ( new File(filename).exists() ) {
				Vector container = ManifestParser.parse(filename);
				Vector data = (Vector) container.elementAt(0);
				session.setAttribute("data", data);	
			} else {
				Vector data = new Vector();
				session.setAttribute("data", data);	
			}
		} catch ( Exception e ) {
			Vector data = new Vector();
			session.setAttribute("data", data);
			throw e;
		}		
	}
	



	Vector getScoItems(Vector items) {
		Vector scos = new Vector();
		for ( int i = 0; i < items.size(); i++ ) {
			Sco sco = new Sco(); 
			String s = (String) items.elementAt(i);
			StringTokenizer st = new StringTokenizer(s, "|");
			//First three token is level, identifier, start page and title
			sco.level = st.nextToken();
			sco.id = st.nextToken();
			sco.page = st.nextToken();
			sco.title = st.nextToken();
			//next tokens are web pages
			while ( st.hasMoreTokens() ) {
				String token = st.nextToken();	
				sco.contents.add(token);
			}
			scos.addElement(sco);
		}
		return scos;
	}	
	
	void getManifest(HttpSession session) throws Exception {
		Course course = (Course) session.getAttribute("course");
		String course_id = course.getId();
		String course_title = course.getTitle();
		context.put("course_id", course_id);
		context.put("course_title", course_title);
		
		if ( session.getAttribute("data") != null ) {
			Vector data = (Vector) session.getAttribute("data");
			Vector scos = getScoItems(data);
			//Iterator modules = scos.iterator();
			context.put("modules", scos);
		}
		
	}
}