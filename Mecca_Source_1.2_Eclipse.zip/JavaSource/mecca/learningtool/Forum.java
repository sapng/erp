/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.learningtool;
import mecca.tree.Category;
import mecca.tree.Tree2;
import mecca.util.SimpleDate;


/**
 * @author Shamsul Bahrin Abd Mutalib
 * @version 1.01
 */
public class Forum extends Tree2  {
	private String category_id;
	private String category_name;
	private Category category;
	private String user_id;
	private SimpleDate date_posted;
	private String posted_by;

	public Forum(String title) {
		super(title);
	}

	public void setCategoryId(String id) { category_id = id; }
	public String getCategoryId() { return category_id; }
	public void setCategoryName(String s) { category_name = s; }
	public String getCategoryName() { return category_name; }
	public void setCategory(Category cat) { category = cat; }
	public Category getCategory() { return category; }
	public void setUserId(String id) { user_id = id; }
	public String getUserId() { return user_id; }
	public void setDatePosted(SimpleDate date) { date_posted = date; }
	public SimpleDate getDatePosted() { return date_posted; }
	public void setPostedBy(String s) { posted_by = s; }
	public String getPostedBy() { return posted_by; }
	public String displayMessage() {
		return putLineBreak(getNotes());
	}
	public String getMessage() {
		return putLineBreak(getNotes());
	}	
	
	public static String putLineBreak(String str) {
		StringBuffer txt = new StringBuffer(str);
		char c = '\n';
		while (txt.toString().indexOf(c) > -1) {
			int pos = txt.toString().indexOf(c);
			txt.replace(pos, pos + 1, "<br>");
		}
		return txt.toString();
	}	

}