/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.object;

import mecca.util.Logger;

/**
 * @author Shaiful Nizam Tajul
 * @version 1.01
 */
public class Module {
    private String id;
    private String title;
    private String className;
    private String group;
    private String description;
    private Boolean selected;
    private Logger log;
    private String cName = "mecca.object.Module";
    private boolean logger = false;
    
    public Module()
    {
        id = "";
        title = "";
        className = "";
        group = "";
        description = "";
        selected = Boolean.valueOf(false);
        if (logger) log = new Logger(cName);
    }
    
/**
 * Setter method to set the String attribute, <i>id</i>.
 */
    public void setId(String id)
    {
        if (id == null)
        {
            this.id = "";
        } else {
            this.id = id;
        }
    }
    
/**
 * Getter method to get the String attribute, <i>id</i>.
 */
    public String getId()
    {
        return id;
    }
    
/**
 * Setter method to set the String attribute, <i>title</i>.
 */
    public void setTitle(String title)
    {
        if (title == null)
        {
            this.title = "";
        } else {
            this.title = title;
        }
    }
    
/**
 * Getter method to get the String attribute, <i>title</i>.
 */
    public String getTitle()
    {
        return title;
    }
    
/**
 * Setter method to set the String attribute, <i>className</i>.
 */
    public void setClassName(String className)
    {
        if (className == null)
        {
            this.className = "";
        } else {
            this.className = className;
        }
    }
    
/**
 * Getter method to get the String attribute, <i>className</i>.
 */
    public String getClassName()
    {
        return className;
    }
    
/**
 * Setter method to set the String attribute, <i>group</i>.
 */
    public void setGroup(String group)
    {
        if (group == null)
        {
            this.group = "";
        } else {
            this.group = group;
        }
    }
    
/**
 * Getter method to get the String attribute, <i>group</i>.
 */
    public String getGroup()
    {
        return group;
    }
    
/**
 * Setter method to set the String attribute, <i>description</i>.
 */
    public void setDescription(String description)
    {
        if (description == null)
        {
            this.description = "";
        } else {
            this.description = description;
        }
    }
    
/**
 * Getter method to get the String attribute, <i>description</i>.
 */
    public String getDescription()
    {
        return description;
    }
    
/**
 * Setter method to set the Boolean attribute, <i>selected</i>.
 */
    public void setSelected(boolean selected)
    {
        this.selected = Boolean.valueOf(selected);
    }
    public void setSelected(String selected)
    {
        this.selected = Boolean.valueOf(selected);
    }
    
/**
 * Getter method to get the Boolean attribute, <i>selected</i>.
 */
    public Boolean isSelected()
    {
        return selected;
    }
    
}