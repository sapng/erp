/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package mecca.object;

import java.sql.Blob;

/**
 * @author Shaiful Nizam Tajul
 * @version 1.01
 */
public class Image
{
    private String id;
    private String filename;
    private Blob blob;
    
    public Image()
    {
        id = "0";
        filename = "";
        blob = null;
    }
    
    public void setId(String s)
    {
        if (s == null)
        {
            id = "0";
        } else {
            id = s;
        }
    }
    
    public String getId()
    {
        return id;
    }
    
    public void setFilename(String s)
    {
        if (s == null)
        {
            filename = "";
        } else {
            filename = s;
        }
    }
    
    public String getFilename()
    {
        return filename;
    }
    
    public void setBlob(Blob b)
    {
        blob = b;
    }
    
    public Blob getBlob()
    {
        return blob;
    }
    
}