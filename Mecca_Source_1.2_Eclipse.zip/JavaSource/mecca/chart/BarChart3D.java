package mecca.chart;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;


public class BarChart3D {
    
    private DefaultCategoryDataset dataset = new DefaultCategoryDataset();
	private double[][] data;
	private String[] categories, series;
	private int width = 450, height = 400;
	private String chartTitle = "", categoryLabel = "Category", valueLabel = "Value";

    public BarChart3D() {
        dataset = new DefaultCategoryDataset();
    }
    
    public void setTitle(String s) {
	    chartTitle = s;
    }    
    
    public void setCategoryLabel(String s) {
	    categoryLabel = s;
    }
    
    public void setValueLabel(String s) {
	    valueLabel = s;
    }
    
    public JFreeChart getChart() {
        CategoryDataset dataset = createDataset();
        return createChart(dataset);
    }    
    
    public void setData(double[][] d) {
	    data = d;
    }
    
    public void setCategories(String[] s) {
		categories = s;
    }
    
    public void setSeries(String[] s) {
	    series = s;
    }
    
    public void setDimension(int w, int h) {
	    width = w;
	    height = h;
    }
    
    public java.awt.image.BufferedImage getBufferedImage() {
	    return getChart().createBufferedImage(width, height);
    }
    
    public void addValue(double value, String series, String category) {
        dataset.addValue(value, series, category);
    }

   private CategoryDataset createDataset() {
       return dataset;
    }    

    private JFreeChart createChart(CategoryDataset dataset) {
        
        JFreeChart chart = ChartFactory.createBarChart3D(
            chartTitle,      				// chart title
            categoryLabel,               	// domain axis label
            valueLabel,                  	// range axis label
            dataset,                  		// data
            PlotOrientation.HORIZONTAL, 		// orientation VERTICAL / HORIZONTAL
            false,                     		// include legend
            false,                     		// tooltips
            false                     		// urls
        );

        CategoryPlot plot = chart.getCategoryPlot();
        
        
        CategoryAxis axis = plot.getDomainAxis();
        axis.setCategoryLabelPositions(
            CategoryLabelPositions.createUpRotationLabelPositions(Math.PI/ 8.0)
        );
        
        return chart;

    }

}
