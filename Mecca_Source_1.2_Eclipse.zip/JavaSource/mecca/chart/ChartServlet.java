package mecca.chart;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jfree.chart.ChartUtilities;

public class ChartServlet extends HttpServlet {
    public void doGet(HttpServletRequest request,  HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("image/png");
		HttpSession session = request.getSession(true);   

		try {
			java.awt.image.BufferedImage image = (java.awt.image.BufferedImage) session.getAttribute("_chart_image");
			ChartUtilities.writeBufferedImageAsPNG(response.getOutputStream(), image); 
			response.getOutputStream().close();
		} catch ( Exception e ) {
			System.out.println( "ERROR HAS OCCURED IN ImgServlet");	
			e.printStackTrace();
		}		     
    }
}



