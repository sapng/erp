package mecca.chart;

import java.awt.Font;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;


public class PieChart {
    
    private DefaultPieDataset dataset;
	private String chartTitle = "";

    public PieChart() {
        dataset = new DefaultPieDataset();
    }
    
    public void setValue(String label, double value ) {
        dataset.setValue(label, value);
    }
    
    public void setTitle(String s) {
	    chartTitle = s;
    }
    
    public JFreeChart getChart() {
        return createChart(dataset);
    }      
    
   
    private JFreeChart createChart(PieDataset dataset) {
        
        JFreeChart chart = ChartFactory.createPieChart(
            chartTitle,  		// chart title
            dataset,            // data
            true,               // include legend
            true,
            false
        );

        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
        plot.setNoDataMessage("No data available");
        plot.setCircular(false);
        plot.setLabelGap(0.02);
        return chart;
        
    }

}