/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.messenger;


import javax.servlet.http.HttpSession;

import mecca.portal.velocity.VTemplate;
import mecca.util.Logger;

import org.apache.velocity.Template;
/**
 * This servlet is the Messenger alerter.
 * 
 * @author Shaiful Nizam Tajul
 * @version 1.01
 */

public class MessengerAlertModule extends VTemplate
{
    private MessengerProcessor processor;    
    private String className = "infusion.messenger.MessengerAlertModule";
    private boolean logger = false;
    private Logger log;
    private String targetPage;
    
    public Template doTemplate() throws Exception
    {
        if (logger) log = new Logger(className);
        HttpSession session = request.getSession();
        processor = new MessengerProcessor();
        
        String user = (String) session.getAttribute("_portal_login");
        
        String totalNewMsg = Integer.toString(processor.getUnreadMessageCount(user));
        String totalMsg = Integer.toString(processor.getTotalMessageCount(user));
        
        context.put("totalNewMsg",totalNewMsg);
        context.put("totalMsg",totalMsg);
        
        Template template = engine.getTemplate("messenger/messenger_alert.vm"); 
        return template;        
    }
}