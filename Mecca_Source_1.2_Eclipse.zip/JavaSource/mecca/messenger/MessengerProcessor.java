/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.messenger;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import mecca.db.Db;
import mecca.db.DbException;
import mecca.messenger.object.Message;
import mecca.object.User;
import mecca.util.DateUtil;
import mecca.util.Logger;
import mecca.util.StringChecker;


/**
 * This class provides a centralized data processing.
 * This class will be used with the MessengerModule.
 * 
 * @author Shaiful Nizam Tajul
 * @version 1.01
 */ 

public class MessengerProcessor
{
    private String className = "infusion.messenger.MessengerProcessor";
    private Logger log;
    private boolean logger = false;
    private Hashtable conProp = new Hashtable();
    
    public MessengerProcessor()
    {
        if (logger) log = new Logger(className);
        if (logger) log.setMessage("Initialized");
    }

/**
 *  This method gets a list of sent messages and returns a Vector.
 */
    public Vector getSentMessages(String sender) throws Exception
    {
        String sql = "select id, sender, receiver, subject, "+
                    "content, post_date, is_read from messenger_sent where "+
                    "sender = '"+sender+"' order by post_date desc";
        Db database = null;
        Message obj = null;
        Vector list = new Vector();
        try
        {
            database = new Db();
            Statement stmt = database.getStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next())
            {
                obj = new Message();
                obj.setId(rs.getString("id"));
                obj.setSender(rs.getString("sender"));
                obj.setReceiver(rs.getString("receiver"));
                obj.setSubject(rs.getString("subject"));
                obj.setContent(rs.getString("content"));
                obj.setPostDate(rs.getDate("post_date"));
                int i = rs.getInt("is_read");
                if (i == 0)
                {
                    obj.setIsRead(false);
                } else {
                    obj.setIsRead(true);
                }
                
                list.addElement(obj);
            }
        }
        catch ( DbException dbex )
        {
            if (logger) log.setMessage("getSentMessages() : DbException : "+dbex.getMessage());
        }
        catch(SQLException ex)
        {
            if (logger) log.setMessage("getSentMessages() : SQLException : "+ex.getMessage());
        }
        finally
        {
            if ( database != null ) database.close();
        }
        return list;
    }

/**
 *  This method gets a list of received messages and returns a Vector.
 */
    public Vector getReceivedMessages(String receiver) throws Exception
    {
        if (logger) log.setMessage("getReceivedMessages("+receiver+")");
        String sql = "select id, sender, receiver, subject, "+
                    "content, post_date, is_read from messenger where "+
                    "receiver = '"+receiver+"' order by post_date desc";
        Db database = null;
        Message obj = null;
        Vector list = new Vector();
        try
        {
            database = new Db();
            Statement stmt = database.getStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next())
            {
                obj = new Message();
                obj.setId(rs.getString("id"));
                obj.setSender(rs.getString("sender"));
                obj.setReceiver(rs.getString("receiver"));
                obj.setSubject(rs.getString("subject"));
                obj.setContent(rs.getString("content"));
                obj.setPostDate(rs.getDate("post_date"));
                int i = rs.getInt("is_read");
                if (i == 0)
                {
                    obj.setIsRead(false);
                } else {
                    obj.setIsRead(true);
                }
                
                list.addElement(obj);
            }
        }
        catch ( DbException dbex )
        {
            if (logger) log.setMessage("getReceivedMessages() : DbException : "+dbex.getMessage());
        }
        catch(SQLException ex)
        {
            if (logger) log.setMessage("getReceivedMessages() : SQLException : "+ex.getMessage());
        }
        finally
        {
            if ( database != null ) database.close();
        }
        return list;
    }
    
    public Message getMessage(String id, String view) throws Exception
    {
        if (logger) log.setMessage("getMessage("+id+","+view+")");
        String sql = "";
        if (view.equals("sent"))
        {
            sql = "select id, sender, receiver, subject, content, "+
                    "post_date, is_read from messenger_sent where "+
                    "id = "+id;
        } else {
            sql = "select id, sender, receiver, subject, content, "+
                    "post_date, is_read from messenger where "+
                    "id = "+id;
        }
        Db database = null;
        Message obj = new Message();
        try
        {
            //database = new Db(conProp);
            database = new Db();
            Statement stmt = database.getStatement();
            ResultSet rs = stmt.executeQuery(sql);
            DateUtil du = new DateUtil();
            
            while (rs.next())
            {
                obj.setId(rs.getString("id"));
                obj.setSender(rs.getString("sender"));
                obj.setReceiver(rs.getString("receiver"));
                obj.setSubject(rs.getString("subject"));
                obj.setContent(rs.getString("content"));
                obj.setPostDate(rs.getDate("post_date"));
                int i = rs.getInt("is_read");
                if (i == 0)
                {
                    obj.setIsRead(false);
                } else {
                    obj.setIsRead(true);
                }
            }
        }
        catch ( DbException dbex )
        {
            if (logger) log.setMessage("getMessage() : DbException : "+dbex.getMessage());
        }
        catch(SQLException ex)
        {
            if (logger) log.setMessage("getMessage() : SQLException : "+ex.getMessage());
        }
        finally
        {
            if ( database != null ) database.close();
        }
        return obj;
    }
    
    public void setMessageStatus(String id, boolean status) throws Exception
    {
        if (logger) log.setMessage("setMessageStatus("+id+","+status+")");
        String s = "0";
        if (status) s = "1";
        String sql = "update messenger set is_read = "+s+" where id = "+id;
        Db database = null;
        try
        {
            database = new Db();
            Statement stmt = database.getStatement();
            stmt.executeUpdate(sql);
        }
        catch ( DbException dbex )
        {
            if (logger) log.setMessage("setMessageStatus() : DbException : "+dbex.getMessage());
        }
        catch(SQLException ex)
        {
            if (logger) log.setMessage("setMessageStatus() : SQLException : "+ex.getMessage());
        }
        finally
        {
            if ( database != null ) database.close();
        }
    }
    
    public void setMessage(String sender, String receiver, String subject,
    String content) throws Exception
    {
        subject = StringChecker.invComma(subject);
        content = StringChecker.invComma(content);
        DateUtil du = new DateUtil();
        String today = du.toString(du.getToday(),"yyyy-MM-dd");
        String sql1 = "";
        String sql2 = "";
        Db database = null;
        try
        {
            database = new Db();
            Statement stmt = database.getStatement();
            
            if ( receiver.indexOf(',') != -1 )
            {
                Vector users = splitReceiver(receiver);
                for ( Enumeration e = users.elements(); e.hasMoreElements(); )
                {
                    String user = (String) e.nextElement();
                    sql1 = "insert into messenger (sender,receiver,subject,content,"+
                           "post_date,is_read) values ('"+sender+"','"+user+"','"+
                           subject+"','"+content+"','"+today+"',0)";
                    stmt.executeUpdate(sql1);                    
                }
            } else {
                sql1 = "insert into messenger (sender,receiver,subject,content,"+
                       "post_date,is_read) values ('"+sender+"','"+receiver+"','"+
                       subject+"','"+content+"','"+today+"',0)";
                stmt.executeUpdate(sql1);
            }
            
            sql2 = "insert into messenger_sent (sender,receiver,subject,content,"+
                   "post_date,is_read) values ('"+sender+"','"+receiver+"','"+
                   subject+"','"+content+"','"+today+"',1)";
            stmt.executeUpdate(sql2);
        }
        catch ( DbException dbex )
        {
            if (logger) log.setMessage("setMessage() : DbException : "+dbex.getMessage());
        }
        catch(SQLException ex)
        {
            if (logger) log.setMessage("setMessage() : SQLException : "+ex.getMessage());
        }
        finally
        {
            if ( database != null ) database.close();
        }
    }
    
    public void deleteMessage(String id, String view) throws Exception
    {
        String sql = "";
        if (view.equals("sent"))
        {
            sql = "delete from messenger_sent where id = "+id;
        } else {
            sql = "delete from messenger where id = "+id;
        }
        Db database = null;
        try
        {
            database = new Db();
            Statement stmt = database.getStatement();
            stmt.executeUpdate(sql);
        }
        catch ( DbException dbex )
        {
            if (logger) log.setMessage("deleteMessage() : DbException : "+dbex.getMessage());
        }
        catch(SQLException ex)
        {
            if (logger) log.setMessage("deleteMessage() : SQLException : "+ex.getMessage());
        }
        finally
        {
            if ( database != null ) database.close();
        }
    }
    
    public int getUnreadMessageCount(String receiver) throws Exception
    {
        String sql = "select count(*) from messenger where is_read = 0 and "+
                    "receiver = '"+receiver+"'";
        Db database = null;
        int count = 0;
        try
        {
            database = new Db();
            Statement stmt = database.getStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next())
            {
                count = rs.getInt(1);
            }
        }
        catch ( DbException dbex )
        {
            if (logger) log.setMessage("getUnreadMessageCount() : DbException : "+dbex.getMessage());
        }
        catch(SQLException ex)
        {
            if (logger) log.setMessage("getUnreadMessageCount() : SQLException : "+ex.getMessage());
        }
        finally
        {
            if ( database != null ) database.close();
        }
        return count;
    }
    
    public int getTotalMessageCount(String receiver) throws Exception
    {
        String sql = "select count(*) from messenger where "+
                    "receiver = '"+receiver+"'";
        Db database = null;
        int count = 0;
        try
        {
            database = new Db();
            Statement stmt = database.getStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next())
            {
                count = rs.getInt(1);
            }
        }
        catch ( DbException dbex )
        {
            if (logger) log.setMessage("getTotalMessageCount() : DbException : "+dbex.getMessage());
        }
        catch(SQLException ex)
        {
            if (logger) log.setMessage("getTotalMessageCount() : SQLException : "+ex.getMessage());
        }
        finally
        {
            if ( database != null ) database.close();
        }
        return count;
    }
    
    public Vector getUsers() throws Exception
    {
        String sql = "select user_login, user_name from users order by user_name";
        Db database = null;
        Vector list = new Vector();
        User user = null;
        try
        {
            database = new Db();
            Statement stmt = database.getStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next())
            {
                user = new User();
                user.setLogin(rs.getString("user_login").toLowerCase());
                user.setName(rs.getString("user_name"));
                
                list.addElement(user);
            }
        }
        catch ( DbException dbex )
        {
            if (logger) log.setMessage("getUsers() : DbException : "+dbex.getMessage());
        }
        catch(SQLException ex)
        {
            if (logger) log.setMessage("getUsers() : SQLException : "+ex.getMessage());
        }
        finally
        {
            if ( database != null ) database.close();
        }
        return list;
    }
    
    private Vector splitReceiver(String receiver) throws Exception
    {
        Vector list = new Vector();
        String newStr = receiver;
        
        while ( newStr.indexOf(',') > -1 )
        {
            int i = newStr.indexOf(',');
            String subStr = newStr.substring(0,i);
            subStr = subStr.trim();
            list.addElement(subStr);
            if (logger) log.setMessage("splitReceiver(): "+subStr);
            newStr = newStr.substring(i+1);
            
            if ( newStr.indexOf(',') == -1 )
            {
                subStr = newStr.trim();
                list.addElement(subStr);
                if (logger) log.setMessage("splitReceiver(): "+subStr);
            }
        }
        return list;
    }
}