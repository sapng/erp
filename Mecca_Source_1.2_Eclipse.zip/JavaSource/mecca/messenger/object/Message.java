/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.messenger.object;

import java.util.Date;

import mecca.util.Logger;

/**
 * This data object represents the Messenger table in the database.
 * 
 * @author Shaiful Nizam Tajul
 * @version 1.01
 */

public class Message
{
    private String id;
    private String sender;
    private String receiver;
    private String content;
    private Date postDate;
    private boolean isRead;
    private String subject;
    private String className = "infusion.messenger.object.Message";
    private boolean logger = false;
    private Logger log;
   
    public Message()
    {
        init();
        if (logger) log = new Logger(className);
    }

/**
* This method is to reset all attributes to its initial state.
*/
    public void init()
    {
        id = "0";      
        sender = "";
        receiver = "";
        content = "";
        postDate = new Date();
        isRead = false;
        subject = "[No Subject]";
    }

    public void setId(String id)
    {
        if (id == null)
        {
            this.id = "0";
        } else {
            this.id = id;
        }
    }

    public String getId()
    {
        return id;
    }

    public void setSender(String sender)
    {
        if (sender == null)
        {
            this.sender = "";
        } else {
            this.sender = sender;
        }
    }

    public String getSender()
    {
        return sender;
    }

    public void setReceiver(String receiver)
    {
        if (receiver == null)
        {
            this.receiver = "";
        } else {
            this.receiver = receiver;
        }
    }

    public String getReceiver()
    {
        return receiver;
    }  

    public void setContent(String content)
    {
        if (content == null)
        {
            this.content = "";
        } else {
            this.content = content;
        }
    }

    public String getContent()
    {
        return content;
    }

    public void setPostDate(Date postDate)
    {       
        this.postDate = postDate;
    }

    public Date getPostDate()
    {
        return postDate;
    }

    public void setIsRead(boolean isRead)
    {
        this.isRead = isRead;
    }

    public boolean isRead()
    {
        return isRead;
    }

    public void setSubject(String subject)
    {
        if (subject == null)
        {
            this.subject = "[No Subject]";
        } else {
            this.subject = subject;
        }
    }

    public String getSubject()
    {
        return subject;
    }
}