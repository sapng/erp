/* ************************************************************************
 * Copyright 2005 In-Fusion Systems Sdn. Bhd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */
package mecca.messenger;


import java.util.Enumeration;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import mecca.messenger.object.Message;
import mecca.object.User;
import mecca.portal.velocity.VTemplate;
import mecca.util.DateUtil;
import mecca.util.Logger;
import mecca.util.StringChecker;

import org.apache.velocity.Template;

/**
 * This servlet is the Messenger Module controller.
 * 
 * @author Shaiful Nizam Tajul
 * @version 1.01
 */
public class MessengerModule extends VTemplate
{
    private MessengerProcessor processor;
    private String className = "infusion.messenger.MessengerModule";
    private boolean logger = false;
    private Logger log;
    private String targetPage;
    
    public Template doTemplate() throws Exception
    {
        if (logger) log = new Logger(className);
        HttpSession session = request.getSession();
        processor = new MessengerProcessor();
        
        String user = (String) session.getAttribute("_portal_login");
            
        String action = request.getParameter("form_action");
        if ((action == null) || (action.equals(""))) action = "none";
        if (logger) log.setMessage("action = "+action);
        
        if (action.equals("none"))
        {
            // IF NO ACTION DO THIS
            // DISPLAY LIST MESSAGE
            DateUtil du = new DateUtil();
            context.put("dateUtil",du);
            
            String view = request.getParameter("view");
            if (view == null) view = "receive";
            Vector list = new Vector();
            if (view.equals("sent"))
            {
                list = processor.getSentMessages(user);
            } else {
                list = processor.getReceivedMessages(user);
            }
            context.put("messageList",list);
            context.put("view",view);
            
            targetPage = "messenger/messenger_home.vm";
            
        } else if (action.equals("message_compose"))
        {
            
            // GET COMPOSE MESSAGE FORM
            Vector userList = processor.getUsers();
            
            context.put("sender",user);
            context.put("userList",userList);
            
            targetPage = "messenger/messenger_compose.vm";
            
        } else if (action.equals("message_sent"))
        {
            
            // SENT MESSAGE
            String receiver = request.getParameter("receiver");
            if ( (receiver.equals("All")) || (receiver.equals("all")) )
            {
                Vector userList = processor.getUsers();
                User userObj = null;
                receiver = "";
                for (Enumeration e = userList.elements(); e.hasMoreElements();)
                {
                    userObj = new User();
                    userObj = (User) e.nextElement();
                    if (!userObj.getLogin().equals(user))
                    {
                        if (receiver.equals(""))
                        {
                            receiver = userObj.getLogin();
                        } else {
                            receiver = receiver + ", " + userObj.getLogin();
                        }
                    }
                }
            }
            
            String subject = request.getParameter("subject");
            String content = request.getParameter("content");
            processor.setMessage(user,receiver,subject,content);

            // DISPLAY LIST MESSAGE
            DateUtil du = new DateUtil();
            context.put("dateUtil",du);
            
            String view = request.getParameter("view");
            if (view == null) view = "receive";
            Vector list = new Vector();
            if (view.equals("sent"))
            {
                list = processor.getSentMessages(user);
            } else {
                list = processor.getReceivedMessages(user);
            }
            context.put("messageList",list);
            context.put("view",view);
            
            targetPage = "messenger/messenger_home.vm";
            
        } else if (action.equals("message_read"))
        {
            
            // READ MESSAGE
            String id = request.getParameter("message_id");
            String view = request.getParameter("view");
            
            Message msg = processor.getMessage(id,view);
            if (view.equals("receive"))
            {
                if (!msg.isRead()) processor.setMessageStatus(id,true);
            }
            String content = msg.getContent();
            msg.setContent(StringChecker.putLineBreak(content));
            context.put("message",msg);
            context.put("view",view);
                        
            targetPage = "messenger/messenger_read.vm";
            
        } else if (action.equals("message_get_reply_form"))
        {
            
            // GET REPLY MESSAGE FORM
            Vector userList = processor.getUsers();
            String id = request.getParameter("message_id");
            Message msg = processor.getMessage(id,"receive");
            
            context.put("sender",user);
            context.put("message",msg);
            
            targetPage = "messenger/messenger_reply.vm";
            
        } else if (action.equals("message_delete"))
        {
            
            // DELETE MESSAGE
            String[] msgIds = request.getParameterValues("msgid");
            String view = request.getParameter("view");
            if (view == null) view = "receive";
            
            for (int i = 0; i < msgIds.length; i++)
            {
                processor.deleteMessage(msgIds[i],view);
            }
            
            // DISPLAY LIST MESSAGE
            DateUtil du = new DateUtil();
            context.put("dateUtil",du);
            
            Vector list = new Vector();
            if (view.equals("sent"))
            {
                list = processor.getSentMessages(user);
            } else {
                list = processor.getReceivedMessages(user);
            }
            context.put("messageList",list);
            context.put("view",view);
            
            targetPage = "messenger/messenger_home.vm";
        
        } else if (action.equals("single_message_delete"))
        {
            
            // DELETE MESSAGE
            String msgId = request.getParameter("message_id");
            String view = request.getParameter("view");
            if (view == null) view = "receive";
            
            processor.deleteMessage(msgId,view);
            
            // DISPLAY LIST MESSAGE
            DateUtil du = new DateUtil();
            context.put("dateUtil",du);
            
            Vector list = new Vector();
            if (view.equals("sent"))
            {
                list = processor.getSentMessages(user);
            } else {
                list = processor.getReceivedMessages(user);
            }
            context.put("messageList",list);
            context.put("view",view);
            
            targetPage = "messenger/messenger_home.vm";
            
        }
        Template template = engine.getTemplate(targetPage); 
        return template;        
    }
}