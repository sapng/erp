/* ************************************************************************
 * Copyright 2005 University ERP Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package act.mecca.sis.registration;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.db.DbException;
import mecca.db.SQLRenderer;
import mecca.sis.registration.StudentData;
import mecca.util.DateTool;

import org.apache.velocity.VelocityContext;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @ refactored to ActionXML: red1
 * @version 1.0
 */
public class RegAdd implements mecca.portal.action.ActionTemplate {
	private static String[] month_name = {"January", "February", "March", "April", "May", "Jun", "July", "August", "September", "October", "November", "December"};
	public void doAction(HttpServletRequest req, HttpServletResponse res, VelocityContext context) throws Exception 
	{
		HttpSession session = req.getSession();
		String submit = req.getParameter("command");
		String mode = session.getAttribute("mode") != null ? (String) session.getAttribute("mode") : "empty";
		Hashtable dateTime = DateTool.getCurrentDateTime();
		context.put("dateTime", dateTime);
		context.put("month_name", month_name);		
		Hashtable studentInfo = new Hashtable();
		add(req, studentInfo, mode);	
		getStudentBiodata(req, session, context);
		//get student program information
		Hashtable programInfo = new Hashtable();
		context.put("isEnrolled", new Boolean(getStudentEnroll(req, programInfo, context)));

	}
	private void add(HttpServletRequest req, Hashtable studentInfo, String mode) throws Exception {
		
		String applicant_id = req.getParameter("applicant_id");
		String student_id = req.getParameter("student_id");
		
		String centre_id = req.getParameter("centre_id");
		
		if ( "".equals(req.getParameter("student_id")) ) throw new Exception("Can not have empty fields!");
		if ( "".equals(req.getParameter("student_name")) ) throw new Exception("Can not have empty fields!");
		
		studentInfo.put("applicant_id", applicant_id);
		studentInfo.put("student_id", student_id);
		studentInfo.put("password", student_id);
		studentInfo.put("name", req.getParameter("student_name"));
		
		studentInfo.put("icno", req.getParameter("icno"));
		
		//use
		studentInfo.put("address", req.getParameter("address1"));
		
		//remove
		studentInfo.put("address1", req.getParameter("address1"));
		studentInfo.put("address2", req.getParameter("address2"));
		studentInfo.put("address3", req.getParameter("address3"));
		//
		studentInfo.put("city", req.getParameter("city"));
		studentInfo.put("state", req.getParameter("state"));
		studentInfo.put("poscode", req.getParameter("poscode"));
		studentInfo.put("country_code", req.getParameter("country_list"));
		studentInfo.put("email", req.getParameter("email"));
		studentInfo.put("phone", req.getParameter("phone"));
		
		String birth_year = req.getParameter("birth_year");
		String birth_month = req.getParameter("birth_month");
		String birth_day = req.getParameter("birth_day");
		
		studentInfo.put("birth_year", birth_year);
		studentInfo.put("birth_month", birth_month);
		studentInfo.put("birth_day", birth_day);
		
		studentInfo.put("gender", req.getParameter("gender"));
		
		String birth_date = birth_year + "-" + fmt(birth_month) + "-" + fmt(birth_day);
		studentInfo.put("birth_date", birth_date);
		
		Db db = null;
		String sql = "";
		Connection conn = null;
		try {
			db = new Db();
			conn = db.getConnection();
			conn.setAutoCommit(false);
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			//check if student_id exists
			boolean found = false;
			{
				r.add("id");
				r.add("id", (String) studentInfo.get("student_id"));
				
				sql = r.getSQLSelect("student");
				
				
				ResultSet rs = stmt.executeQuery(sql);
				
				if ( rs.next() ) found = true;
				else found = false;
			}
			
			
			if ( found &&  !"update".equals(mode) ) throw new Exception("student Id was invalid!");
			
			{
				
				r.clear();
				r.add("applicant_id", getInfoData(studentInfo, "applicant_id"));
				r.add("password", getInfoData(studentInfo, "student_id"));
				r.add("name", getInfoData(studentInfo, "name"));
				r.add("icno", getInfoData(studentInfo, "icno"));
				
				//use this
				r.add("address", getInfoData(studentInfo, "address"));
				//remove address1, 2 and 3
				r.add("address1", getInfoData(studentInfo, "address1"));
				r.add("address2", getInfoData(studentInfo, "address2"));
				r.add("address3", getInfoData(studentInfo, "address3"));
				//
				r.add("city", getInfoData(studentInfo, "city"));
				r.add("state", getInfoData(studentInfo, "state"));
				r.add("poscode", getInfoData(studentInfo, "poscode"));
				r.add("country_code", getInfoData(studentInfo, "country_code"));
				r.add("phone", getInfoData(studentInfo, "phone"));
				r.add("birth_date", getInfoData(studentInfo, "birth_date"));
				r.add("gender", getInfoData(studentInfo, "gender"));

			}
			
			if ( !found ) {
				//insert
				r.add("id", (String) studentInfo.get("student_id"));	
				sql = r.getSQLInsert("student");
				stmt.executeUpdate(sql);				
			} else {
				//update
				r.update("id", (String) studentInfo.get("student_id"));	
				sql = r.getSQLUpdate("student");
				stmt.executeUpdate(sql);				
			}
			saveCustomData(req, student_id, stmt, r, sql);
			
			//save learning centre
			{
				sql = "update student set centre_id = '" + centre_id + "' where id = '" + (String) studentInfo.get("student_id") + "'";
				stmt.executeUpdate(sql);
			}
			conn.commit();
		} catch ( DbException dbex ) {
			throw dbex;
		} catch ( SQLException sqlex ) {
			try {
				conn.rollback();
			} catch ( SQLException rollex ) {}
			throw sqlex;
		} finally {
			if ( db != null ) db.close();
		}		
		
		//create student login in PORTAL and LMS
		//--
		
		createPortalLogin(req, (String) studentInfo.get("student_id"), (String) studentInfo.get("student_id"), (String) studentInfo.get("name") );
		
		//--		
	}
	String getInfoData(Hashtable h, String field) 
		{
		if ( h.get(field) != null )
			return (String) h.get(field);
			else
				return "";
		}
	public static void getStudentBiodata(HttpServletRequest req, HttpSession session, VelocityContext context) throws Exception  {
		String student_id = req.getParameter("student_id");
		Hashtable studentInfo = new Hashtable();
		studentInfo = getStudent(student_id);
		context.put("studentInfo", studentInfo);
		session.setAttribute("studentInfo", studentInfo);
		if ( studentInfo.get("student_id") != null )
			session.setAttribute("mode", "update");
		else
			session.setAttribute("mode", "empty");
	}
	private String fmt(String s) {
		s = s.trim();
		if ( s.length() == 1 ) return "0".concat(s);
		else return s;	
	}	
	private void saveCustomData(HttpServletRequest req, String student_id, Statement stmt, SQLRenderer r, String sql) throws Exception {
		sql = "select data_id, data_name from custom_data";
		ResultSet rs = stmt.executeQuery(sql);
		Hashtable h = new Hashtable();
		while ( rs.next() ) {
			String id = rs.getString("data_id");
			String name = rs.getString("data_name");
			String value = req.getParameter(name);
			h.put(id, value);
			}
		}
		public static boolean getStudentEnroll(HttpServletRequest req, Hashtable info, VelocityContext context) throws Exception {
		    boolean success = true;
		    String student_id = req.getParameter("student_id");
		    info = StudentData.getEnrollmentInfo(student_id);
		    
			//info.put("period_id", period_id);
		    String period_select = req.getParameter("period_list");
		    //String period_id = SessionData.getCurrentPeriodId((String) info.get("period_scheme"), (String) info.get("intake_session"));
		    String period_id = info.get("period_id") != null ? (String) info.get("period_id") : ""; //current period_id

			info.put("period_select", period_select != null && !"".equals(period_select) ? period_select : period_id);
			
			createPeriodName(info);
			if ( !"".equals(period_select)) {
				if ( period_id.equals(period_select)) {
				    info.put("period_select_name", (String) info.get("period_name"));
				} else {
			        createPeriodName2(info, period_select);
				}
			}	    
		    
		    context.put("programInfo", info);
		    return success;
		}
		private void createPortalLogin(HttpServletRequest req, String login, String password, String name) throws Exception {
			String sql = "";
			Connection conn = null;
			Db db = null;
			try {
				db = new Db();
				conn = db.getConnection();
				conn.setAutoCommit(false);			
				Statement stmt = db.getStatement();
				SQLRenderer r = new SQLRenderer();
				//look for login id
				//for student login id is the matric number
				boolean found = false;
				{
					sql = "select user_login from users where user_login = '" + login + "'";
					//System.out.println(sql);
					ResultSet rs = stmt.executeQuery(sql);
					if ( rs.next() ) found = true;
				}
				
				if ( !found ) {
					{
						r.add("user_login", login);
						r.add("user_password", mecca.util.PasswordService.encrypt(password));
						r.add("user_name", name);
						r.add("user_role", "student");
						sql = r.getSQLInsert("users");
						stmt.executeUpdate(sql);
					}
					
					//prepare portal item
					//-- portal's theme
					{
						sql = "select css_name from user_css where user_login = 'student'";
						ResultSet rs = stmt.executeQuery(sql);
						String css_name = "default.css";
						if ( rs.next() ) css_name = rs.getString("css_name");
						sql = "insert into user_css (user_login, css_name) values ('" + login + "', '" + css_name + "')";
						//System.out.println(sql);
						stmt.executeUpdate(sql);
					}
					//-- portal's tabs - get from template student <- deprecated
					//-- use shaiful's get from role's template
					{
						Vector vector = new Vector();

						{
							sql = "select tab_id, tab_title, sequence, display_type from tab_template where user_login = 'student'";
							ResultSet rs = stmt.executeQuery(sql);
							
							while ( rs.next() ) {
								Hashtable h = new Hashtable();
								h.put("tab_id", rs.getString("tab_id"));
								h.put("tab_title", rs.getString("tab_title"));
								h.put("sequence", rs.getString("sequence"));
								h.put("display_type", rs.getString("display_type"));
								//System.out.println("tab");
								vector.addElement(h);
							}
						}						
						//System.out.println("===" + vector.size());
						{
							for ( int i=0; i < vector.size(); i++ ) {
								Hashtable h = (Hashtable) vector.elementAt(i);
								r.clear();
								r.add("tab_id", (String) h.get("tab_id"));
								r.add("tab_title", (String) h.get("tab_title"));
								r.add("sequence", Integer.parseInt((String) h.get("sequence")));
								r.add("display_type", (String) h.get("display_type"));
								r.add("user_login", login);
								sql = r.getSQLInsert("tab");
								//System.out.println(sql);
								stmt.executeUpdate(sql);
							}
						}
					}
					//-- portal's modules

					{
						Vector vector = new Vector();
						{
							sql = "select tab_id, module_id, sequence, module_custom_title, column_number " +
							"from user_module_template where user_login = 'student'";
							ResultSet rs = stmt.executeQuery(sql);
							
							while ( rs.next() ) {
								Hashtable h = new Hashtable();
								h.put("tab_id", rs.getString("tab_id"));
								h.put("module_id", rs.getString("module_id"));
								h.put("sequence", rs.getString("sequence"));
								h.put("module_custom_title", mecca.db.Db.getString(rs, "module_custom_title"));
								String coln = mecca.db.Db.getString(rs, "column_number");
								h.put("column_number", coln.equals("") ? "0" : coln);
								vector.addElement(h);
							}
						}
						
						if ( vector.size() > 0 ) {
							for ( int i=0; i < vector.size(); i++ ) {
								Hashtable h = (Hashtable) vector.elementAt(i);
								r.clear();
								r.add("tab_id", (String) h.get("tab_id"));
								r.add("module_id", (String) h.get("module_id"));
								r.add("sequence", Integer.parseInt((String) h.get("sequence")));
								r.add("module_custom_title", (String) h.get("module_custom_title"));
								r.add("column_number", Integer.parseInt((String) h.get("column_number")));
								r.add("user_login", login);
								sql = r.getSQLInsert("user_module");
								stmt.executeUpdate(sql);	
							}
						}
					}
				}
				else {
					r.add("user_name", name);
					r.update("user_login", login);	
					sql = r.getSQLUpdate("users");		
					stmt.executeUpdate(sql);	
				}
				conn.commit();
			} catch ( Exception ex ) {
				//ex.printStackTrace();
				//throw ex;
			//} catch ( DbException dbex ) {
			//	throw dbex;
			//} catch ( SQLException sqlex ) {
				try {
					conn.rollback();
				} catch ( SQLException rollex ) {}
				//throw sqlex;			
				throw ex;
			} finally {
				if ( db != null ) db.close();
			}
		}
		public static Hashtable getStudent(String id) throws Exception {
			Db db = null;
			String sql = "";
			try {
				db = new Db();
				Statement stmt = db.getStatement();
				SQLRenderer r = new SQLRenderer();
				
				r.add("id");
				r.add("applicant_id");
				r.add("password");
				r.add("name");
				r.add("icno");
				//use this
				r.add("address");
				//remove
				r.add("address1");
				r.add("address2");
				r.add("address3");
				//
				r.add("city");
				r.add("state");
				r.add("poscode");
				r.add("country_code");
				r.add("email");
				r.add("phone");
				r.add("gender");
				r.add("birth_date");
				r.add("intake_session");
				
				//
				r.add("centre_id");
				
				r.add("id", id);
				sql = r.getSQLSelect("student");
				ResultSet rs = stmt.executeQuery(sql);
				Hashtable h = null;
				if ( rs.next() ) {
					h = getStudentData(rs);
				}
				if ( h != null ) {
					getCustomData(h);
				} else {
					h = new Hashtable();
				}
				return h;
			} catch ( DbException dbex ) {
				throw dbex;
			} catch ( SQLException sqlex ) {
				throw sqlex;
			} finally {
				if ( db != null ) db.close();	
			}
		}
		public static Hashtable getStudentData(ResultSet rs) throws Exception {
			Hashtable studentInfo = new Hashtable();
			
			studentInfo.put("student_id", getString(rs, "id"));
			studentInfo.put("applicant_id", getString(rs, "applicant_id"));
			studentInfo.put("password", getString(rs, "password"));
			studentInfo.put("name", getString(rs, "name"));
			studentInfo.put("icno", getString(rs, "icno"));
			
			//use this
			studentInfo.put("address", getString(rs, "address"));
			
			//remove
			studentInfo.put("address1", getString(rs, "address1"));
			studentInfo.put("address2", getString(rs, "address2"));
			studentInfo.put("address3", getString(rs, "address3"));
			//
			studentInfo.put("city", getString(rs, "city"));
			studentInfo.put("state", getString(rs, "state"));
			studentInfo.put("poscode", getString(rs, "poscode"));
			studentInfo.put("country_code", getString(rs, "country_code"));
			studentInfo.put("email", getString(rs, "email"));
			studentInfo.put("gender", getString(rs, "gender"));
			studentInfo.put("phone", getString(rs, "phone"));
			studentInfo.put("birth_date", getString(rs, "birth_date"));
			
			//-- REVISED ALL THE BELOW CODES LATER
			
			java.util.Date birthDate = rs.getDate("birth_date");
			int year = 0, month = 0, day = 0;
			if ( birthDate != null ) {
				Calendar c = new GregorianCalendar();
				c.setTime(birthDate);	
				year = c.get(Calendar.YEAR);
				month = c.get(Calendar.MONTH) + 1;
				day = c.get(Calendar.DAY_OF_MONTH);
			}
			
			studentInfo.put("birth_year", new Integer(year));
			studentInfo.put("birth_month", new Integer(month));
			studentInfo.put("birth_day", new Integer(day));		
			
			studentInfo.put("centre_id", getString(rs, "centre_id"));
			
			studentInfo.put("intake_session", getString(rs, "intake_session"));
			
			return studentInfo;
		}
public static String getString(ResultSet rs, String name) throws Exception {
			String s = rs.getString(name);
			if ( s != null ) return s;
			else return "";	
		}		
public static void createPeriodName2(Hashtable info, String period_select) throws Exception {
			Db db = null;
			String sql = "";
			
			info.put("period_select_name", "");
			
			if ( info.get("period_scheme") == null || "".equals((String) info.get("period_scheme")) ) return;
			
			try {
				db = new Db();
				Statement stmt = db.getStatement();
				SQLRenderer r = new SQLRenderer();
				//establish long period name
				

				{
					r.clear();
					r.add("period_name");
					r.add("period_level");
					r.add("parent_id");
					r.add("period_id", period_select);
					r.add("period_root_id", (String) info.get("period_scheme"));
					sql = r.getSQLSelect("period");

					int period_level = 0;
					String parent_id = "";
					ResultSet rs = stmt.executeQuery(sql);
					if ( rs.next() ) {
						info.put("period_select_name", rs.getString("period_name"));	
						period_level = rs.getInt("period_level");
						parent_id = rs.getString("parent_id");
					}

					String period_name2 = (String) info.get("period_select_name");
					while ( period_level != 0 ) {
						r.clear();
						r.add("period_name");
						r.add("parent_id");
						r.add("period_level");
						r.add("period_id", parent_id);
						sql = r.getSQLSelect("period");
						rs = stmt.executeQuery(sql);
						if ( rs.next() ) {
							period_name2 = rs.getString("period_name") + ", " + period_name2;

							parent_id = rs.getString("parent_id");
							period_level = rs.getInt("period_level");
						}	
					}
					info.put("period_select_name", period_name2);
									
				}

				
			} finally {
				if ( db != null ) db.close();
			}

		}		
public static void createPeriodName(Hashtable info) throws Exception {
			Db db = null;
			String sql = "";
			
			info.put("period_name", "");
			
			if ( info.get("period_id") == null || "".equals((String) info.get("period_id")) ) return;
			if ( info.get("period_scheme") == null || "".equals((String) info.get("period_scheme")) ) return;
			
			try {
				db = new Db();
				Statement stmt = db.getStatement();
				SQLRenderer r = new SQLRenderer();
				//establish long period name

				{
					r.clear();
					r.add("period_name");
					r.add("period_level");
					r.add("parent_id");
					r.add("period_id", (String) info.get("period_id"));
					r.add("period_root_id", (String) info.get("period_scheme"));
					sql = r.getSQLSelect("period");

					int period_level = 0;
					String parent_id = "";
					ResultSet rs = stmt.executeQuery(sql);
					if ( rs.next() ) {
						info.put("period_name", rs.getString("period_name"));	
						period_level = rs.getInt("period_level");
						parent_id = rs.getString("parent_id");
					}

					String period_name = (String) info.get("period_name");
					while ( period_level != 0 ) {
						r.clear();
						r.add("period_name");
						r.add("parent_id");
						r.add("period_level");
						r.add("period_id", parent_id);
						sql = r.getSQLSelect("period");
						rs = stmt.executeQuery(sql);
						if ( rs.next() ) {
							period_name = rs.getString("period_name") + ", " + period_name;

							parent_id = rs.getString("parent_id");
							period_level = rs.getInt("period_level");
						}	
					}
					info.put("period_name", period_name);
					info.put("period_select_name", period_name);

				}

				
			} finally {
				if ( db != null ) db.close();
			}
		}
		public static void getCustomData(Hashtable h) throws Exception {
			Db db = null;
			String sql = "";
			try {
				db = new Db();
				Statement stmt = db.getStatement();
				SQLRenderer r = new SQLRenderer();
				Vector ud = new Vector();
				{
					r.add("data_id");
					r.add("data_name");
					r.add("value_type");
					sql = r.getSQLSelect("custom_data");
					
					ResultSet rs = stmt.executeQuery(sql);
					while (rs.next()) {
						Hashtable hc = new Hashtable();
						hc.put("id", Db.getString(rs, "data_id"));
						hc.put("name", Db.getString(rs, "data_name"));
						hc.put("type", Db.getString(rs, "value_type"));
						hc.put("values", new Vector());
						ud.addElement(hc);	
					}	
				}
				
				//for custom data that has values...
				
				for ( int i = 0; i < ud.size(); i++ ) {
					Hashtable hc = (Hashtable) ud.elementAt(i);
					if ( ((String) hc.get("type")).equals("selection") ) {
						Vector v = (Vector) hc.get("values");	
						String data_id = (String) hc.get("id");
						v = getDataValues(data_id, stmt, r, sql);
						hc.put("values", v);
					}
				}
				
				h.put("custom_data", ud);	
				
				{
					r.clear();
					r.add("d.data_name");
					r.add("s.data_value");
					r.add("s.student_id", (String) h.get("student_id"));
					r.add("s.data_id", r.unquote("d.data_id"));
					sql = r.getSQLSelect("student_custom_data s, custom_data d");
					ResultSet rs = stmt.executeQuery(sql);
					while ( rs.next() ) {
						h.put(rs.getString("data_name"), rs.getString("data_value"));
					}
				}
			} finally {
				if ( db != null ) db.close();
			}
		}
		public static Vector getDataValues(String data_id, Statement stmt, SQLRenderer r, String sql) throws Exception {
			r.clear();
			r.add("data_value");
			r.add("data_id", data_id);
			sql = r.getSQLSelect("custom_data_values");
			ResultSet rs = stmt.executeQuery(sql);
			Vector v = new Vector();
			while ( rs.next() ) {
				v.addElement(rs.getString("data_value"));
			}
			return v;
		}		
		
}
