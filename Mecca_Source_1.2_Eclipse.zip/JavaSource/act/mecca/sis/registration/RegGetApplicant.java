/* ************************************************************************
 * Copyright 2005 University ERP Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package act.mecca.sis.registration;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.db.DbException;
import mecca.db.SQLRenderer;
import mecca.util.DateTool;

import org.apache.velocity.VelocityContext;
/**
 * @author Shamsul Bahrin Abd Mutalib
 * @ refactored to ActionXML: red1
 * @version 1.0
*/
public class RegGetApplicant implements mecca.portal.action.ActionTemplate {
	private static String[] month_name = {"January", "February", "March", "April", "May", "Jun", "July", "August", "September", "October", "November", "December"};
	public void doAction(HttpServletRequest req, HttpServletResponse res, VelocityContext context) throws Exception 
	{
		HttpSession session = req.getSession();
		String submit = req.getParameter("command");
		String mode = session.getAttribute("mode") != null ? (String) session.getAttribute("mode") : "empty";
		Hashtable dateTime = DateTool.getCurrentDateTime();
		context.put("dateTime", dateTime);
		context.put("month_name", month_name);		
		String applicant_id = req.getParameter("applicant_id");
		Hashtable studentInfo = new Hashtable();
		studentInfo = getApplicant(applicant_id);
		context.put("studentInfo", studentInfo);
		context.put("isEnrolled", new Boolean(false));
		session.setAttribute("studentInfo", studentInfo);
		if ( studentInfo.get("applicant_id") != null )
			session.setAttribute("mode", "insert");
		else
			session.setAttribute("mode", "empty");
	}
	private Hashtable getApplicant(String id) throws Exception {
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			
			r.add("applicant_id");
			r.add("password");
			r.add("applicant_name");
			r.add("address1");
			r.add("address2");
			r.add("address3");
			r.add("city");
			r.add("state");
			r.add("poscode");
			r.add("country_code");
			r.add("email");
			r.add("phone");
			r.add("gender");
			r.add("birth_date");
			
			r.add("applicant_id", id);
			
			
			sql = r.getSQLSelect("adm_applicant");
			
			
			ResultSet rs = stmt.executeQuery(sql);
			if ( rs.next() ) {
				return getApplicantData(rs);
			}
			else
			{
				return new Hashtable();
			}
		} catch ( DbException dbex ) {
			throw dbex;
		} catch ( SQLException sqlex ) {
			throw sqlex;
		} finally {
			if ( db != null ) db.close();	
		}
	}
	private Hashtable getApplicantData(ResultSet rs) throws Exception {
		Hashtable applicantInfo = new Hashtable();
		
		applicantInfo.put("applicant_id", RegAdd.getString(rs, "applicant_id"));
		applicantInfo.put("password", RegAdd.getString(rs, "password"));
		applicantInfo.put("name", RegAdd.getString(rs, "applicant_name"));
		applicantInfo.put("address1", RegAdd.getString(rs, "address1"));
		applicantInfo.put("address2", RegAdd.getString(rs, "address2"));
		applicantInfo.put("address3", RegAdd.getString(rs, "address3"));
		applicantInfo.put("city", RegAdd.getString(rs, "city"));
		applicantInfo.put("state", RegAdd.getString(rs, "state"));
		applicantInfo.put("poscode", RegAdd.getString(rs, "poscode"));
		applicantInfo.put("country_code", RegAdd.getString(rs, "country_code"));
		applicantInfo.put("email", RegAdd.getString(rs, "email"));
		applicantInfo.put("phone", RegAdd.getString(rs, "phone"));
		
		applicantInfo.put("birth_date", RegAdd.getString(rs, "birth_date"));
		
		
		//-- REVISED ALL THE BELOW CODES LATER
		
		java.util.Date birthDate = rs.getDate("birth_date");
		
		Calendar c = new GregorianCalendar();
		c.setTime(birthDate);	
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH) + 1;
		int day = c.get(Calendar.DAY_OF_MONTH);		
		
		applicantInfo.put("birth_year", new Integer(year));
		applicantInfo.put("birth_month", new Integer(month));
		applicantInfo.put("birth_day", new Integer(day));
		
		return applicantInfo;
	}	
}
