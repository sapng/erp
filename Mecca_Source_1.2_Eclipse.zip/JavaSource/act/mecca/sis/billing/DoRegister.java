/* ************************************************************************
 * Copyright 2005 University ERP Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package act.mecca.sis.billing;

import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.sis.billing.DepositPayment;

import org.apache.velocity.VelocityContext;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @ refactored to ActionXML: red1
 * @version 1.0
*/
public class DoRegister implements mecca.portal.action.ActionTemplate {
	
	public void doAction(HttpServletRequest req, HttpServletResponse res, VelocityContext context) throws Exception 
	{
		HttpSession session = req.getSession();
		PreRegDefault.preRegistrationDefault(req, context);
		
		String yr = req.getParameter("bill_year"), mn = req.getParameter("bill_month"), dy = req.getParameter("bill_day");
		int iYr = !"".equals(yr) ? Integer.parseInt(yr) : 0;
		int iMn = !"".equals(mn) ? Integer.parseInt(mn) : 0;
		int iDy = !"".equals(dy) ? Integer.parseInt(dy) : 0;
		Hashtable paymentDate = new Hashtable();
		paymentDate.put("year", new Integer(iYr));
		paymentDate.put("month", new Integer(iMn));
		paymentDate.put("day", new Integer(iDy));	
		context.put("date", paymentDate);		
		
		String student_id = req.getParameter("student_id");
		if ( !"".equals(student_id) ) session.setAttribute("student_id", student_id);
		context.put("student_id", student_id);
		String icno = req.getParameter("icno");
		String student_name = req.getParameter("student_name");
		float amount = Float.parseFloat(req.getParameter("amount"));
		
		String program_code = req.getParameter("program_code");
		
		String centre_id = req.getParameter("centre_id");
		session.setAttribute("centre_id", centre_id);	
		
		String session_id = req.getParameter("session_id");
		context.put("session_id", session_id);		
		
		Hashtable info = new Hashtable();
		info.put("icno", icno);
		info.put("student_name", student_name);
		info.put("amount_paid", new Float(amount));
		info.put("program_code", program_code);
		info.put("student_id", student_id);
		info.put("centre_id", centre_id);
		info.put("session_id", session_id);
		context.put("info", info);
		
		DepositPayment.preRegisterStudent(info, paymentDate);
		
		student_id = (String) info.get("student_id");
		if ( !"".equals(student_id) ) session.setAttribute("student_id", student_id);
		//createInvoice(matric, program_code, paymentDate);  //moved into DepositPayment.preRegisterStudent(..);	
		
		Hashtable paymentInfo = DepositPayment.getPaymentInfoByMatric(student_id);
		context.put("paymentInfo", paymentInfo);

	}
}
