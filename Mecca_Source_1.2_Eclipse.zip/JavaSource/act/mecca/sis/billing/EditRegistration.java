/* ************************************************************************
 * Copyright 2005 University ERP Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package act.mecca.sis.billing;

import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.sis.billing.DepositPayment;

import org.apache.velocity.VelocityContext;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @ refactored to ActionXML: red1
 * @version 1.0
*/
public class EditRegistration implements mecca.portal.action.ActionTemplate {
	
	public void doAction(HttpServletRequest req, HttpServletResponse res, VelocityContext context) throws Exception 
	{
		HttpSession session = req.getSession();
		PreRegDefault.preRegistrationDefault(req, context);
	    context.put("mode", "edit");
	    String student_id = req.getParameter("student_id");
	    if ( !"".equals(student_id) ) session.setAttribute("student_id", student_id);

	    context.put("student_id", student_id);
		Hashtable paymentInfo = DepositPayment.getPaymentInfoByMatric(student_id);
		context.put("paymentInfo", paymentInfo);
	}
	
}	
