/* ************************************************************************
 * Copyright 2005 University ERP Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package act.mecca.sis.billing;

import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import mecca.sis.registration.SessionData;
import mecca.sis.struct.LearningCentreData;
import mecca.sis.struct.ProgramData;
import mecca.util.DateTool;

import org.apache.velocity.VelocityContext;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @ refactored to ActionXML: red1
 * @version 1.0
 * 
 *  */
public class PreRegDefault {
	public static void preRegistrationDefault(HttpServletRequest req, VelocityContext context) throws Exception {
		HttpSession session = req.getSession();
		String submit = req.getParameter("command");
		String student_id = !"".equals(req.getParameter("student_id")) ? req.getParameter("student_id") : "";
		context.put("student_id", student_id);
		if ( !"".equals(student_id) ) session.setAttribute("student_id", student_id);
		context.put("isSelect", new Boolean(false));
		
		
		//get default from session
		Hashtable dateTime = session.getAttribute("paymentDate") != null ? (Hashtable) session.getAttribute("paymentDate") 
		        			: DateTool.getCurrentDateTime();
        context.put("dateTime", dateTime);		   
		
		
		
		String session_id = session.getAttribute("session_id") != null ? (String) session.getAttribute("session_id")
		                    : SessionData.getCurrentSessionId();
		context.put("session_id", session_id);

		String program_code = session.getAttribute("program_code") != null ? (String) session.getAttribute("program_code")
		        			: "";
		context.put("program_code", program_code);
		
		Float amountFloat = (Float) session.getAttribute("amount");
		String centre_id = session.getAttribute("centre_id") != null ? (String) session.getAttribute("centre_id") 
		        			: "";
		context.put("center_id", centre_id);
		//
		
		//Hashtable dateTime = DateTool.getCurrentDateTime();
		//context.put("dateTime", dateTime);	
		
		Vector programList = ProgramData.getProgramList();
		context.put("programList", programList);
		
		Vector centreList = LearningCentreData.getCentreList();
		context.put("centreList", centreList);
		
		Vector sessionList = SessionData.getListDesc();
		context.put("sessionList", sessionList);
		
		//String current_session = !"".equals(req.getParameter("session_id")) ? req.getParameter("session_id") : SessionData.getCurrentSessionId();
		//context.put("session_id", current_session);			
		
		context.put("mode", "new");
		context.put("isRegister", new Boolean(false));		
		context.put("paymentInfo", new Hashtable());
	} 
}
