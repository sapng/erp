/* ************************************************************************
 * Copyright 2005 University ERP Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package act.mecca.sis.billing;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.db.SQLRenderer;

import org.apache.velocity.VelocityContext;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @ refactored to ActionXML: red1
 * @version 1.0
*/
public class SearchName implements mecca.portal.action.ActionTemplate 
{
	
	public void doAction(HttpServletRequest req, HttpServletResponse res, VelocityContext context) throws Exception 
	{
		HttpSession session = req.getSession();
		PreRegDefault.preRegistrationDefault(req, context);
		String value = req.getParameter("search_student_name").trim();
		Hashtable h = getSearchByName(value);
	    context.put("searchResult", h);
	    SearchMatric.prepareList(session, h, context);
	}	

public Hashtable getSearchByName(String value) throws Exception {
	if ( "".equals(value)) {
	    value = "%";
	} else if ( value.indexOf("%") < 0 ) {
	    value = value + "%";
	}
	
	Db db = null;
	String sql = "";
	try {
		db = new Db();
		Statement stmt = db.getStatement();
		SQLRenderer r = new SQLRenderer();
		Hashtable result = new Hashtable();
		Vector v = new Vector();
		{
			r.add("id");
			r.add("name");
			r.add("name", value, "LIKE");
			r.add("s.id", r.unquote("d.student_id"));
			sql = r.getSQLSelect("student_deposit d, student s", "name");
			ResultSet rs = stmt.executeQuery(sql);
			while ( rs.next() ) {
				Hashtable h = new Hashtable();
				h.put("id", rs.getString("id"));
				h.put("name", rs.getString("name"));
				v.addElement(h);
			}
		}
		result.put("criteria", value);
		result.put("studentList", v);
		return result;
	} finally {
		if ( db != null ) db.close();
		}
	}
}