/* ************************************************************************
 * Copyright 2005 University ERP Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ************************************************************************ */

package act.mecca.sis.billing;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mecca.db.Db;
import mecca.db.SQLRenderer;

import org.apache.velocity.VelocityContext;

/**
 * @author Shamsul Bahrin Abd Mutalib
 * @ refactored to ActionXML: red1
 * @version 1.0
 */
public class SearchMatric implements mecca.portal.action.ActionTemplate {
	protected static int LIST_ROWS = 50;		    
	protected static boolean isLastPage = false;
	public void doAction(HttpServletRequest req, HttpServletResponse res, VelocityContext context) throws Exception 
	{
		HttpSession session = req.getSession();
		PreRegDefault.preRegistrationDefault(req, context);
	    context.put("mode", "edit");
		String value = req.getParameter("search_student_id").trim();
	    Hashtable h = getSearchByMatric(value);
	    context.put("searchResult", h);
	    prepareList(session, h, context);

	}   
	public Hashtable getSearchByMatric(String value) throws Exception {
//		String value = req.getParameter("search_student_id").trim();
		if ( "".equals(value)) {
		    value = "%";
		} else if ( value.indexOf("%") < 0 ) {
		    value = value + "%";
		}
		
		Db db = null;
		String sql = "";
		try {
			db = new Db();
			Statement stmt = db.getStatement();
			SQLRenderer r = new SQLRenderer();
			Hashtable result = new Hashtable();
			Vector v = new Vector();
			{
				r.add("id");
				r.add("name");
				r.add("id", value, "LIKE");
				r.add("s.id", r.unquote("d.student_id"));
				sql = r.getSQLSelect("student_deposit d, student s", "name");
				//System.out.println(sql);
				ResultSet rs = stmt.executeQuery(sql);
				while ( rs.next() ) {
					Hashtable h = new Hashtable();
					h.put("id", rs.getString("id"));
					h.put("name", rs.getString("name"));
					v.addElement(h);
				}
			}
			result.put("criteria", value);
			result.put("studentList", v);
			return result;
		} finally {
			if ( db != null ) db.close();
		}
	}	
	public static void prepareList(HttpSession session, Hashtable result, VelocityContext context) throws Exception {
		Vector list = (Vector) result.get("studentList");
		int pages =  list.size() / LIST_ROWS;
		double leftover = ((double)list.size() % (double)LIST_ROWS);
		if ( leftover > 0.0 ) ++pages;
		context.put("pages", new Integer(pages));	
		session.setAttribute("pages", new Integer(pages));
			
		session.setAttribute("studentList", list);
		getRows(session, 1,context);
		session.setAttribute("page_number", "1");
		context.put("page_number", new Integer(1));
		context.put("studentList", list);		
	}	
	static void getRows(HttpSession session, int page, VelocityContext context) throws Exception {
		Vector list = (Vector) session.getAttribute("studentList");
		Vector items = getPage(page, LIST_ROWS, list, context);
		context.put("items", items);	
		context.put("page_number", new Integer(page));
		context.put("pages", (Integer) session.getAttribute("pages" ));			
	}
	static Vector getPage(int page, int size, Vector list, VelocityContext context) throws Exception {
		int elementstart = (page - 1) * size;
		int elementlast = 0;
		//int elementlast = page * size < list.size() ? (page * size) - 1 : list.size() - 1;
		if ( page * size < list.size() ) {
			elementlast = (page * size) - 1;
			isLastPage = false;
			context.put("eol", new Boolean(false));
		} else {
			elementlast = list.size() - 1;
			isLastPage = true;
			context.put("eol", new Boolean(true));
		}
		if ( page == 1 ) context.put("bol", new Boolean(true));
		else context.put("bol", new Boolean(false));
		Vector v = new Vector();
		for ( int i = elementstart; i < elementlast + 1; i++ ) {
			v.addElement(list.elementAt(i));
		}
		
		return v;
	}
}
